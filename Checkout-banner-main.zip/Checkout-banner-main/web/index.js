// @ts-check
dotenv.config();
import { join } from "path";
import { readFileSync } from "fs";
import express from "express";
import serveStatic from "serve-static";
import mongoose from "mongoose";
import dotenv from "dotenv";
import shopify from "./shopify.js";
import GDPRWebhookHandlers from "./gdpr.js";
import { billingConfig } from "./billing.js";
import { ConfigModel, ShopifySession } from "./models/shopifyConfig.js";
import { RuleList } from "./models/RuleList.js";
import couponRoute from "./Route/CouponRoute.js";
import planRoute from "./Route/PlanRoute.js";
import checkoutExtensionRoute from "./Route/CheckoutExtensionRoute.js";
import cors from "cors";
import logger from "./helper/Logger.js";
import { BilledTransaction } from "./models/BilledTransaction.js";
import cron from "node-cron";
import { getPlanBillingURL } from "./controller/PlanController.js";
import { PlanModel } from "./models/PlanModel.js";
import paymentReorder from "./Route/PaymentReorderRoute.js";
import prepaidDiscount from "./Route/PrepaidDiscountRoute.js";
import freebieProduct from "./Route/FreebieProduct.js";
import FormFieldRoute from "./Route/FormFieldRoute.js";
import DynamicContentRoute from "./Route/DynamicContentRoute.js";
import axios from 'axios';

// Getting the port from the env if not found then using default. The port is converted to a int with base 10
const PORT = parseInt(
  process.env.BACKEND_PORT || process.env.PORT || "8081",
  10
);

const STATIC_PATH =
  process.env.NODE_ENV === "production"
    ? `${process.cwd()}/frontend/dist`
    : `${process.cwd()}/frontend/`;

const app = express();

app.use(cors());
//app.use((req, res, next) => {
//  res.header("Access-Control-Allow-Origin", "*");
//  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");
//  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//  next();
//});

async function installationNotifySlack(req, res, next) {
  const session = res.locals.shopify.session;
  const client = new shopify.api.clients.Graphql({ session });

  const getShopDetailsQuery = await client.query({
    data: {
      query: `{
        shop {
          name
          contactEmail
          email
          url
          plan {
            displayName
          }
          billingAddress {
            country
            phone
          }
        }
      }`
    }
  });

  // @ts-ignore
  const shopDetails = getShopDetailsQuery.body.data.shop || {};
  if(!shopDetails) next();

  // You can have other conditions or checks here if needed.
  if (process.env.SLACK_INSTALLATION_WEBHOOK_URL) {
      axios.post(process.env.SLACK_INSTALLATION_WEBHOOK_URL, {
        "blocks": [
          {
            "type": "section",
            "block_id": "sectionBlockWithButton",
            "text": {
              "type": "mrkdwn",
              "text": "You have a new installation"
            }
          }
        ],
        "attachments": [
          {
            "color": "#ebff9e",
            "blocks": [
              {
                "type": "section",
                "text": {
                  "type": "mrkdwn",
                  "text": "*<"+ shopDetails.url +">*"
                }
              },
              {
                "type": "section",
                "text": {
                  "type": "mrkdwn",
                  "text": "*Name:* "+ shopDetails.name +"\n*Contact Email:* "+ shopDetails.contactEmail +"\n*Phone Number:* "+ shopDetails.billingAddress.phone +"\n*Email:* "+ shopDetails.email +"\n*Country:* "+ shopDetails.billingAddress.country +"\n*Plan:* "+ shopDetails.plan.displayName
                },
                "accessory": {
                  "type": "button",
                  "text": {
                    "type": "plain_text",
                    "text": "Open Website",
                    "emoji": true
                  },
                  "value": "click_me_123",
                  "action_id": "button-action",
                  "url": shopDetails.url
                }
              }
            ]
          }
        ]
      })
      .then(() => {
          next();
      })
      .catch(error => {
          console.error('Error sending notification to Slack:', error);
          // You can decide to propagate the error or just log and move forward.
          // next(error)
          next();
      });
  } else {
      next(); // If no eventData or not the condition you're looking for, just move to the next middleware.
  }
}

// Set up Shopify authentication and webhook handling
app.get(shopify.config.auth.path, shopify.auth.begin());
app.get(
  shopify.config.auth.callbackPath,
  shopify.auth.callback(),
  installationNotifySlack,
  // Check Default Plan
  async (req, res, next) => {
    const { shop } = req.query;
    await BilledTransaction.updateOne({ shop }, { shop }, { upsert: true });
    next();
  },
  shopify.redirectToShopifyOrAppRoot()
);

app.post(
  shopify.config.webhooks.path,
  shopify.processWebhooks({ webhookHandlers: GDPRWebhookHandlers })
);

// If you are adding routes outside of the /api path, remember to
// also add a proxy rule for them in web/frontend/vite.config.js

app.use("/api/*", shopify.validateAuthenticatedSession());
app.use(express.json());

/**
 * Check Subscription Status
 *
 */
app.get("/api/checkBilling", async (req, res) => {
  logger.info("Check Billing Status Api Called");
  const plans = Object.keys(billingConfig);
  const session = res.locals.shopify.session;

  // Get the shop current plan
  const currentplan = await BilledTransaction.findOne({ shop: session.shop });

  // If they are on free plan respond with true.
  if (currentplan.planId == "free") {
    return res.json({ hasPayment: true });
  }

  const hasPayment = await shopify.api.billing.check({
    session,
    plans: plans, // Here we are using Plan Name
    isTest: process.env.NODE_ENV !== "production",
  });

  if (hasPayment) {
    res.json({ hasPayment: hasPayment });
  } else {
    let result = await getPlanBillingURL(session, "basic"); // Here we are using Plan ID

    res.json({
      hasPayment: hasPayment,
      url: result.url,
    });
  }
});

// Custom Field
app.use("/api/dynamicContent", DynamicContentRoute);

// Custom Field
app.use("/api/form", FormFieldRoute);

// Payment Gateway Reorder
app.use("/api/paymentReorder", paymentReorder);

// Prepaid Discount
app.use("/api/prepaidDiscount", prepaidDiscount);

// Freebie Discount
app.use("/api/freebieProduct", freebieProduct);

// Add Coupon CURD URL
app.use("/api/checkoutextension", checkoutExtensionRoute);
app.use("/api/coupon", couponRoute);
app.use("/api/plans", planRoute);

/**
 * Seed Rule List data.
 *
 */
app.get("/api/seed/rules", (req, res, next) => {
  const rules = [
    { name: "LineItem Id" },
    { name: "Product Id" },
    { name: "Logined User" },
  ];
  rules.forEach(async (rule) => {
    await RuleList.updateOne(
      { name: rule.name },
      { ...rule, id: Date.now() },
      { upsert: true }
    );
  });
  return res.status(200).send({ status: 200, success: true });
});

app.use(shopify.cspHeaders());
app.use(serveStatic(STATIC_PATH, { index: false }));

app.use("/*", shopify.ensureInstalledOnShop(), async (_req, res, _next) => {
  return res
    .status(200)
    .set("Content-Type", "text/html")
    .send(readFileSync(join(STATIC_PATH, "index.html")));
});

const DB_URL = process.env.DB_URL;
logger.info(DB_URL);
mongoose.set("strictQuery", true);
mongoose
  .connect(DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    app.listen(PORT);
    logger.info("Connected to database");
  })
  .catch(() => {
    logger.error("Database Connection Failed");
  });

//cron

const GET_ACTIVE_SUBSCRIPTION_DETAILS = `
  query appSubscription {
    currentAppInstallation {
      activeSubscriptions {
        id
        currentPeriodEnd
        name
        test
        status
      }
    }
  }`

// Define the task for updating Billing
const task = async () => {
  const currentDate = new Date();

  try {
    // Fetch the list of shops
    const shopsDetails = await BilledTransaction.find({status: 'ACTIVE', nextBillingDate: { $lt: currentDate }});

    // Loop through each shop
    for (const shopsDetail of shopsDetails) {
      // Fetch app subscription data for the shop
      const shopName = shopsDetail.shop;
      const shopCurrentPlanId = shopsDetail.planId;
      const planDetailsForShop = await PlanModel.findOne({planId:shopCurrentPlanId});
      let updateDetails = {};


      try {
        if(shopCurrentPlanId == 'free' && shopsDetail.nextBillingDate ) {
          const givenDate = new Date(shopsDetail.nextBillingDate); // Replace with your given date
          const numberOfDaysToAdd = 30;

          const nextBillingDateForFreePlan = new Date(givenDate);
          nextBillingDateForFreePlan.setDate(givenDate.getDate() + numberOfDaysToAdd);

          // Reset the free usage and update the next billing date by calculating 30 days from current date
          updateDetails.nextBillingDate = nextBillingDateForFreePlan;
          updateDetails.viewCount = 0;
          updateDetails.extraViewCount = 0;
          updateDetails.extraViewCharge = 0;
        } else {

          const session = await ShopifySession.findOne({ shop: shopName });
          const client = new shopify.api.clients.Graphql({ session });

          // This function is on billing.js which can be made modular
          // Check Shopify which plan is active for this shop and details
          const activeSubscriptionDetailsResult = await client.query({
            data: {
              query: GET_ACTIVE_SUBSCRIPTION_DETAILS,
            },
          });

          const activeSubscriptionDetails = activeSubscriptionDetailsResult?.body?.data?.currentAppInstallation?.activeSubscriptions;
          const nextBillingDateFromShopify = activeSubscriptionDetails[0]?.currentPeriodEnd;

          updateDetails.nextBillingDate = nextBillingDateFromShopify;
          updateDetails.viewCount = 0;
          updateDetails.extraViewCount = 0;
          updateDetails.extraViewCharge = 0;
        }

        updateDetails.viewLimit = planDetailsForShop.viewLimit;
        await BilledTransaction.updateOne({ shop: shopName },updateDetails);
        return true;

      } catch (error) {
        console.error(`Error during executing cron task for shop ${shopName}:`, error);
      }
    }
    console.log('Cron Executed');
  } catch (error) {
    console.error('Error executing cron task:', error);
  }
};

// Run Cron Every 12 hrs 
cron.schedule("0 */12 * * *", task );

// Only on development server run this cron according to requirement
// Don't run this on production as it is very heavy lifting task
// cron.schedule("* * * * *", task );
