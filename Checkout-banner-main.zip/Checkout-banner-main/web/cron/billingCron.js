import cron from 'node-cron';

cron.schedule('* * * * *', async () => {
    // Session is built by the OAuth process
    let resp = await shopify.rest.RecurringApplicationCharge.all({
        session: session,
    });
    console.log(resp,"_______cron")
});  