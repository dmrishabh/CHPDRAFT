import { GraphqlQueryError, BillingInterval } from "@shopify/shopify-api";
import shopify from "./shopify.js";
import { ConfigModel } from "./models/shopifyConfig.js";
import { BilledTransaction } from "./models/BilledTransaction.js";
import logger from "./helper/Logger.js";
import { respondInternalServerError } from "./helper/Response.js";
import { ShopifySession } from "./models/shopifyConfig.js";
import { PlanModel } from "./models/PlanModel.js"
import { filter } from "compression";

export const billingConfig = {
  // TODO: DB pull all the non free plans
  // Free: {
  //   amount: 10,
  //   currencyCode: "USD",
  //   interval: BillingInterval.Every30Days,
  // },
  Basic: {
    id: 'basic',
    amount: 10,
    currencyCode: "USD",
    interval: BillingInterval.Every30Days,
    cappedAmount: 300,
    usageTerms: "0.001 dollar per page views",
  },
};

/**
 * Ensure Billing.
 *
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
export async function ensureBilling(req, res, next) {
  logger.info("Callback ensureBilling Called...");
  const plans = Object.keys(billingConfig);

  const session = res.locals.shopify.session;
  const hasPayment = await shopify.api.billing.check({
    session,
    plans: plans,
    isTest: true,
  });

  logger.info("Planned Ckecked.....");
  if (hasPayment) {
    next();
  } else {
    logger.info("Redirecting to Billing Page....");
    const redirectUrl = await shopify.api.billing.request({
      session,
      plan: plans[0],
      isTest: true,
    });

    // Not sure why this is required
    ConfigModel.updateOne(
      { shop: session.shop },
      {
        shop: session.shop,
        url: redirectUrl,
        subscribedAt: hasPayment ? new Date().toISOString() : "",
      },
      { upsert: true }
    ).then((resp) => {
      logger.info("Config Model Updated....", resp);
    });
    logger.info("Redirecting to Billing Page....", redirectUrl);
    res.redirect(redirectUrl);
  }
}

// Create Usess Query
const CREATE_USAGE_RECORD = `
  mutation appUsageRecordCreate($subscriptionLineItemId: ID!, $amount: Decimal!, $description: String!){
      appUsageRecordCreate(
        subscriptionLineItemId: $subscriptionLineItemId,
        description: $description,
        price: { amount: $amount, currencyCode: USD }
      ) {
        userErrors {
          field
          message
        }
        appUsageRecord {
          id
        }
    }
  }`;

const HAS_PAYMENTS_QUERY = `
  query appSubscription {
    currentAppInstallation {
      activeSubscriptions {
            id
            name
            lineItems {
                  id
                  plan {
                    pricingDetails {
                      __typename
                      ... on AppUsagePricing {
                        terms
                        balanceUsed {
                          amount
                        }
                        cappedAmount {
                          amount
                        }
                      }
                    }
                  }
                }
            }
          }
      }
  `;

/*
 * This function creates a usage record for the app subscription.
 * To create a usage record, we need to know the app subscription line item ID.
 * You may want to store this ID in your database, but for simplicity, we are
 * querying the API for it here.
 * This function also returns the total amount in dollars of usage records that have been created.
 */

export async function createUsageRecord(session, planDetails) {
  const client = new shopify.api.clients.Graphql({ session });
  const subscriptionLineItems = await getAppSubscription(session);

  const subscriptionLineItem = subscriptionLineItems.filter((lineItem) => {
      return lineItem.type === 'AppUsagePricing';
    }
  )

  const usageChargeIncrementAmount = planDetails.costPerView;
  const res = {
    capacityReached: false,
    createdRecord: false,
  };

  // If the capacity has already been reached, we will not attempt to create the usage record
  // On production shops, if you attempt to create a usage record and the capacity and been
  // reached Shopify will return an error. On development shops, the usage record will be created
  if (
      subscriptionLineItem[0].balanceUsed + usageChargeIncrementAmount >= subscriptionLineItem[0].cappedAmount
  ) {
      res.capacityReached = true;
      return res;
  }

  console.log(planDetails.costPerView);

  try {
    // This makes an API call to Shopify to create a usage record
    await client.query({
      data: {
        query: CREATE_USAGE_RECORD,
        variables: {
          subscriptionLineItemId: subscriptionLineItem[0].id,
          amount: planDetails.costPerView,
          description: planDetails.usageTerms,
        },
      },
    });
    res.createdRecord = true;
  } catch (error) {
    if (error instanceof GraphqlQueryError) {
      throw new Error(
        `${error.message}\n${JSON.stringify(error.response, null, 2)}`
      );
    } else {
      throw error;
    }
  }

  return res;
}

/*
 * This function queries the API to get the app subscription line item ID by the
 * plan name and usage terms. You may want to store this ID in your database, but
 * for simplicity, we are querying the API for it here.
 */
export async function getAppSubscription(session) {
  const client = new shopify.api.clients.Graphql({ session });
  let subscriptionLineItem = [];

  try {
    const response = await client.query({
      data: {
        query: HAS_PAYMENTS_QUERY,
      },
    });

    logger.info(JSON.stringify(response.body, "App subscription data"));

    response.body.data.currentAppInstallation.activeSubscriptions.forEach(
      (subscription) => {
        logger.info(subscription.name, "_________subscription.name");
        subscription.lineItems.forEach((lineItem) => {
          logger.info(lineItem, "App subscription lineItem");
          if (lineItem.plan?.pricingDetails) {
            let subscriptionLineItems = {
              type: lineItem.plan?.pricingDetails?.__typename,
              name: subscription.name,
              id: lineItem.id,
              balanceUsed: parseFloat(
                lineItem.plan.pricingDetails?.balanceUsed?.amount
              ),
              cappedAmount: parseFloat(
                lineItem.plan.pricingDetails?.cappedAmount?.amount
              ),
            };
            subscriptionLineItem.push(subscriptionLineItems);
          }
        });
      }
    );
  } catch (error) {
    if (error instanceof GraphqlQueryError) {
      throw new Error(
        `${error.message}\n${JSON.stringify(error.response, null, 2)}`
      );
    } else {
      throw error;
    }
  }
  return subscriptionLineItem;
}

const GET_ACTIVE_SUBSCRIPTION_DETAILS = `
  query appSubscription {
    currentAppInstallation {
      activeSubscriptions {
        id
        currentPeriodEnd
        name
        test
        status
      }
    }
  }`

//update billing transaction model
export const updateBillingTransaction = async (shop, payload) => {

    try {
      if (payload && payload.app_subscription && (payload.app_subscription.status !== 'DECLINED' && payload.app_subscription.status !== 'EXPIRED')) {
        const session = await ShopifySession.findOne({ shop });
        const client = new shopify.api.clients.Graphql({ session });

        // Check Shopify which plan is active for this shop and details
        const activeSubscriptionDetailsResult = await client.query({
          data: {
            query: GET_ACTIVE_SUBSCRIPTION_DETAILS,
          },
        });

        const activeSubscriptionDetails = activeSubscriptionDetailsResult?.body?.data?.currentAppInstallation?.activeSubscriptions;
        const nextBillingDateFromShopify = activeSubscriptionDetails[0]?.currentPeriodEnd;
        const planNameFromShopify = activeSubscriptionDetails[0]?.name
        const appSubscriptionGIDFromShopify = activeSubscriptionDetails[0]?.id

        let planDetailsOfShopify = '';
        /* Call to DB to get the plan details */
        if(planNameFromShopify){
          planDetailsOfShopify = await PlanModel.findOne({ planName: planNameFromShopify });
        }
        const planIdOfShopifyPlan = planDetailsOfShopify?.planId;
        const viewLimitOfShopifyPlan = planDetailsOfShopify?.viewLimit;

        const statusFromShopify = activeSubscriptionDetails[0].status;
        const app_subscription_details_from_webhook = payload.app_subscription;

        /*
          If active status
          If Plan Name is not matching with the data base (Plan Upgrade or Downgrade)
            - Reset usage
            - Update all other values accordingly

          If Plan Name is matching
            - Only update Cap amount
            - Update app charge ID
        */

        let updateDetails = {};

        if(statusFromShopify == 'ACTIVE' && activeSubscriptionDetails.length > 0) {

          const planOnTheDB = await BilledTransaction.findOne({ shop });

          // Plan name not matching (Plan Upgrade or Downgrade) Reset the counters and other values
          if(planOnTheDB.name != planNameFromShopify ) {
            updateDetails.nextBillingDate = nextBillingDateFromShopify;
            updateDetails.viewCount = 0;
            updateDetails.extraViewCount = 0;
            updateDetails.extraViewCharge = 0;
            updateDetails.viewLimit = viewLimitOfShopifyPlan;
          }

          updateDetails.planId = planIdOfShopifyPlan;
          updateDetails.planName = planNameFromShopify;
          updateDetails.status = statusFromShopify;
          updateDetails.adminGraphqlApiId = appSubscriptionGIDFromShopify;
          updateDetails.cappedAmount = app_subscription_details_from_webhook.capped_amount;
          updateDetails.adminGraphqlApiShopId = app_subscription_details_from_webhook.admin_graphql_api_shop_id;
        }

        // Update billing in the DB by pulling the plan data
        await BilledTransaction.updateOne({ shop },updateDetails);
        return true;
      } else {
        return true;
      }
    } catch (e) {
      console.log(JSON.stringify(e));
    }
};