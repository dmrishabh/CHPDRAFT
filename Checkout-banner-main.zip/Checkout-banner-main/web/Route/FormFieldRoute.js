import { Router} from "express";
import { create, details, deleteForm } from "../controller/FieldController.js";

const FormRoute = Router();

FormRoute.post("/create", create);
FormRoute.get("/details", details);
FormRoute.delete("/delete", deleteForm);

export default FormRoute;