import { Router } from "express";
import { createAppBasicCoupon, createAppAutomaticCoupon, getAllFreebieCoupons, details, query, update } from "../controller/FreebieProduct.js"

const FreebieProductRoute = Router();

FreebieProductRoute.post("/createAppBasicCoupon", createAppBasicCoupon);
FreebieProductRoute.post("/createAppAutomaticCoupon", createAppAutomaticCoupon);
FreebieProductRoute.get("/getAllFreebieCoupons", getAllFreebieCoupons);
FreebieProductRoute.post("/query", query);
FreebieProductRoute.post("/details", details);
FreebieProductRoute.post("/update", update);

export default FreebieProductRoute;