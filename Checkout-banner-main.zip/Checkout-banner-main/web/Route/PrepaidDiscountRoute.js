import { Router } from "express";
import { create, check, details, update } from "../controller/PrepaidDiscount.js";


const paymentReorder = Router();

paymentReorder.post("/create", create);
paymentReorder.post("/details", details);
paymentReorder.post("/update", update);
paymentReorder.post("/check", check);

export default paymentReorder;
