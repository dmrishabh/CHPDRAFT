import { Router } from "express";
import { create, details, update, check  } from "../controller/PaymentReorder.js";


const paymentReorder = Router();

paymentReorder.post("/create", create);
paymentReorder.post("/details", details);
paymentReorder.post("/update", update);
paymentReorder.post("/check", check);

export default paymentReorder;
