import { Router} from "express";
import { 
   handleAddCoupon, handleCouponQuery, handleFetchCouponList, handleListCoupon,
   handleViewCoupon, validateAddCoupon, validateListCoupon, validateViewCoupon
} from "../controller/CouponController.js";


const couponRoute = Router();

// Fetch Coupon List foom the shopify
couponRoute.get("/query", handleCouponQuery);

// Fetch Coupon List
couponRoute.post("/fetch", handleFetchCouponList);

// Curd Operation on the coupon
couponRoute.post("/add", validateAddCoupon, handleAddCoupon);
couponRoute.get("/list", validateListCoupon, handleListCoupon);
couponRoute.get("/view", validateViewCoupon, handleViewCoupon);
couponRoute.post("/update", validateAddCoupon, handleAddCoupon);

export default couponRoute;
