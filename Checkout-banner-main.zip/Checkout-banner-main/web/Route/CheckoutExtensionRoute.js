import { Router} from "express";
import {
   handlePageViewed,
   validatePageViewed
} from "../controller/CouponController.js";


const checkoutExtensionRoute = Router();

//View 
checkoutExtensionRoute.post("/viewed", validatePageViewed, handlePageViewed);

export default checkoutExtensionRoute;