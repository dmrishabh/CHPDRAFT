import { Router} from "express";
import { create, details, deleteDynamicContent } from "../controller/DynamicBlockController.js";

const DynamicContentRoute = Router();

DynamicContentRoute.post("/create", create);
DynamicContentRoute.get("/details", details);
DynamicContentRoute.delete("/delete", deleteDynamicContent);

export default DynamicContentRoute;