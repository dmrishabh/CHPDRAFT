import { Router } from "express";
import {
    listPlans,
    validateUpdatePlan,
    updatePlan
} from "../controller/PlanController.js";

const PlanRoute = Router();

//Views Plans
PlanRoute.get("/list", listPlans);
PlanRoute.get("/updateplan/:plan",validateUpdatePlan, updatePlan);

export default PlanRoute;