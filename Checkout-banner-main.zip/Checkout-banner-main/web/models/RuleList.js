import mongoose from "mongoose";

const RuleListSchema =  mongoose.Schema({
    id: Number,
    name: String,
    operator: String
},{ timestamps: true, _id: false , __v: false });
export const RuleList = mongoose.model("RuleList", RuleListSchema);