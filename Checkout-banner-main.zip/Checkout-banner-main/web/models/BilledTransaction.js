import mongoose from "mongoose";

// next billing date set for 30days
let nextDate = new Date();
nextDate.setDate(nextDate.getDate() + 30);

const BilledTransactionSchema = mongoose.Schema({
    shop: String,
    viewCount: { type: Number, default: 0 },
    /* 
     * STATUS should be always be pulled from this page https://shopify.dev/docs/api/admin-graphql/2023-04/enums/AppSubscriptionStatus
     * As this is also used with webhook to update the data it makes it easy 
     */
    status: { type: String, enum: ["ACTIVE", "CANCELLED","DECLINED","EXPIRED","FROZEN","PENDING"], default: "ACTIVE"}, 
    lastBilledDate: Date,
    nextBillingDate: { type: Date, default: nextDate },
    planName: { type: String, default: 'Free' },
    extraViewCount: { type: Number, default: 0 },
    extraViewCharge: { type: Number, default: 0 },
    viewLimit: { type: Number, default: 100 },
    planId: { type: String, default: 'free' }, // Should always be in lowercase
    adminGraphqlApiId: { type: String },
    adminGraphqlApiShopId: { type: String },
    cappedAmount: { type: String }
}, { timestamps: true, __v: false });

export const BilledTransaction = mongoose.model("BilledTransaction", BilledTransactionSchema);