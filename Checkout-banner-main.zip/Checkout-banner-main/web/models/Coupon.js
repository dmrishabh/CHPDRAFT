import mongoose from "mongoose";

const CouponSchema =  mongoose.Schema({
    gid: String,
    shop: String,
    code: String,
    title: String,
    subtitle: String,
    discountType: String,
    coupon_rule:{
        discountType: String,
        customerGets: Object,
        minimumRequirement: {
            type: Object,
            default:null
        },
        destinationSelection: {
            type: Object,
            default: null
        },
        maximumShippingPrice: Object
    },
    status: {
        type: String,
        enum: ["Active", "Deactivate"],
        default: "Active"
    }
},{ timestamps: true });
export const Coupon = mongoose.model("Coupon", CouponSchema);