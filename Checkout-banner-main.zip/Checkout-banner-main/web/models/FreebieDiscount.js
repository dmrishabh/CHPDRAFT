import mongoose from "mongoose";

const FreebieDiscountSchema =  mongoose.Schema({
    shop: String,
    discountId: String,
    discountTitle: String,
    discountType: Array,
    purchaseAmount: Number,
    purchaseQuantity: Number,
    appliesTo: Array,
    selectedProducts: Array,
    selectedCollections: Array,
    selectedGetProducts: Array
},{ timestamps: true, _id: false , __v: false  });

export const FreebieDiscount = mongoose.model("FreebieDiscount", FreebieDiscountSchema);