import mongoose from "mongoose";

const viewCountSchema =  mongoose.Schema({
    id: String,
    shop: String,
    token: String,
},{ timestamps: true, _id: false });
export const viewCount = mongoose.model("viewCount", viewCountSchema);