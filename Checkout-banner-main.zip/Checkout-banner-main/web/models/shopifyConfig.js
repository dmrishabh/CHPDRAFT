import mongoose from "mongoose";

const StoreList = mongoose.Schema({
    shop: String,
    url: String,
    subscribedAt: String,
    subscriptionId: String,
    subscriptionDetails: Object,
}, { timestamps: true });
export const ConfigModel = mongoose.model("ConfigModel", StoreList);

const sessionSchema = mongoose.Schema({
    shop: String    
}, { strict: false });
export const ShopifySession = mongoose.model("shopify_sessions", sessionSchema);