import mongoose from "mongoose";

const PlanSchema = mongoose.Schema({
    planId: String,
    planName: String,
    planType: { type: String, enum: ["Public", "Custom"] },
    planPrice: Number,
    currencyCode: { type: String, default: "USD" },
    cappedAmount: Number,
    usageTerms: String,
    viewLimit: Number,
    costPerView: Number,
}, { timestamps: true, __v: false });

export const PlanModel = mongoose.model("PlanModel", PlanSchema);