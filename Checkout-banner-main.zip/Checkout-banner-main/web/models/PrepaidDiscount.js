import mongoose from "mongoose";

const PrepaidDiscountSchema =  mongoose.Schema({
    gid: String,
    shop: String,
},{ timestamps: true });
export const PrepaidDiscount = mongoose.model("PrepaidDiscount", PrepaidDiscountSchema);