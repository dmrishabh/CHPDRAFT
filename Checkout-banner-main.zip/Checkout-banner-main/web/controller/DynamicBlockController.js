import shopify from "../shopify.js";
import { GraphqlQueryError } from "@shopify/shopify-api";

const metafieldFieldDetails = {
  namespace: "checkout_pro",
  key: "dynamic_content"
}

/**
 * Creating the function dynamically
 *
 * @param {*} req
 * @param {*} res
 */
export const create = async (req, res) => {
  const { shop } = res.locals.shopify.session;
  const payload = req.body;

  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Find the store ID and the metafield details
    const shopDetails = await graphqlClient.query({
      data: {
        query: `{
          shop {
            id
            metafield(namespace: "${ metafieldFieldDetails.namespace }",key: "${ metafieldFieldDetails.key }") {
              value
            }
          }
        }`
      }
    });

    const shopifyStoreID = shopDetails.body.data.shop.id;
    const metafieldData = JSON.parse(shopDetails.body.data.shop.metafield?.value || '[]');

    const blockID = payload.id

    // Find the index of the object with the matching ID, if it exists
    const indexToUpdate = metafieldData.findIndex(item => item.id === blockID);

    if (indexToUpdate !== -1) {
      // If a matching ID is found, update the existing object
      metafieldData[indexToUpdate] = payload;
    } else {
      // If no matching ID is found, insert the new data
      metafieldData.push(payload);
    }

    // Create the discount with metafield for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
          metafieldsSet(metafields: $metafields) {
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "metafields": [
            {
              "key": metafieldFieldDetails.key,
              "namespace": metafieldFieldDetails.namespace,
              "ownerId": shopifyStoreID,
              "type": "json",
              "value": JSON.stringify(metafieldData)
            }
          ]
        }
      },
    });

    return res.json({payload,metafieldData}).send();

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
}


/**
 * Get the details of the dynamic content
 *
 * @param {*} req
 * @param {*} res
 */
export const details = async (req, res) => {
  const { shop } = res.locals.shopify.session;
  const payload = req.body;

  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {

    const shopDetails = await graphqlClient.query({
      data: {
        query: `{
          shop {
            metafield(namespace: "${ metafieldFieldDetails.namespace }",key: "${ metafieldFieldDetails.key }") {
              value
            }
          }
        }`
      }
    });

    const metafieldData = JSON.parse(shopDetails.body.data.shop.metafield?.value || '[]');

    return res.json({metafieldData});

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
}


/**
 * Creating the function dynamically
 *
 * @param {*} req
 * @param {*} res
 */
export const deleteDynamicContent = async (req, res) => {
  const { shop } = res.locals.shopify.session;
  const payload = req.body;

  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Find the store ID and the metafield details
    const shopDetails = await graphqlClient.query({
      data: {
        query: `{
          shop {
            id
            metafield(namespace: "${ metafieldFieldDetails.namespace }",key: "${ metafieldFieldDetails.key }") {
              value
            }
          }
        }`
      }
    });

    const shopifyStoreID = shopDetails.body.data.shop.id;
    const metafieldData = JSON.parse(shopDetails.body.data.shop.metafield?.value || '[]');

    const formID = payload.id

    // Find the index of the object with the matching ID, if it exists
    const indexToRemove = metafieldData.findIndex(item => item.id === formID);

    if (indexToRemove !== -1) {
      // If a matching ID is found, update the existing object
      metafieldData.splice(indexToRemove, 1);
    } else {
      // If no matching ID is found, insert the new data
      metafieldData.push(payload);
    }

    // Create the discount with metafield for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
          metafieldsSet(metafields: $metafields) {
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "metafields": [
            {
              "key": metafieldFieldDetails.key,
              "namespace": metafieldFieldDetails.namespace,
              "ownerId": shopifyStoreID,
              "type": "json",
              "value": JSON.stringify(metafieldData)
            }
          ]
        }
      },
    });

    return res.json({payload});

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
}
