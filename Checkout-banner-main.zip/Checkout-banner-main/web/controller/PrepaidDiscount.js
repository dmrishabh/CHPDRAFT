import shopify from "../shopify.js";
import { GraphqlQueryError } from "@shopify/shopify-api";
import { PrepaidDiscount } from "../models/PrepaidDiscount.js";

// Helper function for handling any user-facing errors in GraphQL responses
function handleUserError(userErrors, res) {
  if (userErrors && userErrors.length > 0) {
    const message = userErrors.map((error) => error.message).join(' ');
    res.status(500).send({ error: message });
    return true;
  }
  return false;
}

/**
 * Creating the function dynamically
 *
 * @param {*} req
 * @param {*} res
 */
export const create = async (req, res) => {
  const { shop } = res.locals.shopify.session;
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Create the discount with metafield for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation discountAutomaticAppCreate($automaticAppDiscount: DiscountAutomaticAppInput!) {
          discountAutomaticAppCreate(automaticAppDiscount: $automaticAppDiscount) {
            automaticAppDiscount {
              # DiscountAutomaticApp fields
              discountId
            }
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "automaticAppDiscount": {
            "title": payload.data.title,
            "startsAt": payload.data.startsAt,
            "combinesWith": {
              "orderDiscounts": true,
              "productDiscounts": true,
              "shippingDiscounts":true
            },
            "functionId": payload.data.functionId,
            "metafields": [
              {
                "description": "For the prepaid discount configuration values",
                "key": "function-configuration",
                "namespace": "$app:prepaid-discount",
                "type": "json",
                "value": JSON.stringify({
                  uptoAmount: payload.data.uptoAmount,
                  percentage: payload.data.discountPercentage,
                })
              }
            ]
          }
        }
      },
    });


    let createResult = createResponse.body.data.discountAutomaticAppCreate;
    if (handleUserError(createResult.userErrors, res)) {
      return;
    }

    const discountId = createResult.automaticAppDiscount.discountId;

    // Create the entry in the database so we can retrive the information required
    await PrepaidDiscount.updateOne({ shop: shop }, { gid: discountId, shop: shop }, { upsert: true });

    return res.status(200).send();

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    } 
    return res.status(500).send({ error: error.response });
  }
};


/**
 * Check the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const check = async (req, res) => {

  const { shop } = res.locals.shopify.session;
  const payload = req.body;

  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  const appFunctionId = payload.functionId;

  // get the current function created by the app.
  try {
    const prepaidCouponOnStore = await PrepaidDiscount.find({shop: shop }).limit(1);
    let discountNodeData;

    // Check if the discount is active on Shopify
    if(prepaidCouponOnStore.length) {
      const discountNode = await graphqlClient.query({
        data: {
          query: `query GetDiscountNode($discountId: ID!) {
            discountNode(id: $discountId) {
              discount {
                ... on DiscountAutomaticApp {
                  status
                  appDiscountType {
                    appBridge {
                      detailsPath
                    }
                  }
                }
              }
            }
          }`,
          variables: {
            discountId: prepaidCouponOnStore[0].gid,
          }
        }
      });
      discountNodeData = discountNode.body.data.discountNode;
    }

    if(discountNodeData && discountNodeData.discount.status) {
      const discountEditURL = (discountNodeData.discount.appDiscountType.appBridge.detailsPath)
      .replace(':functionId',appFunctionId)
      .replace(':id',prepaidCouponOnStore[0].gid.replace('gid://shopify/DiscountAutomaticNode/','')) || null
      discountNodeData = {...discountNodeData , discountEditURL: discountEditURL }
    }

    return res.status(200).json({
      existingDiscount: discountNodeData
    });

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
};

/**
 * Getting the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const details = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Getting the details of the discount
    const createResponse = await graphqlClient.query({
      data: {
        query: `query discountNodesDetails($shopifyStoreDiscountId: ID!)  {
          discountNode(id:$shopifyStoreDiscountId){
            id
            discount {
              ... on DiscountAutomaticApp {
                title
              }
            }
            metafield(namespace: "$app:prepaid-discount",key: "function-configuration") {
              id
              value
            }
          }
        }`,
        variables: {
          shopifyStoreDiscountId: `gid://shopify/DiscountAutomaticNode/${payload.id}`
        }
      },
    });

    let discountDetails = createResponse.body.data?.discountNode;
    if (handleUserError(discountDetails.userErrors, res)) {
      return;
    }

    return res.status(200).json(discountDetails);

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
};

/**
 * Updating the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const update = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Updating the payment reorder for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation discountAutomaticAppUpdate($automaticAppDiscount: DiscountAutomaticAppInput!, $id: ID!) {
          discountAutomaticAppUpdate(automaticAppDiscount: $automaticAppDiscount, id: $id) {
            automaticAppDiscount {
              title
            }
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "automaticAppDiscount": {
            "title": payload.data.title,
            "metafields": [
              {
                "id": payload.data.metafieldId,
                "value": JSON.stringify({
                  uptoAmount: payload.data.uptoAmount,
                  percentage: payload.data.discountPercentage,
                })
              }
            ]
          },
          "id": `gid://shopify/DiscountAutomaticNode/${payload.data.id}`
        }
      }
    });

    return res.status(200).json(createResponse).send();

    let createResult = createResponse.body.data.metafieldsSet;
    if (handleUserError(createResult.userErrors, res)) {
      return;
    }
  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
  
  return res.status(200).send();
};