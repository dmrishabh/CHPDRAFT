// import { getDataFromCouponResponseJson } from "./CouponGraphQLQuery.js";
import { updateBillingTransaction } from "../billing";
// const successResp = {
//     "data": {
//       "codeDiscountNode": {
//         "codeDiscount": {
//           "basicDiscount": "ORDER",
//           "codes": {
//             "nodes": [
//               { 
//                 "code": "1T28YHHDPBPP"
//               }
//             ]
//           },
//           "asyncUsageCount": 0,
//           "codeCount": 1,
//           "title": "DYDF7ACM4K09",
//           "summary": "5% off one-time purchase products • Minimum purchase of ₹500.00 • For 2 customers",
//           "customerGets": {
//             "appliesOnOneTimePurchase": true,
//             "appliesOnSubscription": false,
//             "items": {
//               "allItems": true
//             },
//             "value": {
//               "percentage": 0.05
//             }
//           },
//           "minimumRequirement": {
//             "greaterThanOrEqualToSubtotal": {
//               "amount": "500.0"
//             }
//           }
//         }
//       }
//     },
//     "extensions": {
//       "cost": {
//         "requestedQueryCost": 30,
//         "actualQueryCost": 6,
//         "throttleStatus": {
//           "maximumAvailable": 1000,
//           "currentlyAvailable": 994,
//           "restoreRate": 50
//         }
//       }
//     }
// };
// test("Basic Discount",() => {

//     const coupons = getDataFromCouponResponseJson(successResp);
//     console.log(coupons);
//     expect(coupons.customerGets.oneTimePurchese).toBe(true);
// });


// test("Check GraphQL Error",() => {

//     const data = {
//         "data": {
//           "codeDiscountNode": null
//         },
//         "extensions": {
//           "cost": {
//             "requestedQueryCost": 25,
//             "actualQueryCost": 1,
//             "throttleStatus": {
//               "maximumAvailable": 1000,
//               "currentlyAvailable": 999,
//               "restoreRate": 50
//             }
//           }
//         }
//     };
//     const coupons = getDataFromCouponResponseJson(data);
//     expect(coupons).toBe("Not Found Value.");
// });

// test("Shipping Rate Discount", () => {

//     const data = {
//       "data": {
//         "codeDiscountNode": {
//           "codeDiscount": {
//             "codes": {
//               "nodes": [
//                 {
//                   "code": "1T28YHHDPBPP"
//                 }
//               ]
//             },
//             "shippingDiscount": "SHIPPING",
//             "appliesOnOneTimePurchase": false,
//             "appliesOnSubscription": true,
//             "asyncUsageCount": 0,
//             "codeCount": 1,
//             "title": "PVG2RMQ64WJK",
//             "summary": "Free shipping on subscription products • Minimum purchase of ₹500.00 • For all countries • For 2 groups of customers • One use per customer",
//             "maximumShippingPrice": null,
//             "minimumRequirement": {
//               "greaterThanOrEqualToSubtotal": {
//                 "amount": "500.0"
//               }
//             },
//             "destinationSelection": {
//               "allCountries": true
//             }
//           }
//         }
//       },
//       "extensions": {
//         "cost": {
//           "requestedQueryCost": 30,
//           "actualQueryCost": 4,
//           "throttleStatus": {
//             "maximumAvailable": 1000,
//             "currentlyAvailable": 996,
//             "restoreRate": 50
//           }
//         }
//       }
//     };
//     const coupons = getDataFromCouponResponseJson(data);
//     console.log(coupons);
//     expect(coupons.codeCount).toBe(1);
// });

test("Test Billing Approval", () => {

  const shop = "sprite-checkout-extensions.myshopify.com";
  const billingData = {
    admin_graphql_api_id: "gid://shopify/AppSubscription/29642916138",
    name: "Basic",
    status: "ACTIVE",
    admin_graphql_api_shop_id: "gid://shopify/Shop/72898969898",
    created_at: "2023-06-16T10:18:04-04:00",
    updated_at: "2023-06-16T10:18:12-04:00",
    currency: "USD",
    capped_amount: "300.0"
  };
  const resp = updateBillingTransaction(shop, billingData);
  console.log(resp);
  expect(1).toBe(1);

})