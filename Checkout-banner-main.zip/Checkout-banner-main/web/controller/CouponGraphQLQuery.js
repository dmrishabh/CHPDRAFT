

// # TODO: Pagination 
// fragment discountCollections on DiscountCollections {
//   collections(first: 10) {
//     nodes {
//       title
//       id
//     }
//   }
// }

// # TODO: Pagination 
// fragment discountProducts on DiscountProducts {
//   products(first: 10) {
//     nodes {
//       id
//       title
//     }
//   }
//   productVariants(first: 10) {
//     nodes {
//       id
//       title
//     }
//   }
// }

export const COUPON_DETAILS_QUERY = (id) => `
fragment discountMinimumRequirement on DiscountMinimumRequirement {
  ... on DiscountMinimumQuantity {
    greaterThanOrEqualToQuantity
  }
  ... on DiscountMinimumSubtotal {
    greaterThanOrEqualToSubtotal {
      amount
    }
  }
}
fragment allDiscountItems on AllDiscountItems {
  allItems
}
{
  codeDiscountNode(id: "${id}") {
    	codeDiscount {
        ... on DiscountCodeBasic {
          basicDiscount: discountClass
          asyncUsageCount
          codeCount
          title
          summary
          codes(first:1){
            nodes{
              code
            }
          }
          customerGets {
            appliesOnOneTimePurchase
            appliesOnSubscription
            items {
              ...allDiscountItems
            }
            value {
              ... on DiscountAmount {
                appliesOnEachItem
              }
              ... on DiscountPercentage {
                percentage
              }
            }
          }
          minimumRequirement {
          	...discountMinimumRequirement
          }
        }
        ... on DiscountCodeFreeShipping {
          shippingDiscount: discountClass
          appliesOnOneTimePurchase
          appliesOnSubscription
          asyncUsageCount
          codeCount
          title
          summary
          codes(first:1){
            nodes{
              code
            }
          }
          maximumShippingPrice {
            amount
          }
          minimumRequirement {
          	...discountMinimumRequirement
          }
          destinationSelection {
            ... on DiscountCountries {
             	countries 
              includeRestOfWorld
            }
            ... on DiscountCountryAll {
              allCountries
            }
        	}
        }
      }
   }
}
`;

/**
 * Extract data from coupon json
 * 
 * @param {*} resp
 */
export const getDataFromCouponResponseJson = (resp) => {

  //Check GraphQL Error 
  if(resp.errors){

    console.log(resp.errors);
    return "Error Encoundered.";
  };

  // Check Not Found Value
  if(!resp.data.codeDiscountNode){
    return "Not Found Value.";
  }

  resp = resp.data.codeDiscountNode.codeDiscount;
  const data = {
    usedCount: resp.asyncUsageCount,
    codeCount: resp.codeCount,
    code: resp.codes.nodes[0].code
  };
  data["coupon_rule"] = {
    discountType: resp.basicDiscount ?? resp.shippingDiscount,
    customerGets: resp?.customerGets,
    maximumShippingPrice: resp?.maximumShippingPrice,
    minimumRequirement: resp?.minimumRequirement,
    destinationSelection: resp?.destinationSelection
  }
  return data;
}