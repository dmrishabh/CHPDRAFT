import { PlanModel } from "../models/PlanModel.js"
import { respondError, respondInternalServerError, respondSuccess, respondWithData } from "../helper/Response.js";
import { BilledTransaction } from "../models/BilledTransaction.js";
import { validator } from "../helper/Validation.js";
import shopify from "../shopify.js";
import { GraphqlQueryError } from "@shopify/shopify-api";

//list view plans
export const listPlans = async (_req, _res, next) => {
    try {
        const plans = await PlanModel.find({});
        const session = _res.locals.shopify.session;

        let shopPlan = await BilledTransaction.findOne({ shop: session.shop, status: "ACTIVE" });
        let activePlan = await PlanModel.findOne({ planId: shopPlan.planId });

        _res.json(respondWithData("Plans", { plans, activePlan, viewCount: shopPlan.viewCount}));
    } catch (e) {
        return _res.json(respondInternalServerError())
    }
}

// GraphQL Query for updating the plan according to plan selected by the merchant
const CREATE_RECURRING_AND_USAGE_CHARGE = `
    mutation CreateRecurringAndUsageCharge($shop: URL!, $planName: String!,$recurringPlanAmount: Decimal!, $currencyCode: CurrencyCode!, $usagePlanCappedAmount: Decimal!, $usageTerms: String!, $isTest: Boolean!) {
      appSubscriptionCreate(
        name: $planName
        returnUrl: $shop
        lineItems: [
          {
            plan: {
              appRecurringPricingDetails: {
                price: { amount: $recurringPlanAmount, currencyCode: $currencyCode }
              }
            }
          },
          {
            plan: {
              appUsagePricingDetails: {
                cappedAmount: { amount: $usagePlanCappedAmount, currencyCode: $currencyCode }
                terms: $usageTerms
              }
            }
          }
        ]
        test: $isTest
      ) {
        appSubscription {
          id
          name
        }
        confirmationUrl
        userErrors {
          field
          message
        }
      }
    }
  `;

// GraphQL Query for getting the app handle its only required for ease on local development
const GET_APP_HANDLE = `
  query appSubscription {
    currentAppInstallation {
      app {
        handle
      }
    }
  }`;

export const getPlanBillingURL = async (session, planId) => {
  try {

    /* Call to DB to get the plan details */
    const planDetails = await PlanModel.findOne({ planId: planId });

    // Handle Error if plans are not found as you can't respond now to the frontend.
    if(!planDetails) {
      throw new Error( `Plan not found ${planId}`);
    }

    // Permanent URL on production
    let getAppHandle = 'custom-banner-2';

    const client = new shopify.api.clients.Graphql({ session });

    /* To Dynamically get the app handle. This can be hard coded for faster execution on production
      * To use during development machine below query is used
      */
    if(process.env.NODE_ENV !== 'production') {
      const getAppHandleQuery = await client.query({
        data: {
          query: GET_APP_HANDLE
        }
      });
      getAppHandle = getAppHandleQuery.body.data.currentAppInstallation.app.handle;
    }

    const response = await client.query({
        data: {
            query: CREATE_RECURRING_AND_USAGE_CHARGE,
            variables: {
                planName: planDetails.planName,
                currencyCode: planDetails.currencyCode,
                recurringPlanAmount: planDetails.planPrice,
                usagePlanCappedAmount: planDetails.cappedAmount,
                usageTerms: planDetails.usageTerms,
                isTest: process.env.NODE_ENV !== "production",
                shop: `https://${session.shop}/admin/apps/${getAppHandle}`
            },
        }
    });

    const data = response.body.data;
    const chargeRedirectURL = data?.appSubscriptionCreate?.confirmationUrl || ''


    /* Return the Bill URL for the store */
    return {
      success: true,
      url: chargeRedirectURL,
    };

  } catch (error) {
    if (error instanceof GraphqlQueryError) {
        throw new Error(
            `${error.message}\n${JSON.stringify(error.response, null, 2)}`
        );
    } else {
        throw error;
    }
  }
}

/*
 * NEED TO OPTIMIZE THE CODE
 * This function is used for updating the merchant plan to the given named plan.
 * This function will only work to upgrade or downgrade.
 * This function will not work for the free plan as of now which need to be done manually.
*/
export const updatePlan = async (_req, _res, next) => {
    try {
        const planId = _req.params.plan;
        const session = _res.locals.shopify.session;

        let data = await getPlanBillingURL(session,planId);
        _res.json(data);

    } catch (e) {
        return _res.json(respondInternalServerError())
    }
}

/* 
 * This function is for the validating the plans requested for update are paid ones
 * Update this to later support the downgrading to the free plan.
 */
export const validateUpdatePlan = async (_req, _res, next) => {
    console.log(_req.params.plan)
    const rules = {
        plan: 'not_in:free'
    };
    await validator(_res, next, _req.params, rules, {});
}

/**
 * Deactivate all the functionaliy after installation
 *
 * @param {*} shop
 * @param {*} body
 */
export const handleAppUnistallation = async (shop, body) => {
  // App uninstall also delete their billing as shopify does't create billing automatically.
  await BilledTransaction.deleteOne(
    { shop }
  ).lean();
};