import shopify from "../shopify.js";
import { GraphqlQueryError } from "@shopify/shopify-api";

// Helper function for handling any user-facing errors in GraphQL responses
function handleUserError(userErrors, res) {
  if (userErrors && userErrors.length > 0) {
    const message = userErrors.map((error) => error.message).join(' ');
    res.status(500).send({ error: message });
    return true;
  }
  return false;
}

/**
 * Creating the function dynamically
 *
 * @param {*} req
 * @param {*} res
 */
export const create = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  // return res.status(200).json(payload).send();

  try {
    // Create the payment reorder for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation PaymentCustomizationCreate($input: PaymentCustomizationInput!) {
          paymentCustomizationCreate(paymentCustomization: $input) {
            paymentCustomization {
              id
            }
            userErrors {
              message
            }
          }
        }`,
        variables: {
          input: {
            functionId: payload.functionId,
            title: `Reorder Payment Gateway`,
            enabled: true,
          },
        }
      },
    });


    let createResult = createResponse.body.data.paymentCustomizationCreate;
    if (handleUserError(createResult.userErrors, res)) {
      return;
    }

    // Populate the function configuration metafield for the payment reorder
    const reorderId = createResult.paymentCustomization.id;
    const metafieldResponse = await graphqlClient.query({
      data: {
        query: `mutation MetafieldsSet($reorderId: ID!, $configurationValue: String!) {
          metafieldsSet(metafields: [
            {
              ownerId: $reorderId
              namespace: "$app:payment-reorder"
              key: "function-configuration"
              value: $configurationValue
              type: "json"
            }
          ]) {
            metafields {
              id
            }
            userErrors {
              message
            }
          }
        }`,
        variables: {
          reorderId,
          configurationValue: JSON.stringify({
            paymentGatewayOrder: payload.paymentGatewayOrder
          })
        }
      }
    });

    let metafieldResult = metafieldResponse.body.data.metafieldsSet;

    if (handleUserError(metafieldResult, res)) {
      return;
    }
  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }

  return res.status(200).json().send();
};


/**
 * Check the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const check = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  const appFunctionId = payload.functionId;

  // get the current function created by the app.
  try {
    const createResponse = await graphqlClient.query({
      data: {
        query: `{
          paymentCustomizations(first: 1, query:"function_id:'${appFunctionId}'") {
            # PaymentCustomizationConnection fields
            nodes {
              id
              functionId
              shopifyFunction {
                appBridge {
                  detailsPath
                }
              }
              metafield(namespace: "$app:payment-reorder",key:"function-configuration") {
                value
              }
            }
          }
        }`
      }
    });

    let functionsDetails = createResponse.body.data.paymentCustomizations?.nodes;
    if (handleUserError(functionsDetails.userErrors, res)) {
      return;
    }

    let storeFunctionEditURL = null;
    let functionConfiguration = "{}"; // This data is going to be parsed to json in frontend so default is a string for json

    if(!!functionsDetails.length) {
      const storeFunctionID = (functionsDetails[0].id).replace('gid://shopify/PaymentCustomization/','') || null
      storeFunctionEditURL = (functionsDetails[0]?.shopifyFunction?.appBridge?.detailsPath)
      .replace(':functionId',appFunctionId)
      .replace(':id',storeFunctionID) || null;
      functionConfiguration = functionsDetails[0].metafield.value;
    }

    return res.status(200).json({
      isFunctionAlreadyCreated: !!functionsDetails.length,
      storeFunctionEditURL: storeFunctionEditURL,
      functionConfiguration: functionConfiguration,
    });

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
};


/**
 * Getting the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const details = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Getting the details of the function metafield data
    const createResponse = await graphqlClient.query({
      data: {
        query: `query paymentCustomizations($shopifyStoreFunctionId: ID!) {
          paymentCustomization(id: $shopifyStoreFunctionId) {
            id
            metafield(namespace: "$app:payment-reorder",key: "function-configuration") {
              value
            }
          }
        }`,
        variables: {
          shopifyStoreFunctionId: `gid://shopify/PaymentCustomization/${payload.id}`
        }
      },
    });

    let createResult = createResponse.body.data.paymentCustomization;
    if (handleUserError(createResult.userErrors, res)) {
      return;
    }

    return res.status(200).json(createResult);
  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
};

/**
 * Updating the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const update = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Updating the payment reorder for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation MetafieldsSet($ownerId: ID!, $configurationValue: String!) {
          metafieldsSet(metafields: [
            {
              ownerId: $ownerId
              namespace: "$app:payment-reorder"
              key: "function-configuration"
              value: $configurationValue
              type: "json"
            }
          ]) {
            metafields {
              id
            }
            userErrors {
              message
            }
          }
        }`,
        variables: {
          ownerId: payload.functionID,
          configurationValue: JSON.stringify({
            paymentGatewayOrder: payload.paymentGatewayOrder
          })
        }
      }
    });

    let createResult = createResponse.body.data.metafieldsSet;
    if (handleUserError(createResult.userErrors, res)) {
      return;
    }
  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
  
  return res.status(200).send();
};