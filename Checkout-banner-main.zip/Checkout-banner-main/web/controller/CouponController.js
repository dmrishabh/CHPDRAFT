import { createUsageRecord } from "../billing.js";
import logger from "../helper/Logger.js";
import { respondError, respondInternalServerError, respondSuccess, respondWithData } from "../helper/Response.js";
import { validator } from "../helper/Validation.js";
import { Coupon } from "../models/Coupon.js";
import { RuleList } from "../models/RuleList.js";
import { viewCount } from "../models/ViewCount.js";
import { BilledTransaction } from "../models/BilledTransaction.js";
import shopify from "../shopify.js";
import { COUPON_DETAILS_QUERY, getDataFromCouponResponseJson } from "./CouponGraphQLQuery.js";
import { PlanModel } from "../models/PlanModel.js";

/**
 * Perform on the coupon part
 * 
 * Dev: Birendra
 */

/**
 * Generate GL Query to fetch the coupon code
 * 
 * @param {*} query 
 * @returns 
 */

const generateQuery = (query) => `{
    codeDiscountNodes(
        first: 5,
        query: ${query}
    ) {
      edges {
        node {
          id,
          codeDiscount {
            ... on DiscountCodeBasic {
              codeCount
              title
              shortSummary
              codes(first:1){
                nodes{
                  code
                }
              }
            }
            ... on DiscountCodeFreeShipping{
              codeCount,
              title,
              shortSummary
              codes(first:1){
                nodes{
                  code
                }
              }
            }
          }
        }
      }
   }
}`;

/**
 * Fetch coupon from the shopify
 * 
 * @param {*} session 
 * @param {*} query 
 * @returns 
 */
export const fetchCouponFromShopify = async (session, query) => {

  const GQL = new shopify.api.clients.Graphql({ session });
  const gQuery = generateQuery(query);

  //console.log(gQuery);
  let resp = await GQL.query({
    data: { query: gQuery }
  }).catch(err => {

    console.log(JSON.stringify(err));
    return null;
  });

  // console.log(resp.body.data);
  if (resp.errors) {

    console.log(resp.errors);
    return null;
  };

  const result = resp.body.data.codeDiscountNodes.edges.map((edge) => {

    return {
      id: edge.node.id,
      title: edge.node.codeDiscount.title,
      code: edge.node.codeDiscount.codes.nodes[0].code,
      summery: edge.node.codeDiscount.shortSummary,
      codeCount: edge.node.codeDiscount.codeCount
    };
  });
  return result;
}

/**
 * Validate Coupon Query Request
 * 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
export const validateCouponQuery = async (req, res, next) => {

  const validationRule = { "text": "string" };
  await validator(res, next, req.body, validationRule, {});
}

/**
 * Handle fetch coupon data from the shopify
 * 
 * @param {*} req 
 * @param {*} res 
 * @returns 
 */
export const handleCouponQuery = async (req, res) => {

  try {

    let { text } = req.query;
    const usedCount = text == undefined ? 2 : 0;
    text = text ? `${text}*` : "*";
    const session = res.locals.shopify.session;
    const query = `"title:${text} status:active times_used>:${usedCount}"`;
    const data = await fetchCouponFromShopify(session, query);
    return res.json({
      success: true,
      data: data
    });
  } catch (error) {

    console.log(error);
    return res.json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

/**
 * Handle event to fetch the applicable discount code list from the middleware
 * 
 * @param {*} req 
 * @param {*} res 
 * @returns 
 */
export const handleFetchCouponList = async (req, res) => {

  try {

    const { shop } = res.locals.shopify.session;
    const coupon = await Coupon.find({ status: "Active", shop: shop }, { "coupon_rule.customerGets": false }).limit(20);
    return res.json(respondWithData("Coupon List", coupon));
  } catch (error) {

    console.log(error);
    return res.json(respondInternalServerError());
  }
}

/**
 * Handle event to fetch the Rule List from the middleware
 * 
 * @param {*} req 
 * @param {*} res 
 * @returns 
 */
export const handleFetchRuleList = async (req, res) => {

  return RuleList.find({}, { name: true, id: true })
    .then(resp => res.json({
      success: true,
      data: resp
    }))
    .catch(err => {

      console.log(err);
      return res.json({
        success: false,
        message: "Internal Server Error"
      });
    });
}

/**
 * Fetch Coupon Data from shopify
 * 
 * @returns 
 */
const fetchCouponDetailsFromShopify = async (session, id) => {

  const GQL = new shopify.api.clients.Graphql({ session });
  const gQuery = COUPON_DETAILS_QUERY(id);

  console.log(gQuery);
  const resp = await GQL.query({
    data: { query: gQuery }
  }).catch(err => {

    console.log("GQL Error", JSON.stringify(err));
    return null;
  });

  console.log(resp.body);
  return getDataFromCouponResponseJson(resp.body);
}

/**
 * Validate Add Coupon Request
 * 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 */
export const validateAddCoupon = async (_req, _res, next) => {

  const rules = {
    "gid": "required|string",
    "title": "string|required",
    "status": "string|in:Active,Deactivate",
    "subtitle": "string|required"
  };
  await validator(_res, next, _req.body, rules, {});
}

/**
 * Handle add discount code request
 * 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 * @returns 
 */
export const handleAddCoupon = async (_req, _res, next) => {

  try {

    const { gid } = _req.body;
    //fetch other data
    const session = _res.locals.shopify.session;
    const details = await fetchCouponDetailsFromShopify(session, gid);
    if (details == "Error Encoundered." || details == "Not Found Value.") {

      return _res.json(respondError("Getting Error While Fetching Coupon Details"));
    }
    await Coupon.updateOne({ gid }, { ..._req.body, shop: session.shop, ...details }, { upsert: true });
    return _res.json(respondSuccess("Coupon Saved Successfully.."));
  } catch (error) {

    logger.info(error);
    return _res.json(respondInternalServerError());
  }
}

/**
 * Validate View Coupon Request
* 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 */
export const validateViewCoupon = async (_req, _res, next) => {

  const rules = {
    "id": "required|string"
  };
  await validator(_res, next, _req.query, rules, {});
}

/**
 * Handle View discount code request
 * 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 * @returns 
 */
export const handleViewCoupon = async (_req, _res, next) => {

  try {

    const { id } = _req.query;
    //fetch other data
    const coupon = await Coupon.findOne({ _id: id });
    return _res.json(respondWithData("Coupon Details", coupon));
  } catch (error) {

    console.log(error);
    return _res.json(respondInternalServerError());
  }
}

/**
 * Validate List Coupon Request
 * 
 * @param {*} _req
 * @param {*} _res
 * @param {*} next
 */
export const validateListCoupon = async (_req, _res, next) => {

  const rules = {
    "page": "required|integer",
    "limit": "required|integer"
  };
  await validator(_res, next, _req.query, rules, {});
}

/**
 * Handle List discount code request
 * 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 * @returns 
 */
export const handleListCoupon = async (_req, _res, next) => {

  try {

    const { page, limit } = _req.query;
    // fetch other data
    const skip = parseInt(page - 1) * parseInt(limit);
    const { shop } = _res.locals.shopify.session;
    const coupon = await Coupon.find({ shop }).skip(skip).limit(limit);
    const total = await Coupon.countDocuments({ shop });
    return _res.json(respondWithData("Coupon Details", { coupon, total }));
  } catch (error) {

    logger.info(error);
    return _res.json(respondInternalServerError());
  }
}


/**
 * Validationf or the page View
 * 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 */
export const validatePageViewed = async (_req, _res, next) => {

  console.log(_req.body, _req.query, _req.param);
  const rules = { "token": "required|string" };
  await validator(_res, next, _req.body, rules, {});
}

/**
 * Handle Page View API
 * 
 * @param {*} _req 
 * @param {*} _res 
 * @param {*} next 
 * @returns 
 */
export const handlePageViewed = async (_req, _res, next) => {
  try {
    const { token } = _req.body;
    const { shop } = _res.locals.shopify.session;
    const addViewToDB = await viewCount.updateOne({ token, shop }, { token, shop }, { upsert: true });

    if (addViewToDB.upsertedCount) {
      const isStoreHaveView = await checkBillingTransaction(_res.locals.shopify.session);
      if (!isStoreHaveView) {
        return _res.json(respondError(""))
      }
      return _res.json(respondSuccess());
    }
  } catch (error) {
    logger.error(error);
    return _res.json(respondInternalServerError());
  }
}

export async function checkBillingTransaction(session) {
  try {
    // If Shop is not created create the shop on free plan
    // TODO : Check the below line is required or not
    await BilledTransaction.updateOne({ shop: session.shop }, { shop: session.shop }, { upsert: true });
    const transactionDetails = await BilledTransaction.findOne({ shop: session.shop });

    if (transactionDetails.viewCount < transactionDetails.viewLimit) {
      await BilledTransaction.updateOne({ shop: session.shop }, {
        $inc: {
          viewCount: +1,
        }
       });
      return true;
    } else if (transactionDetails.viewCount >= transactionDetails.viewLimit && transactionDetails.planId != 'free') {

      // check billing date or planname to stop
      let planDetailsOfShopifyStore = await PlanModel.findOne({ planId: transactionDetails.planId });
      const costPerView = parseFloat( planDetailsOfShopifyStore.costPerView || 0.01 );

      // Have to charge merchant based on the usage fee
      await createUsageRecord(session,planDetailsOfShopifyStore);

      await BilledTransaction.updateOne({ shop: session.shop }, {
        $inc: {
          extraViewCount: +1,
          viewCount: +1,
          extraViewCharge: +costPerView
        }
      });

      return true
    } else if (transactionDetails.viewCount >= transactionDetails.viewLimit && transactionDetails.planId == 'free'){
      return false;
    }
  } catch (error) {
    throw new Error(error);
  }
}
