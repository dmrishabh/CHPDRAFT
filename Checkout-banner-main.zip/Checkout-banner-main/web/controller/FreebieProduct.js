import shopify from "../shopify.js";
import { GraphqlQueryError } from "@shopify/shopify-api";
import { FreebieDiscount } from "../models/FreebieDiscount.js";

// Helper function for handling any user-facing errors in GraphQL responses
function handleUserError(userErrors, res) {
  if (userErrors && userErrors.length > 0) {
    const message = userErrors.map((error) => error.message).join(' ');
    res.status(500).send({ error: message });
    return true;
  }
  return false;
}

/**
 * Creating app basic coupon
 *
 * @param {*} req
 * @param {*} res
 */
export const createAppBasicCoupon = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  // return res.status(200).json(req.body).send();

  try {
    // Create the payment reorder for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation discountCodeAppCreate($codeAppDiscount: DiscountCodeAppInput!) {
          discountCodeAppCreate(codeAppDiscount: $codeAppDiscount) {
            codeAppDiscount {
              # DiscountCodeApp fields
              discountId
            }
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "codeAppDiscount": {
            "appliesOncePerCustomer": false,
            "code": payload.discountTitle,
            "combinesWith": {
              "orderDiscounts": true,
              "productDiscounts": true,
              "shippingDiscounts": true
            },
            "customerSelection": {
              "all": true
            },
            "startsAt": payload.startsAt,
            "functionId": payload.functionId,
            "metafields": [
              {
                "description": "For the freebie product configuration values",
                "key": "function-configuration",
                "namespace": "$app:freebie-discount",
                "type": "json",
                "value": JSON.stringify({
                  appliesTo: payload.appliesTo,
                  purchaseAmount: payload.purchaseAmount,
                  purchaseQuantity: payload.purchaseQuantity,
                  selectedProducts: payload.selectedProducts,
                  selectedCollections: payload.selectedCollections,
                  selectedGetProducts: payload.selectedGetProducts
                })
              }
            ],
            "title": payload.discountTitle,
            "usageLimit": null
          }
        }
      }
    });

    const discountDataResponse = createResponse.body.data.discountCodeAppCreate;

    // Save the discount data to DB for reference
    // TODO: FUTURE: Make the below function common for both
    // TODO: FUTURE:  If DB entry Fail Delete the coupon create and send error
    if(discountDataResponse && discountDataResponse.hasOwnProperty('codeAppDiscount')){
      let discountData = discountDataResponse.codeAppDiscount;
      if(discountData && discountData.discountId) {
        await FreebieDiscount.updateOne({ discountId: discountData.discountId }, {
          shop: session.shop,
          discountId: discountData.discountId,
          ...payload
        }, { upsert: true });
      }
    }

    return res.status(200).json(createResponse);

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }

  return res.status(200).json().send();
};

/**
 * Creating app automatic coupon
 *
 * @param {*} req
 * @param {*} res
 */
export const createAppAutomaticCoupon = async (req, res) => {
  const payload = req.body;
  const session = res.locals.shopify.session;

  const graphqlClient = new shopify.api.clients.Graphql({
    session
  });

  // return res.status(200).json(req.body).send();

  try {
    // Create the payment reorder for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation discountAutomaticAppCreate($automaticAppDiscount: DiscountAutomaticAppInput!) {
          discountAutomaticAppCreate(automaticAppDiscount: $automaticAppDiscount) {
            automaticAppDiscount {
              discountId
            }
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "automaticAppDiscount": {
            "combinesWith": {
              "orderDiscounts": true,
              "productDiscounts": true,
              "shippingDiscounts": true
            },
            "functionId": payload.functionId,
            "metafields": [
              {
                "description": "For the freebie product configuration values",
                "key": "function-configuration",
                "namespace": "$app:freebie-discount",
                "type": "json",
                "value": JSON.stringify({
                  appliesTo: payload.appliesTo,
                  purchaseAmount: payload.purchaseAmount,
                  purchaseQuantity: payload.purchaseQuantity,
                  selectedProducts: payload.selectedProducts,
                  selectedCollections: payload.selectedCollections,
                  selectedGetProducts: payload.selectedGetProducts
                })
              }
            ],
            "startsAt": payload.startsAt,
            "title": payload.discountTitle,
          }
        }
      }
    });

    const discountDataResponse = createResponse.body.data.discountAutomaticAppCreate;

    // Save the discount data to DB for reference
    // TODO: FUTURE: Make the below function common for both
    // TODO: FUTURE:  If DB entry Fail Delete the coupon create and send error
    if(discountDataResponse && discountDataResponse.hasOwnProperty('automaticAppDiscount')){
      let discountData = discountDataResponse.automaticAppDiscount;
      if(discountData && discountData.discountId) {
        await FreebieDiscount.updateOne({ discountId: discountData.discountId }, {
          shop: session.shop,
          discountId: discountData.discountId,
          ...payload
        }, { upsert: true });
      }
    }

    return res.status(200).json(createResponse);

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }

  return res.status(200).json().send();
};



/**
 * Getting All the freebie coupon for the store
 *
 * @param {*} req
 * @param {*} res
 */
export const getAllFreebieCoupons = async (req, res) => {
  const session = res.locals.shopify.session;

  try {
    const FreebieDiscounts = await FreebieDiscount.find({ shop: session.shop });
    return res.status(200).json(FreebieDiscounts);
  } catch (error) {
    return res.status(204).json(error);
  }
};


/**
 * Getting the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const details = async (req, res) => {
  const payload = req.body;
  const session = res.locals.shopify.session
  const graphqlClient = new shopify.api.clients.Graphql({
    session: session
  });

  try {
    // Getting the details of the discount from the DB
    // const getDiscountDetailsFromDB = await FreebieDiscount.findOne({ 
    //   shop: session.shop ,
    //   // Find either it is a automatic discount or basic discount
    //   discountId: { $in: [`gid://shopify/DiscountAutomaticNode/${payload.id}`, `gid://shopify/DiscountCodeNode/${payload.id}`] } 
    // });

    // return res.status(200).json(getDiscountDetailsFromDB);

    const createResponse = await graphqlClient.query({
      data: {
        query: `query discountNodesDetails($shopifyStoreDiscountId: ID!)  {
          discountNode(id:$shopifyStoreDiscountId){
            id
            discount {
              ... on DiscountAutomaticApp {
                title
              }
              ... on DiscountCodeApp {
                title
              }
            }
            metafield(namespace: "$app:freebie-discount",key: "function-configuration") {
              id
              value
            }
          }
        }`,
        variables: {
          // We are only handling the automatic coupon for now
          shopifyStoreDiscountId: `gid://shopify/DiscountAutomaticNode/${payload.id}`
        }
      },
    });

    let discountDetails = createResponse.body.data?.discountNode;
    if (handleUserError(discountDetails.userErrors, res)) {
      return;
    }

    return res.status(200).json(discountDetails);

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
};

/**
 * Updating the function details
 *
 * @param {*} req
 * @param {*} res
 */
export const update = async (req, res) => {
  const payload = req.body;
  const session = res.locals.shopify.session;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: session
  });

  try {
    // Updating the payment reorder for the provided function ID
    const createResponse = await graphqlClient.query({
      data: {
        query: `mutation discountAutomaticAppUpdate($automaticAppDiscount: DiscountAutomaticAppInput!, $id: ID!) {
          discountAutomaticAppUpdate(automaticAppDiscount: $automaticAppDiscount, id: $id) {
            automaticAppDiscount {
              discountId
            }
            userErrors {
              field
              message
            }
          }
        }`,
        variables: {
          "automaticAppDiscount": {
            "title": payload.discountTitle,
            "metafields": [
              {
                "id": payload.metafieldId,
                "value": JSON.stringify({
                  appliesTo: payload.appliesTo,
                  purchaseAmount: payload.purchaseAmount,
                  purchaseQuantity: payload.purchaseQuantity,
                  selectedProducts: payload.selectedProducts,
                  selectedCollections: payload.selectedCollections,
                  selectedGetProducts: payload.selectedGetProducts
                })
              }
            ]
          },
          "id": `gid://shopify/DiscountAutomaticNode/${payload.id}`
        }
      }
    });

    const discountDataResponse = createResponse.body.data.discountAutomaticAppUpdate;
    // return res.status(200).json(discountDataResponse);

    // Update the discount data to DB for reference
    // TODO: FUTURE: Make the below function common for both
    // TODO: FUTURE:  If DB entry Fail Delete the coupon create and send error
    if(discountDataResponse && discountDataResponse.hasOwnProperty('automaticAppDiscount')){
      let discountData = discountDataResponse.automaticAppDiscount;
      if(discountData && discountData.discountId) {
        await FreebieDiscount.updateOne({ discountId: discountData.discountId }, {
          shop: session.shop,
          discountId: discountData.discountId,
          ...payload
        }, { upsert: true });
      }
    }

    return res.status(200).json(createResponse);

    let createResult = createResponse.body.data.metafieldsSet;
    if (handleUserError(createResult.userErrors, res)) {
      return;
    }
  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
  
  return res.status(200).send();
};

// TODO : FUTURE : Change this to specific query to avoid hacking 
// Too Open For Any Query
export const query = async (req, res) => {
  const payload = req.body;
  const graphqlClient = new shopify.api.clients.Graphql({
    session: res.locals.shopify.session
  });

  try {
    // Avoid graphql query with mutation requests
    if(payload.queryWithVariable && JSON.stringify(payload.queryWithVariable).includes('mutation')) {
      return res.status(401).send({ error: "Mutation can't be processed" });
    }

    // Getting the details of the discount
    const queryResponse = await graphqlClient.query({
        data: payload.queryWithVariable
    });

    return res.status(200).json(queryResponse.body.data);

  } catch (error) {
    // Handle errors thrown by the graphql client
    if (!(error instanceof GraphqlQueryError)) {
      throw error;
    }
    return res.status(500).send({ error: error.response });
  }
}