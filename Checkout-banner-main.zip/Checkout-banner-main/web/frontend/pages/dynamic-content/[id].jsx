import React, { useState, useEffect, useCallback } from "react";
import {
  Card,
  Page,
  Button,
  Form,
  FormLayout,
  TextField,
  Layout,
  Stack,
  RadioButton,
  TextContainer,
  EmptySearchResult,
  Modal,
  Listbox,
  Toast,
  Frame
} from "@shopify/polaris";
import {IndexTable, Badge} from '@shopify/polaris';
import { CirclePlusMinor, DuplicateMinor, ExternalMinor, DeleteMinor } from "@shopify/polaris-icons";
import { ConditionsSelector } from "../../components/ConditionsSelector";
import { SupportFooter } from "../../components/supportFooter";
import { useAuthenticatedFetch } from "../../hooks";
import { useParams } from 'react-router-dom';
import { Redirect } from "@shopify/app-bridge/actions";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useNavigate } from "react-router-dom";

const MAX_CONDITION_CAN_CREATE = 6;

// A utility hook for getting the details for the forms
function useGetBlocks() {
  const fetch = useAuthenticatedFetch();
  return async () => {
    return await fetch("/api/dynamicContent/details", {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });
  }
}

// A utility hook for invoking the server endpoint that create form
function useUpdateBlock() {
  const fetch = useAuthenticatedFetch();
  return async (customBanner) => {
    try {
      const res = await fetch("/api/dynamicContent/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customBanner),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// A utility hook for deleting specified the forms
function useDeleteDynamicBlock() {
  const fetch = useAuthenticatedFetch();
  return async (dynamicBlockToDelete) => {
    return await fetch("/api/dynamicContent/delete", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dynamicBlockToDelete)
    });
  }
}

// A utility hook for redirecting back to the checkout theme customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

// Generate a random 6-digit ID
function generateRandomID() {
  const min = 100000; // Minimum value for a 6-digit number
  const max = 999999; // Maximum value for a 6-digit number

  const randomID = Math.floor(Math.random() * (max - min + 1)) + min;

  return randomID.toString(); // Convert to string
}

export default function createCustomField() {
  const { id } = useParams();

  const getDynamicBlock = useGetBlocks();
  const updateDynamicBlock = useUpdateBlock();
  const deleteDynamicBlock = useDeleteDynamicBlock();
  const navigate = useNavigate();

  const redirectToCustomizations = useRedirectToCustomizations();

  const [blockName, setBlockName] = useState("Custom Block");
  const [blockID, setBlockID] = useState(generateRandomID());
  const [isLoading, setIsLoading] = useState(false);
  const [ruleSelection, setRuleSelection] = useState(false);
  const [selectedLogic, setSelectedLogic] = useState('and');
  const [conditions, setConditions] = useState([{ type: 'cart_quantity' }]);

  // Content Data for Banner
  const [bannerTitle, setBannerTitle] = useState("");
  const [bannerContent, setBannerContent] = useState("");

  const [blockData, setBlockData] = useState([]);

  const handleBlockNameChange = useCallback((value) => setBlockName(value), []);
  const handleChange = useCallback(() => setRuleSelection(!ruleSelection), [ruleSelection]);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const copiedActive = useCallback(() => setCopied((copied) => !copied), []);
  const savedActive = useCallback(() => setSaved((saved) => !saved), []);

  const copiedToastMarkup = copied ? (
    <Toast content="Copied" onDismiss={copiedActive} />
  ) : null;

  const savedToastMarkup = saved ? (
    <Toast content="Block Updated" onDismiss={savedActive} />
  ) : null;

  useEffect(async() => {
    setIsLoading(true);
    const response = await getDynamicBlock();
    const dataJSON = await response.json();
    setBlockData(dataJSON?.metafieldData || []);
    setIsLoading(false);
  },[]);

  // Make the form data as row
  useEffect(async() => {
    // Read the function ID from the URL
    const detailsForDynamicBlock = blockData.filter(block =>  block.id === id );

    if(detailsForDynamicBlock[0]){
      setBlockID(detailsForDynamicBlock[0].id || blockID);
      setBlockName(detailsForDynamicBlock[0].name || blockName);
      setSelectedLogic(detailsForDynamicBlock[0].conditionsType || selectedLogic );
      setConditions(detailsForDynamicBlock[0].conditions || []);

      setBannerTitle(detailsForDynamicBlock[0].contents[0].title || bannerTitle)
      setBannerContent(detailsForDynamicBlock[0].contents[0].content || bannerContent)
    }
  },[blockData]);

  // Copy Form ID to the clipboard
  const copyToClipboard = useCallback(async () => {
    if ("clipboard" in navigator) {
      await navigator.clipboard.writeText(blockID);
    } else {
      document.execCommand("copy", true, blockID);
    }
    copiedActive();
  },[blockID]);


  // Invoke the server endpoint when the form is submitted
  const handleSubmit = async () => {
    setIsLoading(true);
    let dynamicBlockDetails = {};

    // Assigning form a randomID
    dynamicBlockDetails.id = blockID;

    // Adding form Details as added by the merchants
    dynamicBlockDetails.name = blockName;
    dynamicBlockDetails.isActive = true;
    dynamicBlockDetails.updatedAt = Date.now();
    dynamicBlockDetails.conditionsType = selectedLogic;
    dynamicBlockDetails.conditions = conditions;
    dynamicBlockDetails.contents = [
      {
        type: "banner",
        title: bannerTitle,
        content: bannerContent,
        bannerType: "info",
        collapsible: false
      }
    ];

    await updateDynamicBlock(dynamicBlockDetails);
    // navigate("/dynamic-content/" + blockID);
    savedActive();
    setIsLoading(false);
  };

  // Handle Form Delete
  const handleDelete = async () => {
    setIsLoading(true);
    await deleteDynamicBlock({id: blockID});
    navigate('/dynamic-content/');
    setIsLoading(false);
  }

  const handleConditionAdd = (type) => {
    setConditions([...conditions, { type: type }]);
    handleChange();
  };

  const handleRemoveCondition = (index) => {
    const updatedConditions = [...conditions];
    updatedConditions.splice(index, 1);
    setConditions(updatedConditions);
  };

  const handleUpdateCondition = (index, updatedCondition) => {
    const updatedConditions = [...conditions];
    updatedConditions[index] = updatedCondition;
    setConditions(updatedConditions);
  };

  const resourceName = {
    singular: 'rule',
    plural: 'rules',
  };

  const emptyStateMarkup = (
    <EmptySearchResult
      title={'Block will be shown to all customers.'}
      description={'Try adding rule'}
      withIllustration
    />
  );

  const rowMarkup = conditions.map(
    (
      condition,
      index,
    ) => {
      if(condition.type) {
        return (
          <ConditionsSelector
            key={index}
            selectedLogic={selectedLogic}
            index={index}
            condition={condition}
            onUpdateCondition={ handleUpdateCondition }
            onRemoveCondition={ handleRemoveCondition }
          />
        )
      }
    }
  );

  return (
    <Frame>
      <Page
        breadcrumbs={[{ onAction: () => navigate("/dynamic-content/") }]}
        title="Add Dynamic Banner"
        subtitle="Manage the settings of the component that will be shown to customers."
        compactTitle
        primaryAction={
          <Stack
            alignment="center"
          >
            <Button
              plain
              destructive
              disabled={isLoading}
              icon={DeleteMinor}
              onClick={handleDelete}
            >
              Delete
            </Button>
            <Button primary onClick={handleSubmit} loading={isLoading}>
              Update
            </Button>
          </Stack>
        }
      >
        <Layout>
          <Layout.Section>
            <Card sectioned title="Dynamic Block Details">
              <TextField
                label="Dynamic Block ID"
                type="text"
                value={blockID}
                disabled
                autoComplete="off"
                helpText="Block wont be vissible until you add them in customizer"
                connectedRight={
                  <Stack spacing="tight">
                    <Button icon={DuplicateMinor} onClick={copyToClipboard} >Copy dynamic block ID</Button>
                    <Button icon={ExternalMinor} onClick={redirectToCustomizations}>Open Customizer</Button>
                  </Stack>
                }
              />
            </Card>
          </Layout.Section>
          <Layout.Section>
            <Form onSubmit={handleSubmit}>
              <FormLayout>
                <Card sectioned>
                  <Stack vertical spacing="loose">
                    <TextField
                      onChange={handleBlockNameChange}
                      label="Block name"
                      value={blockName}
                      helpText="This is for internal purpose only,Not shown to customer"
                      requiredIndicator={true}
                    />
                  </Stack>
                </Card>
                <Card sectioned title="Display rule">
                  <Card>
                    <Card.Section>
                      <Stack alignment="center">
                        <TextContainer>
                          Only show when
                        </TextContainer>
                        <RadioButton
                          label="All rules pass"
                          id="allRules"
                          checked={selectedLogic === 'and'}
                          onChange={() => setSelectedLogic('and')}
                        />
                        <RadioButton
                          label="Any rule passes"
                          id="anyRule"
                          checked={selectedLogic === 'or'}
                          onChange={() => setSelectedLogic('or')}
                        />
                      </Stack>
                    </Card.Section>
                    <IndexTable
                      resourceName={resourceName}
                      itemCount={conditions.length}
                      emptyState={emptyStateMarkup}
                      headings={[
                        {title: ''},
                        {title: 'Rule'},
                        {title: 'Condition'},
                        {title: 'Value'},
                        {title: 'Action', alignment: 'end'}
                      ]}
                      selectable={false}
                    >
                      {rowMarkup}
                    </IndexTable>
                    <Card.Section>
                      <Modal
                        activator={
                          <Button 
                            fullWidth 
                            disabled={conditions.length < MAX_CONDITION_CAN_CREATE ? false : true } 
                            icon={CirclePlusMinor} 
                            onClick={handleChange}
                          >
                            Add Rule
                          </Button>
                        }
                        open={ruleSelection}
                        onClose={handleChange}
                        title="Select a rule"
                      >
                        <Modal.Section>
                          <Listbox 
                            onSelect={handleConditionAdd} 
                            autoSelection={'NONE'}
                            accessibilityLabel="Select a rule from the list"
                          >
                            {/* <Listbox.Option value="product_collection">Product Collection</Listbox.Option> */}
                            <Listbox.Option value="product_vendor">Product Vendor</Listbox.Option>
                            <Listbox.Option value="cart_quantity">Cart Quantity</Listbox.Option>
                            <Listbox.Option value="cart_total">Cart Total</Listbox.Option>
                          </Listbox>
                        </Modal.Section>
                      </Modal>
                    </Card.Section>
                  </Card>
                </Card>
                <Card sectioned title="Content">
                  <Stack vertical spacing="loose">
                    <TextField
                      onChange={setBannerTitle}
                      label="Banner title"
                      value={bannerTitle}
                      requiredIndicator={true}
                    />
                    <TextField
                      onChange={setBannerContent}
                      label="Banner Content"
                      value={bannerContent}
                      requiredIndicator={true}
                    />
                  </Stack>
                </Card>
              </FormLayout>
            </Form>
          </Layout.Section>
          <Layout.Section>
            <Card sectioned >
              <FormLayout>
                {/* <Button fullWidth icon={CirclePlusMinor} onClick={handleAddField}>Add Field</Button> */}
                <Button fullWidth primary onClick={handleSubmit} loading={isLoading}>Update</Button>
              </FormLayout>
            </Card>
          </Layout.Section>
        </Layout>
        <SupportFooter />
        {copiedToastMarkup}
        {savedToastMarkup}
      </Page>
    </Frame>
  );
}