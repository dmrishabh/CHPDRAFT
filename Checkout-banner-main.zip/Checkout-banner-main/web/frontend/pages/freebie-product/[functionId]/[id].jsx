import React, { useState, useCallback, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ResourcePicker, useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAuthenticatedFetch } from "../../../hooks";
import { FormLayout, ResourceList, ResourceItem, TextContainer, Thumbnail, SkeletonThumbnail } from '@shopify/polaris';

import {
  Page,
  Layout,
  ChoiceList,
  TextField,
  Stack,
  Card,
  Form,
  Button,
  SkeletonPage,
  SkeletonBodyText,
} from "@shopify/polaris";
import { ImageMajor } from '@shopify/polaris-icons';
import { SupportFooter } from "../../../components/supportFooter.jsx";

// A utility hook for getting the details for the discount customization
function useGetCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (discountCustomization) => {
      return await fetch("/api/freebieProduct/details", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(discountCustomization),
      });
  }
}

// A utility hook for updating the function data
function useUpdateCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (discountCustomization) => {
      return await fetch("/api/freebieProduct/update", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(discountCustomization),
      });
  }
}

// A utility hook for invoking the server endpoint that create automatic coupon
function useGraphQLQuery() {
  const fetch = useAuthenticatedFetch();
  return async (GraphQLQuery) => {
    try {
      const res = await fetch("/api/freebieProduct/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(GraphQLQuery),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToDiscount() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/discounts",
    });
  };
}

// A utility hook for redirecting back to the checkout theme customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

export default function NewCustomizationPage() {
  // Read the function ID from the URL
  const { functionId, id } = useParams();

  // Utility hooks
  // const createAppBasicCoupon = useCreateAppBasicCoupon();
  // const createAppAutomaticCoupon = useCreateAppAutomaticCoupon();
  const redirectToDiscount = useRedirectToDiscount();
  const getCustomization = useGetCustomization();
  const updateCustomization = useUpdateCustomization();
  const GraphQLQuery = useGraphQLQuery();

  // Page state management
  const [isLoading, setIsLoading] = useState(false);
  const [automaticCouponTitle, setAutomaticCouponTitle] = useState("");
  const [discountCode, setDiscountCode] = useState("");
  const [openResourceSelector, setOpenResourceSelector] = useState(false);

  const [initialProduct, setInitialProduct] = useState([]);
  const [initialCollection, setInitialCollection] = useState([]);
  const [initialGetProduct, setInitialGetProduct] = useState([]);

  const [selectedProduct, setSelectedProduct] = useState([]);
  const [selectedCollection, setSelectedCollection] = useState([]);
  const [selectedGetProduct, setSelectedGetProduct] = useState([]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [openResourceGetSelector, setOpenResourceGetSelector] = useState(false);
  const [startAtTimeStamp, setStartAtTimeStamp] = useState(new Date());
  const [searchGetQuery, setSearchGetQuery] = useState('');
  const [discountType, setDiscountType] = useState(["manual"]);
  const [appliesTo, setAppliesTo] = useState(["Product"]);
  const [purchaseAmountValue, setPurchaseAmount] = useState('');
  const [purchaseQuantityValue, setPurchaseQuantity] = useState(1);
  const [metafieldId,setMetafieldId] = useState("");

  useEffect(async() => {
    setIsLoading(true);

    const response = await getCustomization({id});
    const dataJSON = await response.json();
    const configuration = JSON.parse(
      dataJSON?.metafield?.value ?? "{}"
    );

    console.log(dataJSON)

    if(configuration && dataJSON && dataJSON?.discount ){
      console.log(configuration)
      if (dataJSON.id.includes('DiscountAutomaticNode')) {
        setDiscountType(['automatic'])
        setAutomaticCouponTitle(dataJSON.discount.title)
      } else {
        setDiscountType(['manual'])
        setDiscountCode(dataJSON.discount.title)
      }

      setAppliesTo(configuration.appliesTo);

      if (configuration.appliesTo == 'Product') {
        setInitialProduct(configuration.selectedProducts)
      } else {
        setInitialCollection(configuration.selectedCollections)
      }

      setPurchaseAmount(parseFloat(configuration.purchaseAmount))
      setPurchaseQuantity(parseInt(configuration.purchaseQuantity))
      setInitialGetProduct(configuration.selectedGetProducts)
      setMetafieldId(dataJSON.metafield.id);
    }

    setIsLoading(false);
  },[id]);


  // Effect to fetch and update product details
  useEffect(() => {
    // Create an array of IDs from initialProduct
    const selectedProductsIDArray = initialProduct.map(product => product.id);

    // GraphQL query to fetch product details by IDs
    const GET_PRODUCT_DETAILS = `
      query FetchProductsByIds($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on Product {
            id
            title
            featuredImage {
              url(transform: {maxWidth: 50})
            }
          }
        }
      }`;

    // Prepare the query for product details and fetch data
    const queryForProduct = {
      query: GET_PRODUCT_DETAILS,
      variables: { ids: selectedProductsIDArray },
    };

    // Avoid running the query if there are no selected products
    if (!selectedProductsIDArray.length) {
      return;
    }

    // Fetch and process product details
    const updateProductDetails = async () => {
      try {
        const response = await GraphQLQuery({ queryWithVariable: queryForProduct });
        const data = await response.json();
        return data.nodes;
      } catch (error) {
        console.error('Error fetching product details:', error);
        return [];
      }
    };

    // Call the updateProductDetails function and update state
    updateProductDetails().then(updatedProducts => {
      setSelectedProduct(updatedProducts);
    });
  }, [initialProduct]);

  // Effect to fetch and update collection details
  useEffect(() => {
    // Create an array of IDs from initialCollection
    const selectedCollectionIDArray = initialCollection;
    console.log(selectedCollectionIDArray)

    // GraphQL query to fetch product details by IDs
    const GET_COLLECTION_DETAILS = `
      query FetchCollectionsByIds($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on Collection {
            id
            title
            image {
              url(transform: {maxWidth: 50})
            }
          }
        }
      }`;

    // Prepare the query for product details and fetch data
    const queryForCollections = {
      query: GET_COLLECTION_DETAILS,
      variables: { ids: selectedCollectionIDArray },
    };

    // Avoid running the query if there are no selected collection
    if (!selectedCollectionIDArray.length) {
      return;
    }

    // Fetch and process collection details
    const updateCollectionDetails = async () => {
      try {
        const response = await GraphQLQuery({ queryWithVariable: queryForCollections });
        const data = await response.json();
        return data.nodes;
      } catch (error) {
        console.error('Error fetching collection details:', error);
        return [];
      }
    };

    // Call the updateProductDetails function and update state
    updateCollectionDetails().then(updatedCollection => {
      setSelectedCollection(updatedCollection);
    });
  }, [initialCollection]);


  // Effect to fetch and update Get product details
  useEffect(() => {
    // Create an array of IDs from initialProduct
    const selectedProductsIDArray = initialGetProduct.map(product => product.id);

    // GraphQL query to fetch product details by IDs
    const GET_PRODUCT_DETAILS = `
      query FetchProductsByIds($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on Product {
            id
            title
            featuredImage {
              url(transform: {maxWidth: 50})
            }
          }
        }
      }`;

    // Prepare the query for product details and fetch data
    const queryForProduct = {
      query: GET_PRODUCT_DETAILS,
      variables: { ids: selectedProductsIDArray },
    };

    // Avoid running the query if there are no selected products
    if (!selectedProductsIDArray.length) {
      return;
    }

    // Fetch and process product details
    const updateProductDetails = async () => {
      try {
        const response = await GraphQLQuery({ queryWithVariable: queryForProduct });
        const data = await response.json();
        return data.nodes;
      } catch (error) {
        console.error('Error fetching product details:', error);
        return [];
      }
    };

    // Call the updateProductDetails function and update state
    updateProductDetails().then(updatedProducts => {

      const mergedArray = updatedProducts.map(item1 => {
        const correspondingItem2 = initialGetProduct.find(item2 => item2.id === item1.id);
        return {
          ...item1,
          variants: correspondingItem2 ? correspondingItem2.variants : null,
        };
      });

      setSelectedGetProduct(mergedArray);
    });
  }, [initialGetProduct]);


  // Handle for Submission for update
  const handleSubmit = useCallback(
    async (event) => {
      setIsLoading(true);
      event.preventDefault();

      let data = {};
      let cleanSelectedProduct = [];
      let cleanSelectedGetProduct = [];
      let cleanSelectedCollection = [];

      // Clean the data for product/collections.
      // Send only required data to keep the payload small
      cleanSelectedProduct = selectedProduct.map((selectedItem)=>{ return { id : selectedItem.id } });
      cleanSelectedGetProduct = selectedGetProduct.map((selectedItem)=>{
        return {
          id : selectedItem.id,
          variants: selectedItem.variants.map((variant) => {return { id : variant.id }})
        }
      })

      // Format collection in such a way that it can be used in the metafield
      cleanSelectedCollection = selectedCollection.map((selectedItem)=> selectedItem.id );

      data = {
        functionId,
        startsAt: startAtTimeStamp,
        purchaseAmount: parseFloat(purchaseAmountValue) || 0,
        purchaseQuantity: parseInt(purchaseQuantityValue) || 1,
        appliesTo: appliesTo,
        selectedProducts: appliesTo == 'Product' ? cleanSelectedProduct : [],
        selectedCollections: appliesTo == 'Collection' ? cleanSelectedCollection : [],
        selectedGetProducts: cleanSelectedGetProduct,
        discountType: discountType,
        discountTitle: discountType == 'manual' ? discountCode : automaticCouponTitle,
        id: id,
        metafieldId: metafieldId,
      }

      // Make the fetch POST request to update
      let resData;
      try {

        if (discountType == 'manual'){
          // resData = await createAppBasicCoupon(data);
        } else {
          resData = await updateCustomization(data);
        }

        if (resData.status !== 200) {
          setErrorMessage("An error occurred while processing your request.");
        } else {
          console.log("Discount updated successfully");
          // redirectToDiscount();
        }
      } catch (error) {
        console.log(error);
      } finally {
        setIsLoading(false);
      }
    },
    [functionId, selectedCollection, selectedProduct, selectedGetProduct, appliesTo, discountType, discountCode, automaticCouponTitle, purchaseAmountValue, purchaseQuantityValue]
  );

  // On Input Open the resource picker
  const handleSearchInput = (input) => {
    setSearchQuery(input)
    setOpenResourceSelector(true);
  }

  // On Input Open the gets resource picker
  const handleSearchGetInput = (input) => {
    setSearchGetQuery(input)
    setOpenResourceGetSelector(true);
  }

  const handleSelection = (resources) => {

    // Create Selected Items JSON
    const selectedItems = resources.selection

    // Set the data accordingly
    appliesTo == 'Product' ? setSelectedProduct(selectedItems) : setSelectedCollection(selectedItems)
    console.log({resources,selectedItems});
    setOpenResourceSelector(false);
  }

  // Handle What Customer Should Get
  const handleGetSelection = (resources) => {

    // Create Selected Items JSON
    const selectedItems = resources.selection

    // Set the data accordingly
    setSelectedGetProduct(selectedItems)
    console.log({resources,selectedItems});
    setOpenResourceGetSelector(false);
  }

  // Generate Random Code for the coupons
  const generateRandomValue = () => {
    const randomValue = Math.random().toString(36).substring(2, 14).toUpperCase();
    setDiscountCode(randomValue);
  };

  const setPurchaseAmountChange = useCallback(
    (value) => value >= 0 && setPurchaseAmount(value),
    [],
  );

  const setPurchaseQuantityChange = useCallback(
    (value) => value > 0 && setPurchaseQuantity(value),
    [],
  );

  return (
    // Show Coupon if already created and active/exist and provide a link to go to the coupon and change

    <Page
      breadcrumbs={[{ onAction: () => history.back() }]}
      title="Freebie Products"
      narrowWidth
    >
      {isLoading ? (
        <SkeletonPage primaryAction>
          <Layout>
            <Layout.Section>
              <Card sectioned>
                <SkeletonBodyText />
              </Card>
            </Layout.Section>
          </Layout>
        </SkeletonPage>
      ) : (
        <Layout>
          <Layout.Section>
            <Form onSubmit={handleSubmit}>
              <Card title="Gift with Product">
                <Card.Section>
                   <FormLayout>
                    {discountType == 'manual' ? (
                      <TextField
                        onChange={setDiscountCode}
                        label="Discount code"
                        value={discountCode}
                        helpText="Customers must enter this code at checkout."
                        connectedRight={<Button onClick={generateRandomValue}>Generate</Button>}
                      />
                    ) : (
                      <TextField
                        onChange={setAutomaticCouponTitle}
                        label="Title"
                        value={automaticCouponTitle}
                        helpText="Customers will see this in their cart and at checkout."
                      />
                    )}
                  </FormLayout>
                </Card.Section>
              </Card>
              <Card>
                <Card.Section title="Minimum purchase requirements">
                  <FormLayout>
                    <FormLayout.Group>
                      <TextField
                        label="Minimum Purchase Amount"
                        type="number"
                        prefix="₹"
                        placeholder="0.00"
                        onChange={setPurchaseAmountChange}
                        value={purchaseAmountValue}
                        autoComplete="off"
                      />
                      <TextField
                        label="Minimum Quantity"
                        type="number"
                        onChange={setPurchaseQuantityChange}
                        value={purchaseQuantityValue}
                        autoComplete="off"
                      />
                    </FormLayout.Group>
                  </FormLayout>
                </Card.Section>
              </Card>
              <Card>
                <Card.Section title="Customer Buys">
                  <FormLayout>
                    <ChoiceList
                      title="Any items from"
                      choices={[
                        { label: "Products", value: "Product" },
                        { label: "Collection", value: "Collection" }
                      ]}
                      selected={appliesTo}
                      onChange={setAppliesTo}
                    />
                    <Stack>
                      <Stack.Item fill>
                        <TextField
                          onChange={ handleSearchInput }
                          placeholder={ "Search "+ appliesTo.toString().toLowerCase() }
                        />
                      </Stack.Item>
                      <Stack.Item>
                        <Button onClick={setOpenResourceSelector}>Browse</Button>
                      </Stack.Item>
                    </Stack>
                    { selectedProduct.length || selectedCollection.length ?
                        <Stack>
                          <Stack.Item fill>
                            <ResourceList
                              resourceName={{singular: 'product', plural: 'products'}}
                              items={ appliesTo == 'Product' ? selectedProduct : selectedCollection }
                              renderItem={(item) => {
                                // 'images' is in product item object and 'image' is in collection item object
                                // Item can also arrive from graphql on initial query
                                const {id, title, images, image, featuredImage} = item;
                                console.log({item})
                                const media = (<Thumbnail
                                  size="small"
                                  transparent
                                  source={ image && image.originalSrc || image && image.url || images && images[0]?.originalSrc || featuredImage && featuredImage.url || ImageMajor }
                                  alt={title}
                                />)

                                return (
                                  <ResourceItem
                                    verticalAlignment="center"
                                    id={id}
                                    media={media}
                                    accessibilityLabel={`View details for ${title}`}
                                  >
                                    <TextContainer variant="bodyMd" fontWeight="bold" as="h2">
                                      {title}
                                    </TextContainer>

                                  </ResourceItem>
                                );
                              }}
                            />
                          </Stack.Item>
                        </Stack>
                      : "" }
                  </FormLayout>

                  {/* Resource Picker for the getting what customer needs to buy */}
                  <ResourcePicker
                    showVariants={false}
                    selectMultiple={ appliesTo == "Product" ? 5 : 1 }
                    initialQuery={ searchQuery }
                    resourceType={ appliesTo }
                    initialSelectionIds={ appliesTo == 'Product' ? selectedProduct : selectedCollection }
                    onCancel={() => {setOpenResourceSelector(false);setSearchQuery('')}}
                    open = { openResourceSelector }
                    onSelection={(resources) => handleSelection(resources)}
                  />

                </Card.Section>

                <Card.Section title="Customer Gets">
                  <FormLayout>
                    <Stack>
                      <Stack.Item fill>
                        <TextField
                          onChange={ handleSearchGetInput }
                          placeholder={ "Search product"}
                        />
                      </Stack.Item>
                      <Stack.Item>
                        <Button onClick={setOpenResourceGetSelector}>Browse</Button>
                      </Stack.Item>
                    </Stack>

                  { selectedGetProduct.length ?
                    <Stack>
                      <Stack.Item fill>
                        <ResourceList
                          resourceName={{singular: 'product', plural: 'products'}}
                          items={selectedGetProduct}
                          renderItem={(item) => {
                            const {id, title, images, variants, featuredImage} = item;
                            const media = (<Thumbnail
                              size="small"
                              transparent
                              source={ images && images[0]?.originalSrc || featuredImage && featuredImage.url || ImageMajor }
                              alt={title}
                            />)

                            return (
                              <ResourceItem
                                verticalAlignment="center"
                                id={id}
                                media={media}
                                accessibilityLabel={`View details for ${title}`}
                              >
                                <TextContainer>
                                  {title}
                                </TextContainer>
                                { variants ? 
                                  <small>{variants?.length} variant(s) selected</small>
                                  : ''
                                }
                              </ResourceItem>
                            )
                          }}
                        />
                      </Stack.Item>
                    </Stack>
                  : "" }
                  </FormLayout>

                  {/* Resource Picker for the getting which customer will get */}
                  <ResourcePicker
                    initialQuery={ searchGetQuery }
                    resourceType="Product"
                    initialSelectionIds={ selectedGetProduct }
                    onCancel={() => {setOpenResourceGetSelector(false);setSearchGetQuery('')}}
                    open = { openResourceGetSelector }
                    onSelection={(resources) => handleGetSelection(resources)}
                  />
                </Card.Section>

                <Card.Section>
                  <Button primary submit loading={isLoading}>
                    Update Discount
                  </Button>
                </Card.Section>

              </Card>
            </Form>
          </Layout.Section>
        </Layout>
      )}
      <SupportFooter />
    </Page>
  );
}