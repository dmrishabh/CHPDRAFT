import React, { useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { ResourcePicker, useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAuthenticatedFetch } from "../../../hooks";
import { ImageMajor } from '@shopify/polaris-icons';
import {
  FormLayout,
  ResourceList,
  ResourceItem,
  TextContainer, 
  Thumbnail
} from "@shopify/polaris";
  
import { 
  Page,
  Layout,
  ChoiceList,
  TextField, 
  Stack,
  Card,
  Form,
  Button,
  SkeletonPage,
  SkeletonBodyText,
} from "@shopify/polaris";
import { SupportFooter } from "../../../components/supportFooter.jsx";

// A utility hook for invoking the server endpoint that create basic coupon
function useCreateAppBasicCoupon() {
  const fetch = useAuthenticatedFetch();
  return async (appBasicCoupon) => {
    try {
      const res = await fetch("/api/freebieProduct/createAppBasicCoupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(appBasicCoupon),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// A utility hook for invoking the server endpoint that create automatic coupon
function useCreateAppAutomaticCoupon() {
  const fetch = useAuthenticatedFetch();
  return async (appAutomaticCoupon) => {
    try {
      const res = await fetch("/api/freebieProduct/createAppAutomaticCoupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(appAutomaticCoupon),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToDiscount() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/discounts",
    });
  };
}

// A utility hook for redirecting back to the checkout theme customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

export default function NewCustomizationPage() {
  // Read the function ID from the URL
  const { functionId } = useParams();

  // Utility hooks
  const createAppBasicCoupon = useCreateAppBasicCoupon();
  const createAppAutomaticCoupon = useCreateAppAutomaticCoupon();
  const redirect = useRedirectToCustomizations();
  const redirectToDiscount = useRedirectToDiscount();

  // Page state management
  const [isLoading, setIsLoading] = useState(false);
  const [automaticCouponTitle, setAutomaticCouponTitle] = useState("");
  const [discountCode, setDiscountCode] = useState("");
  const [openResourceSelector, setOpenResourceSelector] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState([]);
  const [selectedCollection, setSelectedCollection] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [openResourceGetSelector, setOpenResourceGetSelector] = useState(false);
  const [startAtTimeStamp, setStartAtTimeStamp] = useState(new Date());
  const [selectedGetProduct, setSelectedGetProduct] = useState([]);
  const [searchGetQuery, setSearchGetQuery] = useState("");
  const [discountType, setDiscountType] = useState(["automatic"]);
  const [appliesTo, setAppliesTo] = useState(["Product"]);
  const [purchaseAmountValue, setPurchaseAmount] = useState("");
  const [purchaseQuantityValue, setPurchaseQuantity] = useState(1);

  const handleSubmit = useCallback(
    async (event) => {
      // setIsLoading(true);
      event.preventDefault();

      let data = {};
      let cleanSelectedProduct = [];
      let cleanSelectedGetProduct = [];
      let cleanSelectedCollection = [];

      // Clean the data for product/collections.
      // Send only required data to keep the payload small
      cleanSelectedProduct = selectedProduct.map((selectedItem) => {
        return { id: selectedItem.id };
      });
      cleanSelectedGetProduct = selectedGetProduct.map((selectedItem) => {
        return {
          id: selectedItem.id,
          variants: selectedItem.variants.map((variant) => {
            return { id: variant.id };
          }),
        };
      });

      // Format collection in such a way that it can be used in the metafield
      cleanSelectedCollection = selectedCollection.map(
        (selectedItem) => selectedItem.id
      );

      data = {
        functionId,
        startsAt: startAtTimeStamp,
        purchaseAmount: parseFloat(purchaseAmountValue) || 0,
        purchaseQuantity: parseInt(purchaseQuantityValue) || 1,
        appliesTo: appliesTo,
        selectedProducts: appliesTo == "Product" ? cleanSelectedProduct : [],
        selectedCollections:
          appliesTo == "Collection" ? cleanSelectedCollection : [],
        selectedGetProducts: cleanSelectedGetProduct,
        discountType: discountType,
        discountTitle:
          discountType == "manual" ? discountCode : automaticCouponTitle,
      };

      console.log(data)

      // Make the fetch POST request to update
      let resData;
      try {
        if (discountType == "manual") {
          resData = await createAppBasicCoupon(data);
        } else {
          resData = await createAppAutomaticCoupon(data);
        }

        if (resData.status !== 200) {
          setErrorMessage("An error occurred while processing your request.");
        } else {
          redirectToDiscount();
        }
      } catch (error) {
        console.log(error);
      } finally {
        setIsLoading(false);
      }
    },
    [
      functionId,
      selectedCollection,
      selectedProduct,
      selectedGetProduct,
      appliesTo,
      discountType,
      discountCode,
      automaticCouponTitle,
      purchaseAmountValue,
      purchaseQuantityValue,
    ]
  );

  // On Input Open the resource picker
  const handleSearchInput = (input) => {
    setSearchQuery(input);
    setOpenResourceSelector(true);
  };

  // On Input Open the gets resource picker
  const handleSearchGetInput = (input) => {
    setSearchGetQuery(input);
    setOpenResourceGetSelector(true);
  };

  const handleSelection = (resources) => {
    // Create Selected Items JSON
    const selectedItems = resources.selection;

    // Set the data accordingly
    appliesTo == "Product"
      ? setSelectedProduct(selectedItems)
      : setSelectedCollection(selectedItems);
    console.log({ resources, selectedItems });
    setOpenResourceSelector(false);
  };

  // Handle What Customer Should Get
  const handleGetSelection = (resources) => {
    // Create Selected Items JSON
    const selectedItems = resources.selection;

    // Set the data accordingly
    setSelectedGetProduct(selectedItems);
    console.log({ resources, selectedItems });
    setOpenResourceGetSelector(false);
  };

  // Generate Random Code for the coupons
  const generateRandomValue = () => {
    const randomValue = Math.random()
      .toString(36)
      .substring(2, 14)
      .toUpperCase();
    setDiscountCode(randomValue);
  };

  const setPurchaseAmountChange = useCallback(
    (value) => value >= 0 && setPurchaseAmount(value),
    []
  );

  const setPurchaseQuantityChange = useCallback(
    (value) => value > 0 && setPurchaseQuantity(value),
    []
  );

  return (
    // Show Coupon if already created and active/exist and provide a link to go to the coupon and change

    <Page
      breadcrumbs={[{ onAction: () => history.back() }]}
      title="Freebie Products"
    >
      {isLoading ? (
        <SkeletonPage primaryAction>
          <Layout>
            <Layout.Section>
              <Card sectioned>
                <SkeletonBodyText />
              </Card>
            </Layout.Section>
          </Layout>
        </SkeletonPage>
      ) : (
        <Layout>
          <Layout.Section>
            <Form onSubmit={handleSubmit}>
              <Card title="">
                <Card.Section>
                  <FormLayout>
                    {/* Commenting code that we will be reusing to enable coupon code based discount */} 
                    <ChoiceList
                      choices={[
                        // { label: "Discount code", value: "manual" },
                        { label: "Automatic discount", value: "automatic" },
                      ]}
                      selected={discountType}
                      onChange={setDiscountType}
                    />  
                    {discountType == "manual" ? (
                      <TextField
                        onChange={setDiscountCode}
                        label="Discount code" 
                        value={discountCode}
                        helpText="Customers must enter this code at checkout."
                        connectedRight={
                          <Button onClick={generateRandomValue}>
                            Generate
                          </Button> 
                        }
                      />  
                    ) : (
                      <TextField
                        onChange={setAutomaticCouponTitle}
                        label="Title"
                        value={automaticCouponTitle}
                        helpText="Customers will see this in their cart and at checkout."
                      />
                    )}
                  </FormLayout>
                </Card.Section>
              </Card>
              <Card>
                <Card.Section title="Minimum purchase requirements">
                  <FormLayout>
                    <FormLayout.Group>
                      <TextField
                        label="Minimum Purchase Amount"
                        type="number"
                        prefix="₹"
                        placeholder="0.00"
                        onChange={setPurchaseAmountChange}
                        value={purchaseAmountValue}
                        autoComplete="off"
                      />
                      <TextField
                        label="Minimum Quantity"
                        type="number"
                        onChange={setPurchaseQuantityChange}
                        value={purchaseQuantityValue}
                        autoComplete="off"
                      />
                    </FormLayout.Group>
                  </FormLayout>
                </Card.Section>
              </Card>
              <Card>
                <Card.Section title="Customer Buys">
                  <FormLayout>
                    <ChoiceList
                      title="Any items from"
                      choices={[
                        { label: "Products", value: "Product" },
                        { label: "Collection", value: "Collection" },
                      ]}
                      selected={appliesTo}
                      onChange={setAppliesTo}
                    />
                    <Stack>
                      <Stack.Item fill>
                        <TextField
                          onChange={handleSearchInput}
                          placeholder={
                            "Search " + appliesTo.toString().toLowerCase()
                          }
                        />
                      </Stack.Item>
                      <Stack.Item>
                        <Button onClick={setOpenResourceSelector}>
                          Browse
                        </Button>
                      </Stack.Item>
                    </Stack>

                    {selectedProduct.length || selectedCollection.length ? (
                      <Stack>
                        <Stack.Item fill>
                          <ResourceList
                            resourceName={{
                              singular: "product",
                              plural: "products",
                            }}
                            items={
                              appliesTo == "Product"
                                ? selectedProduct
                                : selectedCollection
                            }
                            renderItem={(item) => {
                              // 'images' is in product item object and 'image' is in collection item object
                              const { id, title, images, image } = item;
                              const media = (
                                <Thumbnail
                                  size="small"
                                  transparent
                                  source={ image && image.originalSrc || images && images[0]?.originalSrc || ImageMajor }
                                  alt={title}
                                />
                              );

                              return (
                                <ResourceItem
                                  verticalAlignment="center"
                                  id={id}
                                  media={media}
                                  accessibilityLabel={`View details for ${title}`}
                                >
                                  <TextContainer
                                    variant="bodyMd"
                                    fontWeight="bold"
                                    as="h2"
                                  >
                                    {title}
                                  </TextContainer>
                                </ResourceItem>
                              );
                            }}
                          />
                        </Stack.Item>
                      </Stack>
                    ) : (
                      ""
                    )}
                  </FormLayout>

                  {/* Resource Picker for the getting what customer needs to buy */}
                  <ResourcePicker
                    showVariants={false}
                    // For products we allow 5 and for collection we allow only 1
                    selectMultiple={appliesTo == "Product" ? 5 : 1}
                    initialQuery={searchQuery}
                    resourceType={appliesTo}
                    initialSelectionIds={
                      appliesTo == "Product"
                        ? selectedProduct
                        : selectedCollection
                    }
                    onCancel={() => {
                      setOpenResourceSelector(false);
                      setSearchQuery("");
                    }}
                    open={openResourceSelector}
                    onSelection={(resources) => handleSelection(resources)}
                  />
                </Card.Section>

                <Card.Section title="Customer Gets">
                  <FormLayout>
                    <Stack>
                      <Stack.Item fill>
                        <TextField
                          onChange={handleSearchGetInput}
                          placeholder={"Search product"}
                        />
                      </Stack.Item>
                      <Stack.Item>
                        <Button onClick={setOpenResourceGetSelector}>
                          Browse
                        </Button>
                      </Stack.Item>
                    </Stack>

                    {selectedGetProduct.length ? (
                      <Stack>
                        <Stack.Item fill>
                          <ResourceList
                            resourceName={{
                              singular: "product",
                              plural: "products",
                            }}
                            items={selectedGetProduct}
                            renderItem={(item) => {
                              const { id, title, images, variants } = item;
                              const media = (
                                <Thumbnail
                                  size="small"
                                  transparent
                                  source={ images[0]?.originalSrc || ImageMajor }
                                  alt={title}
                                />
                              );

                              return (
                                <ResourceItem
                                  verticalAlignment="center"
                                  id={id}
                                  media={media}
                                  accessibilityLabel={`View details for ${title}`}
                                >
                                  <TextContainer>{title}</TextContainer>
                                  <small>
                                    {variants.length} variant(s) selected
                                  </small>
                                </ResourceItem>
                              );
                            }}
                          />
                        </Stack.Item>
                      </Stack>
                    ) : (
                      ""
                    )}
                  </FormLayout>

                  {/* Resource Picker for the getting which customer will get */}
                  <ResourcePicker
                    initialQuery={searchGetQuery}
                    resourceType="Product"
                    initialSelectionIds={selectedGetProduct}
                    onCancel={() => {
                      setOpenResourceGetSelector(false);
                      setSearchGetQuery("");
                    }}
                    open={openResourceGetSelector}
                    onSelection={(resources) => handleGetSelection(resources)}
                  />
                </Card.Section>

                <Card.Section>
                  <Button primary submit loading={isLoading}>
                    Create Discount
                  </Button>
                </Card.Section>
              </Card>
            </Form>
          </Layout.Section>
          <Layout.Section secondary>
            <Card title="Add extension in the checkout editor." sectioned>
              <TextContainer>
                Blocks will not show inside checkout until you add a Prepaid
                Discount extension in the checkout editor.
              </TextContainer>

              <div className="mt-5">
                <Button onClick={redirect} primary>
                  Open checkout editor
                </Button>
              </div>
            </Card>
          </Layout.Section>
        </Layout>
      )}
      <SupportFooter />
    </Page>
  );
}
