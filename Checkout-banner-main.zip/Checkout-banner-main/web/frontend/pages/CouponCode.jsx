import React, { useEffect, useState } from "react";
import {
  Button,
  Card,
  Page,
  Layout,
  TextContainer,
  Heading,
  EmptyState,
  IndexTable,
  Badge,
  Link,
  SkeletonPage,
  SkeletonBodyText,
  Pagination,
  Stack,
  Icon,
} from "@shopify/polaris";
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useNavigate } from "react-router-dom";
import { useAuthenticatedFetch } from "../hooks";
import { SupportFooter } from "../components/supportFooter";
import { CirclePlusMinor } from "@shopify/polaris-icons";

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/payments/customizations",
    });
  };
}

export default function CouponCode() {
  const [isEmpty, setIsEmpty] = useState(false);
  const [data, setData] = useState();
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const navigate = useNavigate();
  const redirect = useRedirectToCustomizations();
  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    setCurrentPage(currentPage + 1);
  };

  const fetch = useAuthenticatedFetch();

  const fetchData = async () => {
    try {
      setLoading(true);

      const URL = `/api/coupon/list?page=${currentPage}&limit=50`;
      const response = await fetch(URL);
      let result = await response.json();

      setData(result.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(async () => {
    fetchData();
  }, [currentPage]);

  useEffect(() => {
    if (data && !data.total) {
      setIsEmpty(true);
    }
  }, [data]);

  const onActionHandler = () => {
    navigate("/createcoupon");
  };

  const resourceName = {
    singular: "order",
    plural: "orders",
  };

  // For Creating skeleton
  const skeletonMarkUpIterations = Array.from(Array(6).keys());

  // const rowMarkup =

  return (
    <Page
      breadcrumbs={[{ url: "/" }]}
      title="Single click discount coupons"
      subtitle="Show discount coupons from the Shopify coupons list to be directly applied on the checkout page"
      compactTitle
      primaryAction={
        <Button primary onClick={() => onActionHandler()}>
          Create coupon
        </Button>
      }
    >
      <Layout>
        <Layout.Section>
          {loading ? (
            <Card>
              <IndexTable
                itemCount="2"
                headings={[{ title: "Coupons" }, { title: "Status" }]}
                selectable={false}
              >
                {skeletonMarkUpIterations.map((index) => (
                  <IndexTable.Row key={index}>
                    <IndexTable.Cell>
                      <SkeletonBodyText lines={1} />
                    </IndexTable.Cell>
                    <IndexTable.Cell>
                      <SkeletonBodyText lines={1} />
                    </IndexTable.Cell>
                  </IndexTable.Row>
                ))}
              </IndexTable>
            </Card>
          ) : isEmpty ? (
            <Card sectioned>
              <EmptyState
                heading="Create your fist coupon to get started"
                action={{
                  content: "Create Coupon",
                  onAction: onActionHandler,
                }}
                image="https://cdn.shopify.com/s/files/1/0759/0880/8990/files/cash_register_128.d525a0d5.png?v=1685107656"
              ></EmptyState>
            </Card>
          ) : (
            <Card>
              <IndexTable
                resourceName={resourceName}
                // Need to make sure this data is getting updated dynamically
                itemCount={2}
                headings={[{ title: "Coupon name" }, { title: "Status" }]}
                selectable={false}
              >
                {data !== null &&
                  data?.coupon.map(({ title, status, _id }, index) => (
                    <IndexTable.Row id={_id} key={index} position={index}>
                      <IndexTable.Cell>
                        <Link
                          dataPrimaryLink
                          url="/view"
                          onClick={() => {
                            navigate(`/viewcoupon/${_id}`);
                          }}
                        >
                          <div variant="bodyMd" fontWeight="bold" as="span">
                            {title}
                          </div>
                        </Link>
                      </IndexTable.Cell>
                      <IndexTable.Cell>
                        <Badge
                          progress={
                            status === "Active" ? "complete" : "incomplete"
                          }
                          status={status === "Active" ? "success" : "critical"}
                        >
                          {status === "Active" ? "Active" : "Inactive"}
                        </Badge>
                      </IndexTable.Cell>
                    </IndexTable.Row>
                  ))}
              </IndexTable>
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  padding: "15px",
                  borderTop: "1px solid #e2e4e6",
                }}
              >
                <Pagination
                  hasPrevious={currentPage !== 1}
                  previousKeys={[74]}
                  onPrevious={() => {
                    // Previous Page
                    handlePreviousPage();
                  }}
                  hasNext={currentPage !== Math.ceil(data?.total / 50)}
                  nextKeys={[75]}
                  onNext={() => {
                    // Next Page
                    handleNextPage();
                  }}
                />
              </div>
            </Card>
          )}
        </Layout.Section>
        <Layout.Section secondary>
          <Card title="Add extension in the checkout editor." sectioned>
            <TextContainer>
              Blocks will not show inside checkout until you add a Prepaid
              Discount extension in the checkout editor.
            </TextContainer>

            <div className="mt-5">
              <Button onClick={redirect} plain>
                <div className="flex">
                  <Icon source={CirclePlusMinor} />
                  Open checkout editor
                </div>
              </Button>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
      <SupportFooter />
    </Page>
  );
}
