import { useState, useEffect, useCallback } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useParams } from "react-router-dom";
import {
    TextField,
    Card,
    Page,
    Frame,
    Button,
    Icon,
    List,
    SkeletonBodyText,
  } from "@shopify/polaris";
import { DragHandleMinor,DeleteMinor } from '@shopify/polaris-icons';
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAuthenticatedFetch } from "../../../hooks/useAuthenticatedFetch.js";
import { ReorderImage } from "../../../components/ReorderImage.jsx";
import { SupportFooter } from "../../../components/supportFooter.jsx";
import '../../../styles/ReorderPaymentGateway.css'

// A utility hook for getting the details for the payment customization
function useGetCustomization() {
    const fetch = useAuthenticatedFetch();
    return async (paymentCustomization) => {
        return await fetch("/api/paymentReorder/details", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(paymentCustomization),
        });
    }
}

// A utility hook for updating the function data
function useUpdateCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (paymentCustomization) => {
      return await fetch("/api/paymentReorder/update", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(paymentCustomization),
      });
  }
}

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToCustomizations() {
    const app = useAppBridge();
    const redirect = Redirect.create(app);
    return () => {
        redirect.dispatch(Redirect.Action.ADMIN_PATH, {
            path: "/settings/payments/customizations",
        });
    }
}

export default function CustomizationPageDetails() {

    // Read the function ID from the URL
    const { id } = useParams();
  
    // Utility hooks
    const getCustomization = useGetCustomization();
    const updateCustomization = useUpdateCustomization();
    const redirect = useRedirectToCustomizations();
  
    // Page state management
    const [isLoading, setIsLoading] = useState(false);
    const [items, setItems] = useState([]);
    const [functionID, setFunctionID] = useState({});


    useEffect(async() => {
        setIsLoading(true);
        const response = await getCustomization({id});
        const dataJSON = await response.json();

        if(dataJSON?.id) {
            setFunctionID(dataJSON?.id);
        }

        const configuration = JSON.parse(
          dataJSON?.metafield?.value ?? "{}"
        );
  
        if(configuration && configuration.paymentGatewayOrder){
          setItems(configuration.paymentGatewayOrder);
        }
        setIsLoading(false);
      },[id]);
  
    // Invoke the server endpoint when the form is submitted
    const handleSubmit = async () => {
      console.log(items);
  
      setIsLoading(true);
      const response = await updateCustomization({
        functionID,
        paymentGatewayOrder: items,
      });
      if (response.status != 200) {
        const errorResponse = await response.json();
        console.log(
          "Error creating payment customization: ",
          errorResponse.error
        );
      } else {
        redirect();
      }
      setIsLoading(false);
    };
    const [newItem, setNewItem] = useState('');
  
    const handleDragEnd = useCallback(
      (result) => {
        if (!result.destination) return; // Return if dropped outside the list
  
        const updatedItems = Array.from(items);
        const [removed] = updatedItems.splice(result.source.index, 1);
        updatedItems.splice(result.destination.index, 0, removed);
  
        setItems(updatedItems);
      },
      [items]
    );
  
    const handleAddItem = useCallback(() => {
      if (newItem.trim() === '') return;
  
      const updatedItem = { id: newItem, content: newItem };
      const updatedItems = [...items, updatedItem];
  
      setItems(updatedItems);
      setNewItem('');
    }, [items,newItem]);
  
    const handleDeleteItem = useCallback(
      (id) => {
        const updatedItems = items.filter((item) => item.id !== id);
  
        setItems(updatedItems);
      },
      [items]
    );
  
    const handleContentChange = useCallback(
      (id, content) => {
        const updatedItems = items.map((item) => {
          if (item.id === id) {
            return { ...item, content };
          }
          return item;
        });
  
        setItems(updatedItems);
      },
      [items]
    );
  
    const handleInputChange = (value) => {
      setNewItem(value);
    };

    // A basic input form page created using Polaris components
    return (
      <Frame>
        <Page
          title="Reorder payment gateway"
          subtitle="You have the flexibility to reorder your payment gateways as per your preference."
          primaryAction={{
            onAction: handleSubmit,
            content: "Save",
            loading: isLoading,
          }}
          breadcrumbs={[
            {
              content: "Payment customizations",
              onAction: redirect,
            },
          ]}
        >
          <Card title="Order payment gateway as required">
            <Card.Section>
              { isLoading ?
                <SkeletonBodyText lines={6} ></SkeletonBodyText> 
              :
                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId="droppable">
                    {(provided) => (
                      <div ref={provided.innerRef} {...provided.droppableProps}>
                        <List>
                          {items.map((item, index) => (
                            <Draggable key={index} draggableId={`item-${index}`} index={index}>
                              {(provided) => (
                                <div
                                  className="payment__gateway--item"
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                >
                                  <List.Item>
                                    <div className="payment__gateway--listItem">
                                      <div {...provided.dragHandleProps} >
                                        <Icon source={DragHandleMinor} color="base" />
                                      </div>
                                      <TextField
                                        value={item.content}
                                        onChange={(content) => handleContentChange(item.id, content)}
                                        connectedRight={<Button icon={DeleteMinor} onClick={() => handleDeleteItem(item.id)}></Button>}
                                      />
                                    </div>
                                  </List.Item>
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </List>
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              }
            </Card.Section>
            <Card.Section>
              <TextField
                label="Add payment gateway to reorder"
                helpText="Example payment gateway names: Paypal, Stripe, Cash on delivery"
                value={newItem}
                onChange={handleInputChange}
                connectedRight={<Button onClick={handleAddItem}>Add Gateway</Button>}
              />
            </Card.Section>
          </Card>
          <ReorderImage/>
          <SupportFooter/>
        </Page>
      </Frame>
    );
  }