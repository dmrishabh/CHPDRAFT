import { useState, useEffect, useCallback } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useParams, useNavigate } from "react-router-dom";
import {
  TextField,
  Card,
  Page,
  Frame,
  Button,
  Icon,
  List,
} from "@shopify/polaris";
import { DragHandleMinor } from '@shopify/polaris-icons';
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAuthenticatedFetch } from "../../../hooks/useAuthenticatedFetch.js";
import { ReorderImage } from "../../../components/ReorderImage.jsx";
import '../../../styles/ReorderPaymentGateway.css'
import { SupportFooter } from "../../../components/supportFooter.jsx";

// A utility hook for invoking the server endpoint that you created
function useCreateCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (paymentCustomization) => {
    return await fetch("/api/paymentReorder/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(paymentCustomization),
    });
  };
}

// A utility hook to check if there is already a function added
function useActiveFunction() {
  const fetch = useAuthenticatedFetch();
  return async (functionId) => {
    return await fetch("/api/paymentReorder/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(functionId),
    });
  };
}

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/payments/customizations",
    });
  };
}

export default function NewCustomizationPage() {

  // Read the function ID from the URL
  const { functionId } = useParams();

  // Utility hooks
  const createCustomization = useCreateCustomization();
  const redirect = useRedirectToCustomizations();
  const activeFunction = useActiveFunction();
  const navigate = useNavigate();

  // Page state management
  const [isLoading, setIsLoading] = useState(false);


  useEffect(async() => {
      setIsLoading(true);

      const response = await activeFunction({ functionId });
      const dataJSON = await response.json();

      if (dataJSON.isFunctionAlreadyCreated) {
          navigate(dataJSON.storeFunctionEditURL);
      }

      setIsLoading(false);
    },[]);

  // Invoke the server endpoint when the form is submitted
  const handleSubmit = async () => {
    console.log(items);

    setIsLoading(true);
    const response = await createCustomization({
      functionId,
      paymentGatewayOrder: items,
    });
    if (response.status != 200) {
      const errorResponse = await response.json();
      console.log(
        "Error creating payment customization: ",
        errorResponse.error
      );
    } else {
      redirect();
    }
    setIsLoading(false);
  };

  const [items, setItems] = useState([{
    id: 'Replace your payment gateway name here',
    content: 'Replace your payment gateway name here',
  }]);
  const [newItem, setNewItem] = useState('');

  const handleDragEnd = useCallback(
    (result) => {
      if (!result.destination) return; // Return if dropped outside the list

      const updatedItems = Array.from(items);
      const [removed] = updatedItems.splice(result.source.index, 1);
      updatedItems.splice(result.destination.index, 0, removed);

      setItems(updatedItems);
    },
    [items]
  );

  const handleAddItem = useCallback(() => {
    if (newItem.trim() === '') return;

    const updatedItem = { id: newItem, content: newItem };
    const updatedItems = [...items, updatedItem];

    setItems(updatedItems);
    setNewItem('');
  }, [items,newItem]);

  const handleDeleteItem = useCallback(
    (id) => {
      const updatedItems = items.filter((item) => item.id !== id);

      setItems(updatedItems);
    },
    [items]
  );

  const handleContentChange = useCallback(
    (id, content) => {
      const updatedItems = items.map((item) => {
        if (item.id === id) {
          return { ...item, content };
        }
        return item;
      });

      setItems(updatedItems);
    },
    [items]
  );

  const handleInputChange = (value) => {
    setNewItem(value);
  };



  // A basic input form page created using Polaris components
  return (
    <Frame>
      <Page
        title="Reorder payment gateway"
        subtitle="You have the flexibility to reorder your payment gateways as per your preference."
        primaryAction={{
          onAction: handleSubmit,
          content: "Save",
          loading: isLoading,
        }}
        breadcrumbs={[
          {
            content: "Payment customizations",
            onAction: redirect,
          },
        ]}
      >
        <Card title="Order payment gateway as required">

          <Card.Section>
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="droppable">
                {(provided) => (
                  <div ref={provided.innerRef} {...provided.droppableProps}>
                    <List>
                      {items.map((item, index) => (
                        <Draggable key={index} draggableId={`item-${index}`} index={index}>
                          {(provided) => (
                            <div
                              className="payment__gateway--item"
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                            >
                              <List.Item>
                                <div className="payment__gateway--listItem">
                                  <div {...provided.dragHandleProps} >
                                    <Icon source={DragHandleMinor} color="base" />
                                  </div>
                                  <TextField
                                    value={item.content}
                                    onChange={(content) => handleContentChange(item.id, content)}
                                    connectedRight={<Button onClick={() => handleDeleteItem(item.id)}>Delete</Button>}
                                  />
                                </div>
                              </List.Item>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </List>
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </Card.Section>
          <Card.Section>
            <TextField
              label="Add payment gateway to reorder"
              helpText="Example payment gateway names: Paypal, Stripe, Cash on delivery"
              value={newItem}
              onChange={handleInputChange}
              connectedRight={<Button onClick={handleAddItem}>Add Gateway</Button>}
            />
          </Card.Section>
        </Card>
        <ReorderImage/>
        <SupportFooter/>
      </Page>
    </Frame>
  );
}
