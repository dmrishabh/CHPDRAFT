import { Button, Card, Page, Layout, Link, TextContainer, List } from "@shopify/polaris";
import { useNavigate } from "react-router-dom";
import { SupportFooter } from "../../components/supportFooter"
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
      redirect.dispatch(Redirect.Action.ADMIN_PATH, {
          path: "/settings/payments/customizations",
      });
  }
}

export default function PageName() {
  const navigate = useNavigate();
  const redirect = useRedirectToCustomizations();
  const onActionHandler = () => {
    navigate("/");
  };

  return (
    <Page
      breadcrumbs={[{ onAction: () => onActionHandler() }]}
      title="Reorder Payment Gateway"
      subtitle="You have the flexibility to reorder your payment gateways as per your preference."
    >
      <Layout>
        <Layout.Section >
          <Card sectioned>
            <img
              src="https://cdn.shopify.com/s/files/1/0759/0880/8990/files/paymentGatewayReorder.gif?v=1687790212"
              alt="demo_gify"
            />
          </Card>
        </Layout.Section>
        <Layout.Section secondary>
          <Card title="Watch the video and complete the following steps" sectioned>
            <TextContainer>
              <p>
                <strong> Step 1:</strong> Click on{" "} Go to payment customization
              </p>
              <p>
                <strong> Step 2:</strong> Click on the add a customization button
              </p>
              <p>
                <strong> Step 3:</strong> Select Payment Gateway reorder
              </p>
              <p>
                <strong> Step 4:</strong> Add payment gateway name and arrange in your desire order
              </p>
              <p></p>
            </TextContainer>
            <Button onClick={redirect} primary>Go to payment customization</Button>
          </Card>
        </Layout.Section>
      </Layout>
      <SupportFooter/>
    </Page>
  );
}
