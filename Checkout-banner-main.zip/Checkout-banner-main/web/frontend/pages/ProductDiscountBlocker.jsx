import { Card, Page, Layout, TextContainer, Button } from "@shopify/polaris";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAppBridge } from "@shopify/app-bridge-react";

import DiscountBlockerImg from "../assets/Discount-BlockerImg.png";

// A utility hook for redirecting back to the checkout customizer page
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

export default function HomePage() {
  const redirect = useRedirectToCustomizations();
  return (
    <Page>
      <Layout>
        <Layout.Section>
          <Card sectioned>
            <img src={DiscountBlockerImg} alt="demo_gify" />
          </Card>
        </Layout.Section>
        <Layout.Section secondary>
          <Card title="Add extension in the checkout editor." sectioned>
            <TextContainer>
              Blocks will not show inside checkout until you add a Product
              Discount blocker extension in the checkout editor.
            </TextContainer>

            <div className="mt-5">
              <Button onClick={redirect} primary>
                Open checkout editor
              </Button>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
