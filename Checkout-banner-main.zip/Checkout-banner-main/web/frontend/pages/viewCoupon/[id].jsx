import React, { useState, useCallback, useEffect } from "react";
import { useParams,useNavigate } from "react-router-dom";
import {
  SkeletonPage,
  Layout,
  SkeletonBodyText,
  SkeletonDisplayText,
  Button,
  Card,
  Page,
  Form,
  FormLayout,
  TextField,
  Stack,
  Checkbox,
} from "@shopify/polaris";
import { useAuthenticatedFetch } from "../../hooks";

function SkeletonExample() {
  const { id } = useParams();
  const navigate =useNavigate();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetch = useAuthenticatedFetch();

  // fetch data by id
  const fetchItem = async () => {
    try {
      const URL = `/api/coupon/view?id=${id}`;
      const response = await fetch(URL);
      let result = await response.json();
      setData(result.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchItem();
  }, []);

  // handle input fields
  const handleInput = () => {
    const { name, value } = event.target;
    setData((prev) => ({ ...prev, [name]: value }));
  };

  // handle check box
  const handleCheck = (newChecked) => {
    setData((prev) => ({
      ...prev,
      status: newChecked ? "Active" : "Deactivate",
    }));
  };

  const handleSubmit = useCallback((event) => {

    event.preventDefault();
    
    const dataUpdate = {
      "gid": data.gid,
      "title": data.title,
      "subtitle": data.subtitle,
      "status": data.status
    };

    // Make the fetch POST request to update
    fetch('/api/coupon/update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dataUpdate),
    })
      .then((response) => response.json())
      .then((responseData) => {
        // Handle the response data
        navigate("/couponcode")
      })
      .catch((error) => {
        // Handle any error that occurred during the request
        console.error('Error submitting form:', error);
      });

  }, [data]);

  return (
    <Page
      breadcrumbs={[{ onAction: () => navigate("/CouponCode") }]}
      title="Edit coupon"
    >
      {data == null ? (
        <Card sectioned>
          <Stack vertical spacing="loose" fill>
            <SkeletonDisplayText size="small" />
            <SkeletonBodyText lines={3} />
            <SkeletonDisplayText size="small" />
            <SkeletonBodyText lines={3} />
          </Stack>
        </Card>
      ) : (
        <Form onSubmit={handleSubmit}>
          <FormLayout>
            <Card sectioned>
              <Stack vertical spacing="loose" fill>
                <TextField
                  name="title"
                  value={data.title}
                  onChange={handleInput}
                  label="Discount Coupon Title"
                  type="text"
                  autoComplete="off"
                  placeholder="FREE10"
                  helpText={<span>You can create a coupon title to attract customers attention.</span>}
                />
                <TextField
                  name="subtitle"
                  value={data.subtitle}
                  onChange={handleInput}
                  label="Discount Coupon Subtitle"
                  type="text"
                  autoComplete="off"
                  placeholder="E.g. get flat 10% off"
                  helpText={<span>You can add brief description for customer understanding.</span>}
                />
                <Checkbox
                  label="Coupon available for customer usage"
                  name="show_coupon"
                  helpText={
                    <span>
                      Clicking this will make the coupon visible for customers to use.
                    </span>
                  }
                  checked={data.status === "Active" ? true : false}
                  onChange={handleCheck}
                />
              </Stack>
            </Card>

            <div className="text-right">
              {/* <Button destructive outline>
                Delete
              </Button> */}

              <Button primary submit>
                Save
              </Button>
            </div>
          </FormLayout>
        </Form>
      )}
    </Page>
  );
}

export default SkeletonExample;
