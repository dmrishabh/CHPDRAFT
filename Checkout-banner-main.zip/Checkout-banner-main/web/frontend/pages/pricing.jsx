import {
  Heading,
  Page,
  Card,
  TextContainer,
  List,
  Button,
  Icon,
  Stack,
  Layout,
  SkeletonBodyText,
  SkeletonDisplayText,
  ProgressBar,
} from "@shopify/polaris";
import { MobileAcceptMajor } from "@shopify/polaris-icons";
import { TickMinor } from "@shopify/polaris-icons";
import React, { useEffect, useState } from "react";
import { useAuthenticatedFetch } from "../hooks";
import { SupportFooter } from "../components/supportFooter";

export default function PageName() {
  const fetch = useAuthenticatedFetch();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState();
  const [activePlan, setActivePlan] = useState();
  const [currentViewCount, setCurrentViewCount] = useState(30);
  const [currentProgress, setCurrentProgress] = useState(0);

  const fetchData = async () => {
    try {
      setLoading(true);

      const URL = `/api/plans/list`;
      const response = await fetch(URL);
      let result = await response.json();

      setData(result.data);
      setActivePlan(result.data.activePlan);

      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  const handleSelectPlan = async (plan) => {
    // Handle the plan selection here
    const URL = `/api/plans/updateplan/${plan}`;

    const response = await fetch(URL);

    let result = await response.json();
    if (result.success) {
      window.top.location.href = result.url;
    }

    console.log(`Selected plan: ${plan}`);
  };

  useEffect(async () => {
    fetchData();
  }, []);
  useEffect(() => {
    const targetCount = data?.activePlan?.viewLimit || 100;
    setCurrentViewCount(data?.viewCount);
    const newProgress = (currentViewCount / targetCount) * 100;
    // Update the progress state
    setCurrentProgress(newProgress);
  }, [data, currentViewCount]);

  return (
    <Page>
      <Card sectioned>
        <Stack vertical spacing="tight">
          <Heading>Pricing Plan</Heading>
          <TextContainer>
            <p>Choose the perfect plan for your needs:</p>
          </TextContainer>
          <div className="">
            <div
              style={{
                display: "flex",
                gap: "1rem",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  width: "25%",
                }}
              >
                Current view count {data?.viewCount}
              </div>

              <ProgressBar
                ariaLabelledBy="Area"
                progress={currentProgress}
                color="highlight"
                animated={true}
              />

              <div
                style={{
                  width: "25%",
                }}
              >
                {data?.activePlan?.viewLimit}
              </div>
            </div>
          </div>
          <Stack spacing="" distribution="fill">
            {loading ? (
              <Stack spacing="" distribution="fill">
                <TextContainer>
                  <SkeletonBodyText />
                  <SkeletonBodyText />
                  <SkeletonBodyText />
                  <SkeletonDisplayText size="small" />
                </TextContainer>
                <TextContainer>
                  <SkeletonBodyText />
                  <SkeletonBodyText />
                  <SkeletonBodyText />
                  <SkeletonDisplayText size="small" />
                </TextContainer>
              </Stack>
            ) : (
              "HI"
            )}
            {data?.plans.map(
              (
                {
                  costPerView,
                  currencyCode,
                  planPrice,
                  planId,
                  planName,
                  usageTerms,
                  viewLimit,
                  _id,
                },
                index
              ) => (
                <Card
                  title={`${planName} \n $${planPrice}/month`}
                  id={_id}
                  key={index}
                  sectioned
                >
                  <Card.Section>
                    <TextContainer>
                      <List>
                        <List.Item>
                          <Stack alignment="center">
                            <Icon source={TickMinor} color="primary" />
                            <>Unlimited payment gateway rearrangement</>
                          </Stack>
                        </List.Item>
                        {viewLimit && (
                          <List.Item>
                            <Stack alignment="center">
                              <Icon source={TickMinor} color="primary" />
                              <>
                                Process up to {viewLimit} free views per month
                              </>
                            </Stack>
                          </List.Item>
                        )}
                        <List.Item>
                          <Stack alignment="center">
                            <Icon source={TickMinor} color="primary" />
                            <>One Click Discount</>
                          </Stack>
                        </List.Item>
                        <List.Item>
                          <Stack alignment="center">
                            <Icon source={TickMinor} color="primary" />
                            <>Checkout Banners</>
                          </Stack>
                        </List.Item>
                        {costPerView ? (
                          <List.Item>
                            <Stack alignment="center">
                              <Icon source={TickMinor} color="primary" />
                              <>${costPerView} per additional unique views</>
                            </Stack>
                          </List.Item>
                        ) : (
                          ""
                        )}
                        {/* Add more list items as needed for other data properties */}
                      </List>
                    </TextContainer>
                  </Card.Section>
                  <Card.Section>
                    <Button
                      disabled={
                        planId == "free" || planId == activePlan?.planId
                      }
                      onClick={() => handleSelectPlan(planId)}
                      primary
                    >
                      {planId == activePlan?.planId
                        ? "Activated"
                        : "Select Plan"}
                    </Button>
                  </Card.Section>
                </Card>
              )
            )}
          </Stack>
        </Stack>
      </Card>
      <SupportFooter />
    </Page>
  );
}
