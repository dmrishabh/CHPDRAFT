import React, { useState, useCallback, useEffect } from 'react';
import { Frame, Card, Page, Button, Form, FormLayout, TextField, Layout, Stack, SkeletonBodyText, Toast } from '@shopify/polaris';
import { DuplicateMinor, ExternalMinor, CirclePlusMinor, DeleteMinor } from '@shopify/polaris-icons';
import { FormField } from '../../components';
import { SupportFooter } from '../../components/supportFooter';
import { useAuthenticatedFetch } from "../../hooks";
import { useParams } from 'react-router-dom';
import { Redirect } from "@shopify/app-bridge/actions";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useNavigate } from 'react-router-dom';


// A utility hook for getting the details for the forms
function useGetForms() {
  const fetch = useAuthenticatedFetch();
  return async () => {
    return await fetch("/api/form/details", {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });
  }
}

// A utility hook for invoking the server endpoint that create form
function useUpdateForm() {
  const fetch = useAuthenticatedFetch();
  return async (customField) => {
    try {
      const res = await fetch("/api/form/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customField),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// A utility hook for deleting specified the forms
function useDeleteForm() {
  const fetch = useAuthenticatedFetch();
  return async (formToDelete) => {
    return await fetch("/api/form/delete", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formToDelete)
    });
  }
}

// A utility hook for redirecting back to the checkout theme customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

// Generate a random 6-digit ID
function generateRandomID() {
  const min = 100000; // Minimum value for a 6-digit number
  const max = 999999; // Maximum value for a 6-digit number

  const randomID = Math.floor(Math.random() * (max - min + 1)) + min;

  return randomID.toString(); // Convert to string
}

export default function createCustomField() {
  const { id } = useParams();

  const getForms = useGetForms();
  const updateForm = useUpdateForm();
  const deleteForm = useDeleteForm();
  const navigate = useNavigate();

  const redirectToCustomizations = useRedirectToCustomizations();

  const [isLoading, setIsLoading] = useState(false);
  const [formTitle, setFormTitle] = useState("Custom Form");
  const [title, setTitle] = useState("");
  const [formID, setFormID] = useState(generateRandomID());
  const [formFields, setFormFields] = useState([]);
  const [formData, setFormData] = useState([]);

  const handleFormTitleChange = useCallback((value) => setFormTitle(value), []);
  const handleTitleChange = useCallback((value) => setTitle(value), []);

  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const copiedActive = useCallback(() => setCopied((copied) => !copied), []);
  const savedActive = useCallback(() => setSaved((saved) => !saved), []);

  const copiedToastMarkup = copied ? (
    <Toast content="Copied" onDismiss={copiedActive} />
  ) : null;

  const savedToastMarkup = saved ? (
    <Toast content="Form Updated" onDismiss={savedActive} />
  ) : null;

  useEffect(async() => {
    setIsLoading(true);
    const response = await getForms();
    const dataJSON = await response.json();
    setFormData(dataJSON?.metafieldData || []);
    setIsLoading(false);
  },[]);

  // Make the form data as row
  useEffect(async() => {
    // Read the function ID from the URL
    const detailsForFormField = formData.filter(form =>  form.id === id );

    if(detailsForFormField[0]){
      setFormID(detailsForFormField[0].id || '');
      setTitle(detailsForFormField[0].title || '');
      setFormTitle(detailsForFormField[0].formName || '')
      setFormFields(detailsForFormField[0].fields || [{ type: 'text' }])
    }
  },[formData]);

  // Copy Form ID to the clipboard
  const copyToClipboard = useCallback(async () => {
    if ("clipboard" in navigator) {
      await navigator.clipboard.writeText(formID);
    } else {
      document.execCommand("copy", true, formID);
    }
    copiedActive();
  },[formID]);

  // Invoke the server endpoint when the form is submitted
  const handleSubmit = async () => {
    setIsLoading(true);
    let formDetails = {};

    // Assigning form a randomID
    formDetails.id = formID;

    // Adding form Details as added by the merchants
    formDetails.formName = formTitle;
    formDetails.title = title;
    formDetails.isActive = true;
    formDetails.createdAt = Date.now();
    formDetails.updatedAt = Date.now();
    formDetails.fields = formFields

    // Update the Form
    await updateForm(formDetails);
    savedActive();
    setIsLoading(false);
  };

  // Handle Form Delete
  const handleDelete = async () => {
    setIsLoading(true);
    await deleteForm({id: formID});
    navigate('/custom-field/');
    setIsLoading(false);
  }

  const handleAddField = () => {
    setFormFields([...formFields, { type: 'text' }]);
  };

  const handleUpdateField = (index, updatedField) => {
    const updatedFields = [...formFields];
    updatedFields[index] = updatedField;
    setFormFields(updatedFields);
  };

  const handleRemoveField = (index) => {
    const updatedFields = [...formFields];
    updatedFields.splice(index, 1);
    setFormFields(updatedFields);
  };

  return (
    <Frame>
      <Page
        breadcrumbs={[{ onAction: () => navigate('/custom-field/') }]}
        title="Add Custom field"
        subtitle="Manage the settings of the component that will be shown to customers."
        compactTitle
        primaryAction={
          <Stack
            alignment="center"
          >
            <Button
              plain
              destructive
              disabled={isLoading} 
              icon={DeleteMinor}
              onClick={handleDelete}
            >
              Delete
            </Button>
            <Button primary onClick={handleSubmit} loading={isLoading}>
              Update
            </Button>
          </Stack>

        }
      >
        { isLoading && !formFields.length ?
            <Layout>
              <Layout.Section>
                <Card sectioned title="Form Details">
                  <SkeletonBodyText lines={7} />
                </Card>
              </Layout.Section>
            </Layout>
          :
            <Layout>
              <Layout.Section>
                  <Card sectioned title="Form Details">
                    <TextField
                      label="Form ID"
                      type="text"
                      value={formID}
                      disabled
                      autoComplete="off"
                      helpText="Block wont be vissible until you add them in customizer"
                      connectedRight={
                        <Stack spacing="tight">
                          <Button icon={DuplicateMinor} onClick={copyToClipboard} >Copy Form ID</Button>
                          <Button icon={ExternalMinor} onClick={redirectToCustomizations}>Open Customizer</Button>
                        </Stack>
                      }
                    />
                  </Card>
              </Layout.Section>
              <Layout.Section>
                <Card sectioned >
                  <Form onSubmit={handleSubmit}>
                    <FormLayout>
                      <Stack vertical spacing="tight">
                        <TextField
                          onChange={handleFormTitleChange}
                          label="Form name"
                          value={formTitle}
                          helpText="This is for internal reference"
                          requiredIndicator={true}
                        />
                        <TextField
                          onChange={handleTitleChange}
                          label="Form title for customer (Optional)"
                          value={title}
                          helpText="This will be what your customer will see"
                          requiredIndicator={false}
                        />
                      </Stack>
                    </FormLayout>
                  </Form>
                </Card>
              </Layout.Section>
              <Layout.Section>
                {formFields.map((field, index) => (
                  <FormField
                    key={index} 
                    index={index}
                    field={field}
                    onUpdateField={handleUpdateField}
                    onRemoveField={handleRemoveField}
                  />
                ))}
              </Layout.Section>
              <Layout.Section>
                <Card sectioned >
                  <FormLayout>
                    <Button fullWidth icon={CirclePlusMinor} onClick={handleAddField}>Add Field</Button>
                    <Button fullWidth primary onClick={handleSubmit} loading={isLoading}>Update</Button>
                  </FormLayout>
                </Card>
              </Layout.Section>
            </Layout>
        }

        <SupportFooter />
        {copiedToastMarkup}
        {savedToastMarkup}
      </Page>
    </Frame>
  );
}
