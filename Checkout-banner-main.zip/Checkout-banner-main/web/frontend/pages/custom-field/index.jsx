import { Card, EmptyState, Page, Button } from "@shopify/polaris";
import {Link, DataTable, Badge} from '@shopify/polaris';
import { notFoundImage } from "../../assets";
import { useNavigate } from "react-router-dom";
import { useAuthenticatedFetch } from "../../hooks";
import { useEffect, useState } from "react";
import { SupportFooter } from "../../components/supportFooter";

// A utility hook for getting the details for the forms
function useGetForms() {
  const fetch = useAuthenticatedFetch();
  return async () => {
      return await fetch("/api/form/details", {
          method: "GET",
          headers: { "Content-Type": "application/json" }
      });
  }
}

export default function customField() {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState([]);
  const [dataRow, setDataRow] = useState([]);

  const getForms = useGetForms();
  const navigate = useNavigate();

  useEffect(async() => {
    setIsLoading(true);
    const response = await getForms();
    const dataJSON = await response.json();
    setFormData(dataJSON?.metafieldData || []);
    setIsLoading(false);
  },[]);

  // Make the form data as row
  useEffect(async() => {
    const items = formData.map((item) => {
      const date = new Date(item.updatedAt).toLocaleDateString();

      return [
        <Link
          onClick={()=> {
              navigate('/custom-field/'+ item.id)
            }
          }
          url={item.id}
          key={item.formName}
        >{item.formName}</Link>,
        item.id,
        item.isActive ? <Badge status="success">Active</Badge> : <Badge status="attention">Inactive</Badge>,
        date
      ]
    })
    setDataRow(items)
  },[formData]);

  return (
    <Page
      breadcrumbs={[{ onAction: () => history.back() }]}
      title="Custom field"
      subtitle="Let customers add additional details on checkout"
      compactTitle
      primaryAction={
        <Button primary onClick={() => navigate(`/custom-field/new`)}>
          Create custom field
        </Button>
      }
    >
      <Card>
        <Card.Section>
          { isLoading ?
            <EmptyState
              heading="Finding form"
              image={notFoundImage}
            />
          :
            <DataTable
              increasedTableDensity
              hoverable
              columnContentTypes={[
                'text',
                'text',
                'text',
                'numeric'
              ]}
              headings={['Form name', 'Form id', 'Status', 'Updated at']}
              rows={dataRow}
            />
          }
        </Card.Section>
      </Card>
      <SupportFooter/>
    </Page>
  );
}
