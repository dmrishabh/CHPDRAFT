import React, { useState,useCallback } from 'react';
import { Card, Page, Button, Form, FormLayout, TextField, Layout, Stack } from '@shopify/polaris';
import { CirclePlusMinor } from '@shopify/polaris-icons';
import { FormField } from '../../components';
import { SupportFooter } from '../../components/supportFooter';
import { useAuthenticatedFetch } from "../../hooks";
import { useNavigate } from 'react-router-dom';

// Generate a random 6-digit ID
function generateRandomID() {
  const min = 100000; // Minimum value for a 6-digit number
  const max = 999999; // Maximum value for a 6-digit number

  const randomID = Math.floor(Math.random() * (max - min + 1)) + min;

  return randomID.toString(); // Convert to string
}

// A utility hook for invoking the server endpoint that create form
function useCreateForm() {
  const fetch = useAuthenticatedFetch();
  return async (customField) => {
    try {
      const res = await fetch("/api/form/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customField),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

export default function createCustomField() {
  const createForm = useCreateForm();
  const navigate = useNavigate();

  const [formTitle, setFormTitle] = useState("Custom Form");
  const [title, setTitle] = useState("");
  const [formID, setFormID] = useState(generateRandomID());
  const [isLoading, setIsLoading] = useState(false);
  

  const handleFormTitleChange = useCallback((value) => setFormTitle(value), []);
  const handleTitleChange = useCallback((value) => setTitle(value), []);

  // Invoke the server endpoint when the form is submitted
  const handleSubmit = async () => {
    setIsLoading(true);
    let formDetails = {};

    // Assigning form a randomID
    formDetails.id = formID;

    // Adding form Details as added by the merchants
    formDetails.formName = formTitle;
    formDetails.title = title;
    formDetails.isActive = true;
    formDetails.createdAt = Date.now();
    formDetails.updatedAt = Date.now();
    formDetails.fields = formFields

    await createForm(formDetails);
    navigate('/custom-field/'+ formID)
    setIsLoading(false);
  };

  const [formFields, setFormFields] = useState([
    { type: 'text' },
  ]);

  const handleAddField = () => {
    setFormFields([...formFields, { type: 'text' }]);
  };

  const handleUpdateField = (index, updatedField) => {
    const updatedFields = [...formFields];
    updatedFields[index] = updatedField;
    setFormFields(updatedFields);
  };

  const handleRemoveField = (index) => {
    const updatedFields = [...formFields];
    updatedFields.splice(index, 1);
    setFormFields(updatedFields);
  };

  return (
    <Page
      breadcrumbs={[{ onAction: () => navigate('/custom-field/') }]}
      title="Add Custom field"
      subtitle="Manage the settings of the component that will be shown to customers."
      compactTitle
      primaryAction={
        <Button primary onClick={handleSubmit} loading={isLoading}>
          Save
        </Button>
      }
    >
      <Layout>
        <Layout.Section>
          <Card sectioned title="Form Details">
            <Form onSubmit={handleSubmit}>
              <FormLayout>
                <Stack vertical spacing="loose">
                  <TextField
                    onChange={handleFormTitleChange}
                    label="Form name"
                    value={formTitle}
                    helpText="This is for internal reference"
                    requiredIndicator={true}
                  />
                  <TextField
                    onChange={handleTitleChange}
                    label="Form title for customer (Optional)"
                    value={title}
                    helpText="This will be what your customer will see"
                    requiredIndicator={false}
                  />
                </Stack>
              </FormLayout>
            </Form>
          </Card>
        </Layout.Section>
        <Layout.Section>
          {formFields.map((field, index) => (
            <FormField
              key={index}
              index={index}
              field={field}
              onUpdateField={handleUpdateField}
              onRemoveField={handleRemoveField}
            />
          ))}
        </Layout.Section>
        <Layout.Section>
          <Card sectioned >
            <FormLayout>
              <Button fullWidth icon={CirclePlusMinor} onClick={handleAddField}>Add Field</Button>
              <Button fullWidth loading={isLoading} primary onClick={handleSubmit}>Save</Button>
            </FormLayout>
          </Card>
        </Layout.Section>
      </Layout>
      <SupportFooter />
    </Page>
  );
}
