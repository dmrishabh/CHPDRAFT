import { useEffect, useState } from "react";
import { Page, Layout } from "@shopify/polaris";
import { TitleBar } from "@shopify/app-bridge-react";
import { useAuthenticatedFetch } from "../hooks";
import "../styles/CustomStyles.css";
import { useNavigate } from "react-router-dom";
import IntroCard from "./../components/IntroCard";
import { SupportFooter } from "../components/supportFooter";
import {
  CouponBlockVideo,
  PaymentReorderBlockVideo,
  BannerBlockVideo,
  FreebieDiscount,
  PrepaidDiscount,
  DiscountBlocker,
  CustomField,
} from "../assets";

const FUNCTION_ID_PREPAID_DISCOUNT = "1864d648-b879-4e3a-9116-0c4d1a8f0203";
const FUNCTION_ID_FREEBIE_DISCOUNT = "64f8d556-703b-42bb-9759-9f2b29f29580";
const prePaidDiscountPath =
  "/prepaid-discount/" + FUNCTION_ID_PREPAID_DISCOUNT + "/new";
const freebieDiscountPath =
  "/freebie-product/" + FUNCTION_ID_FREEBIE_DISCOUNT + "/new";
const createCustomFieldPath = "/custom-field";
const dynamicContentPath = "/dynamic-content";

export default function HomePage() {
  const navigate = useNavigate();
  const fetch = useAuthenticatedFetch();
  const [status, setStatus] = useState(false);

  useEffect(async () => {
    const resp = await fetch("/api/checkBilling");
    const resp1 = await resp.json();
    setStatus(resp1.hasPayment);
    if (!resp1.hasPayment) {
      window.top.location.href = resp1.url;
    }
  }, []);
  const [showSaleStrip, setShowSaleStrip] = useState(false);
  const [showDoneButton, setShowDoneButton] = useState(false);
  return status ? (
    <div className="checkout-pro-container">
      <Page>
        <TitleBar title="" primaryAction={null} />
        <Layout>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Single Click Discounts"
                description="Show discount coupons from the Shopify coupons list to be directly applied on the checkout page."
                videoSource={CouponBlockVideo}
                buttonText="Configure coupon"
                path="/CouponCode"
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Checkout Banners"
                description="Apply multiple promotional banners across different checkout stages to enhance customer experience."
                videoSource={BannerBlockVideo}
                buttonText="Know more"
                path="/checkoutbanner"
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Payment Gateway Reorder"
                description="Provides flexibility by enabling merchants to rearrange the sequence of payment gateways"
                buttonText="Rearrange now"
                videoSource={PaymentReorderBlockVideo}
                path="/payment-reorder"
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Product discount blocker"
                description="Remove discounts from the cart if non-discountable products are present. Works only on discount coupons."
                buttonText="Know more"
                imageSource={DiscountBlocker}
                path="/productDiscountBlocker"
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Prepaid discount"
                description="Treat your customers with exclusive discounts as a reward for every online payment purchase."
                buttonText="Configure discount"
                imageSource={PrepaidDiscount}
                path={prePaidDiscountPath}
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Add a free gift to a product."
                description="Elevate your shopping experience with the ability to effortlessly add a complimentary gift to your purchase."
                buttonText="Create freebie"
                imageSource={FreebieDiscount}
                path={freebieDiscountPath}
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Add a custom field"
                description="Streamline Checkout: Empower merchants to gather custom data seamlessly during the buying process, from GST numbers to special instructions."
                buttonText="Create custom field"
                imageSource={CustomField}
                path={createCustomFieldPath}
              />
            </Layout.Section>
          </div>
          <div className="custom-one-third">
            <Layout.Section oneThird>
              <IntroCard
                title="Dynamic content"
                description="Streamline Checkout: Empower merchantsEmpowerEmpower to gather custom data seamlessly  to gather custom data se during the buying ."
                buttonText="Add"
                imageSource={CustomField}
                path={dynamicContentPath}
              />
            </Layout.Section>
          </div>
        </Layout>
        <SupportFooter />
      </Page>
    </div>
  ) : (
    <> </>
  );
}
