import { useEffect, useState } from "react";
import {
  CalloutCard,
  Page,
  Layout,
  Grid,
  Card,
  Link,
  Button,
  ButtonGroup,
  Icon,
  Stack,
  DisplayText,
} from "@shopify/polaris";
import "../styles/CustomStyles.css";
import { useNavigate } from "react-router-dom";
import { SupportFooter } from "../components/supportFooter";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAppBridge } from "@shopify/app-bridge-react";
import {
  ViewMajor,
  AppExtensionMinor,
  InfoMinor,
} from "@shopify/polaris-icons";
import { useAuthenticatedFetch } from "../hooks";

import { Confused } from "../assets";
import sadSvg from "../assets/sad.svg";
import happySvg from "../assets/happy.svg";
import info from "../assets/info.svg";

// Custom hook to redirect to checkout customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}
export default function HomePage() {
  const navigate = useNavigate();
  const [data, setData] = useState();
  const fetch = useAuthenticatedFetch();

  // fetching data to get plan details

  const fetchData = async () => {
    try {
      const URL = `/api/plans/list`;
      const response = await fetch(URL);
      let result = await response.json();
      setData(result.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const redirect = useRedirectToCustomizations();
  const creditLeftMsg =
    (data?.viewCount || 0) + " / " + (data?.activePlan?.viewLimit || 0) || 0;
  const handleClick = () => {
    navigate("/Pricing");
  };

  const CardSection = ({ iconSource, heading, value, handleClick }) => (
    <Card
      sectioned
      title={
        <Stack alignment="center" spacing="tight">
          <Icon source={iconSource} tone="base" />
          <h2 className="Polaris-Heading">
            <span className="headingMd">{heading}</span>
          </h2>
          <Stack.Item fill>
            <div style={{ textAlign: "end" }}>
              <Button plain onClick={handleClick}>
                <img src={info} alt="info" />
              </Button>
            </div>
          </Stack.Item>
        </Stack>
      }
    >
      <DisplayText size="Medium" style={{ fontWeight: "normal" }}>
        {value || 0}
      </DisplayText>
    </Card>
  );

  return (
    <Page narrow>
      <Layout>
        <div className="lh-0">
          <Layout.Section>
            <Grid columns={{ sm: 9 }}>
              <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 4, xl: 6 }}>
                <Card
                  title={
                    <Stack alignment="center" spacing="tight">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-rocket-takeoff-fill"
                        viewBox="0 0 16 16"
                      >
                        <path d="M12.17 9.53c2.307-2.592 3.278-4.684 3.641-6.218.21-.887.214-1.58.16-2.065a3.578 3.578 0 0 0-.108-.563 2.22 2.22 0 0 0-.078-.23V.453c-.073-.164-.168-.234-.352-.295a2.35 2.35 0 0 0-.16-.045 3.797 3.797 0 0 0-.57-.093c-.49-.044-1.19-.03-2.08.188-1.536.374-3.618 1.343-6.161 3.604l-2.4.238h-.006a2.552 2.552 0 0 0-1.524.734L.15 7.17a.512.512 0 0 0 .433.868l1.896-.271c.28-.04.592.013.955.132.232.076.437.16.655.248l.203.083c.196.816.66 1.58 1.275 2.195.613.614 1.376 1.08 2.191 1.277l.082.202c.089.218.173.424.249.657.118.363.172.676.132.956l-.271 1.9a.512.512 0 0 0 .867.433l2.382-2.386c.41-.41.668-.949.732-1.526l.24-2.408Zm.11-3.699c-.797.8-1.93.961-2.528.362-.598-.6-.436-1.733.361-2.532.798-.799 1.93-.96 2.528-.361.599.599.437 1.732-.36 2.531Z" />
                        <path d="M5.205 10.787a7.632 7.632 0 0 0 1.804 1.352c-1.118 1.007-4.929 2.028-5.054 1.903-.126-.127.737-4.189 1.839-5.18.346.69.837 1.35 1.411 1.925Z" />
                      </svg>
                      <h2 className="Polaris-Heading">
                        <span className="headingMd">Getting started</span>
                      </h2>
                    </Stack>
                  }
                  sectioned
                >
                  <div className="flex-col gap-1">
                    <span className="flex gap-1 items-center">
                      {" "}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-node-plus"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          d="M11 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM6.025 7.5a5 5 0 1 1 0 1H4A1.5 1.5 0 0 1 2.5 10h-1A1.5 1.5 0 0 1 0 8.5v-1A1.5 1.5 0 0 1 1.5 6h1A1.5 1.5 0 0 1 4 7.5h2.025zM11 5a.5.5 0 0 1 .5.5v2h2a.5.5 0 0 1 0 1h-2v2a.5.5 0 0 1-1 0v-2h-2a.5.5 0 0 1 0-1h2v-2A.5.5 0 0 1 11 5zM1.5 7a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"
                        />
                      </svg>
                      <Link
                        onClick={() => {
                          navigate("/dashboard");
                        }}
                      >
                        Create a customization
                      </Link>
                    </span>
                    <span className="flex gap-1 items-center">
                      {" "}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-cart-plus-fill"
                        viewBox="0 0 16 16"
                      >
                        <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM9 5.5V7h1.5a.5.5 0 0 1 0 1H9v1.5a.5.5 0 0 1-1 0V8H6.5a.5.5 0 0 1 0-1H8V5.5a.5.5 0 0 1 1 0z" />
                      </svg>
                      <Link onClick={redirect}>Add app block to checkout</Link>
                    </span>
                  </div>
                </Card>
              </Grid.Cell>
              <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 4, xl: 6 }}>
                <CardSection
                  iconSource={ViewMajor}
                  heading="View count"
                  value={creditLeftMsg}
                  handleClick={handleClick}
                />
              </Grid.Cell>
              <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 4, xl: 6 }}>
                <Card
                  title={
                    <Stack alignment="center" spacing="tight">
                      <Icon source={AppExtensionMinor} tone="base" />
                      <h2 className="Polaris-Heading">
                        <span className="headingMd">New features</span>
                      </h2>
                    </Stack>
                  }
                  sectioned
                >
                  <div className="flex-col gap-1">
                    <span className="flex gap-1 items-center">
                      {" "}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-input-cursor-text"
                        viewBox="0 0 16 16"
                      >
                        <path
                          fillRule="evenodd"
                          d="M5 2a.5.5 0 0 1 .5-.5c.862 0 1.573.287 2.06.566.174.099.321.198.44.286.119-.088.266-.187.44-.286A4.165 4.165 0 0 1 10.5 1.5a.5.5 0 0 1 0 1c-.638 0-1.177.213-1.564.434a3.49 3.49 0 0 0-.436.294V7.5H9a.5.5 0 0 1 0 1h-.5v4.272c.1.08.248.187.436.294.387.221.926.434 1.564.434a.5.5 0 0 1 0 1 4.165 4.165 0 0 1-2.06-.566A4.561 4.561 0 0 1 8 13.65a4.561 4.561 0 0 1-.44.285 4.165 4.165 0 0 1-2.06.566.5.5 0 0 1 0-1c.638 0 1.177-.213 1.564-.434.188-.107.335-.214.436-.294V8.5H7a.5.5 0 0 1 0-1h.5V3.228a3.49 3.49 0 0 0-.436-.294A3.166 3.166 0 0 0 5.5 2.5.5.5 0 0 1 5 2z"
                        />
                        <path d="M10 5h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-4v1h4a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-4v1zM6 5V4H2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v-1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h4z" />
                      </svg>
                      <Link
                        onClick={() => {
                          navigate("/custom-field");
                        }}
                      >
                        Custom fields
                      </Link>
                    </span>
                    <span className="flex gap-1 items-center">
                      {" "}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-app-indicator"
                        viewBox="0 0 16 16"
                      >
                        <path d="M5.5 2A3.5 3.5 0 0 0 2 5.5v5A3.5 3.5 0 0 0 5.5 14h5a3.5 3.5 0 0 0 3.5-3.5V8a.5.5 0 0 1 1 0v2.5a4.5 4.5 0 0 1-4.5 4.5h-5A4.5 4.5 0 0 1 1 10.5v-5A4.5 4.5 0 0 1 5.5 1H8a.5.5 0 0 1 0 1H5.5z" />
                        <path d="M16 3a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                      </svg>
                      <Link
                        onClick={() => {
                          navigate("/dynamic-content");
                        }}
                      >
                        Dynamic Blocks
                      </Link>
                    </span>
                  </div>
                </Card>
              </Grid.Cell>
              <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 4, xl: 6 }}>
                <Card title="Share your feedback" sectioned>
                  How would you describe your experience using the checkout pro?
                  mail us your feedback at :
                  <Link url="mailto:support@checkoutextension.com">
                    support@checkoutextension.com
                  </Link>
                  {/*
                Info: Commenting as of now !
                <div className="pt-1">
                  <ButtonGroup gap="loose">

                    <Link url="https://apps.shopify.com/checkout-banner#modal-show=WriteReviewModal">
                      <img src={happySvg} alt="Happy" />
                      Good
                    </Link>
                    
                     <Link url="https://apps.shopify.com/checkout-banner#modal-show=WriteReviewModal">
                      <img src={sadSvg} alt="Sad" />
                      Bad
                  </ButtonGroup>
                </div>
                    </Link> */}
                </Card>
              </Grid.Cell>
              <Grid.Cell columnSpan={{ xs: 6, sm: 9, md: 9, lg: 8, xl: 9 }}>
                <CalloutCard
                  title="Help center"
                  illustration={Confused}
                  primaryAction={{
                    variant: "primary",
                    content: "Contact us",
                    onAction: () => {
                      window.open(
                        "mailto:support@checkoutextension.com",
                        "_blank"
                      );
                    },
                  }}
                >
                  <p>
                    Have a question or need assistance? Reach out to our
                    dedicated support team.
                  </p>
                </CalloutCard>
              </Grid.Cell>
            </Grid>
          </Layout.Section>
        </div>
      </Layout>
    </Page>
  );
}
