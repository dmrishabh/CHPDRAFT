import React, { useState, useCallback, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAuthenticatedFetch } from "../../../hooks";
import {
  Page,
  Toast,
  Frame,
  Layout,
  TextField,
  Stack,
  Card,
  Form,
  Button,
  TextContainer,
  Banner,
} from "@shopify/polaris";
import { SupportFooter } from "../../../components/supportFooter.jsx";
import "../../../styles/PrepaidStyles.css";

// A utility hook for getting the details for the discount customization
function useGetCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (discountCustomization) => {
      return await fetch("/api/prepaidDiscount/details", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(discountCustomization),
      });
  }
}

// A utility hook for updating the function data
function useUpdateCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (discountCustomization) => {
      return await fetch("/api/prepaidDiscount/update", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(discountCustomization),
      });
  }
}

// A utility hook for redirecting back to the checkout theme customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

export default function NewCustomizationPage() {
  // Read the function ID from the URL
  const { functionId, id } = useParams();

  // Utility hooks
  const getCustomization = useGetCustomization();
  const updateCustomization = useUpdateCustomization();
  const redirect = useRedirectToCustomizations();
  const navigate = useNavigate();

  // Page state management
  const [data, setData] = useState({});
  const [title, setTitle] = useState("Prepaid Discount");
  const [discountPercentage, setDiscountPercentage] = useState(5);
  const [uptoAmount, setUptoAmount] = useState("");
  const [metafieldId,setMetafieldId] = useState("");
  const [startAtTimeStamp, setStartAtTimeStamp] = useState(new Date());
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState();
  const [errorMessage, setErrorMessage] = useState();



  // Input States
  const handleTitleChange = useCallback((value) => setTitle(value), []);
  const handlePercentageChange = useCallback((value) => setDiscountPercentage(value),[]);
  const handleAmountChange = useCallback((value) => setUptoAmount(value), []);

  useEffect(async() => {
    setIsLoading(true);
    const response = await getCustomization({id});
    const dataJSON = await response.json();
    const configuration = JSON.parse(
      dataJSON?.metafield?.value ?? "{}"
    );

    if(configuration && dataJSON && dataJSON?.discount ){
      setTitle(dataJSON.discount.title);
      setDiscountPercentage(parseInt(configuration.percentage));
      setUptoAmount(parseInt(configuration.uptoAmount));
      setMetafieldId(dataJSON.metafield.id);
    }

    setIsLoading(false);
  },[id]);

  useEffect(async () => {
    setData({
      title: title,
      discountPercentage: parseInt(discountPercentage),
      uptoAmount: parseInt(uptoAmount),
      id: id, 
      metafieldId: metafieldId,
    });  
  }, [title, discountPercentage, uptoAmount, metafieldId]);


  // Invoke the server endpoint when the form is submitted
  const handleSubmit = useCallback(
    async (event) => {
      event.preventDefault();

      // Make the fetch POST request to update
      // await createCustomization({ data });
      console.log('Handle Discount Updating')
      console.log(data);

      setIsLoading(true);
      const response = await updateCustomization({
        data,
      });
      if (response.status != 200) {
        const errorResponse = await response.json();
        
        console.log(
          "Error Updating discount customization: ",
          errorResponse.error
        );
        setErrorMessage("Error Updating discount customization", errorResponse.error);

      } else {
        setSuccessMessage("Discount updated successfully");

        console.log('Success')
      }
      setIsLoading(false);
    },
    [data]
  );


  // Navigating back to home page of app
  const onActionHandler = () => {
    navigate("/");
  };

  return (
    // Show Coupon if already created and active/exist and provide a link to go to the coupon and change

    <Page
      breadcrumbs={[{ onAction: () => onActionHandler() }]}
      title="Edit Prepaid Discount"
      narrow
    >
      
      <div style={{ height: "1px" }}>
        <Frame>
          {errorMessage && (
            <Toast
              content={errorMessage}
              error
              onDismiss={() => setErrorMessage("")}
            />
          )}
        </Frame>
      </div>
       <div style={{ height: "1px" }}>
        <Frame>
          {successMessage && (
            <Toast
              content={successMessage}
              onDismiss={() => setSuccessMessage("")} 
            />
          )}
        </Frame>
      </div>
      <Layout>
        <Layout.Section>
          <Form onSubmit={handleSubmit}>
            <Card title="Discount Configuration">
              <Card.Section>
                <Stack vertical spacing="loose">
                  <TextField
                    onChange={handleTitleChange}
                    label="Discount title"
                    value={title}
                    helpText="This will shows as discount message"
                    requiredIndicator={true}
                    disabled={isLoading}
                  />
                  <TextField
                    label="Discount percentage"
                    value={discountPercentage}
                    suffix="%"
                    max="100"
                    min="1"
                    type="number"
                    helpText="Make it 100% if you wish to offer amount off and add in"
                    onChange={handlePercentageChange}
                    requiredIndicator={true}
                    disabled={isLoading}
                  />
                  <TextField
                    type="number"
                    label="Discount upto (amount)"
                    value={uptoAmount}
                    min="0"
                    helpText="Enter maximum capped amount for discount"
                    onChange={handleAmountChange}
                    disabled={isLoading}
                  />
                  <Button primary submit loading={isLoading}>
                    Update Discount
                  </Button>
                </Stack>
              </Card.Section>
            </Card>
          </Form>
        </Layout.Section>
        <Layout.Section secondary>
          <Card title="Add extension in the checkout editor." sectioned>
            <TextContainer>
              Blocks will not show inside checkout until you add a Prepaid
              Discount extension in the checkout editor.
            </TextContainer>

            <div className="mt-5">
              <Button onClick={redirect} primary>
                Open checkout editor
              </Button>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
      <SupportFooter />
    </Page>
  );
}