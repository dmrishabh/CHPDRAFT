import React, { useState, useCallback, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { useAuthenticatedFetch } from "../../../hooks";
import { CirclePlusMinor } from "@shopify/polaris-icons";
import {
  Page,
  Icon,
  Toast,
  Frame,
  Layout,
  TextField,
  Stack,
  Card,
  Form,
  Button,
  TextContainer,
  Banner,
  SkeletonPage,
  SkeletonBodyText,
} from "@shopify/polaris";
import { SupportFooter } from "../../../components/supportFooter.jsx";
import "../../../styles/PrepaidStyles.css";

// A utility hook for invoking the server endpoint that you created
function useCreateCustomization() {
  const fetch = useAuthenticatedFetch();
  return async (paymentCustomization) => {
    try {
      const res = await fetch("/api/prepaidDiscount/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentCustomization),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// A utility hook to check if there is already a function added
function useActiveFunction() {
  const fetch = useAuthenticatedFetch();
  return async (functionId) => {
    return await fetch("/api/prepaidDiscount/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(functionId),
    });
  };
}

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToDiscount() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/discounts",
    });
  };
}
// A utility hook for redirecting back to the checkout theme customizer
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
    redirect.dispatch(Redirect.Action.ADMIN_PATH, {
      path: "/settings/checkout/editor?extensionPicker=true",
    });
  };
}

export default function NewCustomizationPage() {
  // Read the function ID from the URL
  const { functionId } = useParams();

  // Utility hooks
  const createCustomization = useCreateCustomization();
  const redirectToDiscount = useRedirectToDiscount();
  const redirect = useRedirectToCustomizations();
  const activeFunction = useActiveFunction();
  const navigate = useNavigate();

  // Page state management
  const [data, setData] = useState({});
  const [title, setTitle] = useState("Prepaid Discount");
  const [discountPercentage, setDiscountPercentage] = useState(5);
  const [uptoAmount, setUptoAmount] = useState("");
  const [startAtTimeStamp, setStartAtTimeStamp] = useState(new Date());
  const [isLoading, setIsLoading] = useState(false);
  const [isBtnLoading, setIsBtnLoading] = useState(false);
  const [editUrl, setEditUrl] = useState();
  const [errorMessage, setErrorMessage] = useState();
  const [successMessage, setSuccessMessage] = useState();

  // Input States
  const handleTitleChange = useCallback((value) => setTitle(value), []);
  const handlePercentageChange = useCallback(
    (value) => setDiscountPercentage(value),
    []
  );
  const handleAmountChange = useCallback((value) => setUptoAmount(value), []);
  const toggleActive = useCallback(() => setActive((active) => !active), []);

  useEffect(async () => {
    setIsLoading(true);
    // Check if discount is already created and exist on shopify
    // Also check if its is active
    const response = await activeFunction({ functionId });
    const dataJSON = await response.json();
    if (dataJSON?.existingDiscount) {
      setEditUrl(dataJSON?.existingDiscount?.discountEditURL);
    }

    if (dataJSON && dataJSON.isFunctionAlreadyCreated) {
      navigate(dataJSON.storeFunctionEditURL);
    }

    setIsLoading(false);
  }, []);

  useEffect(async () => {
    setData({
      title: title,
      discountPercentage: parseInt(discountPercentage),
      uptoAmount: parseInt(uptoAmount),
      startsAt: startAtTimeStamp,
      functionId: functionId,
    });
  }, [title, discountPercentage, uptoAmount]);

  const handleSubmit = useCallback(
    async (event) => {
      setIsBtnLoading(true);
      event.preventDefault();
      // Make the fetch POST request to update
      let resData;
      try {
        resData = await createCustomization({ data });
        if (resData.status !== 200) {
          setErrorMessage("An error occurred while processing your request.");
        } else {
          setSuccessMessage("Discount created successfully");
          redirectToDiscount();
        }
      } catch (error) {
        console.log(error);
      }

      setIsBtnLoading(false);
    },
    [data]
  );

  // Navigating back to home page of app
  const onActionHandler = () => {
    navigate("/");
  };
  return (
    // Show Coupon if already created and active/exist and provide a link to go to the coupon and change

    <Page
      breadcrumbs={[{ onAction: () => onActionHandler() }]}
      title="Prepaid Discount"
      narrow
    >
      <div style={{ height: "1px" }}>
        <Frame>
          {errorMessage && (
            <Toast
              content={errorMessage}
              error
              onDismiss={() => setErrorMessage("")}
            />
          )}
        </Frame>
      </div>
      <div style={{ height: "1px" }}>
        <Frame>
          {successMessage && (
            <Toast
              content={successMessage}
              onDismiss={() => setSuccessMessage("")}
            />
          )}
        </Frame>
      </div>
      {editUrl ? (
        <Banner
          action={{
            content: "Edit discount",
            onAction: () => {
              navigate(editUrl);
            },
          }}
          status="warning"
          title="Discount already exists"
        >
          We’re pleased to inform you that the discount coupon you mentioned has
          already been created and is ready for use.
        </Banner>
      ) : (
        <></>
      )}
      {isLoading ? (
        <SkeletonPage primaryAction>
          <Layout>
            <Layout.Section>
              <Card sectioned>
                <SkeletonBodyText />
              </Card>
            </Layout.Section>
          </Layout>
        </SkeletonPage>
      ) : (
        <Layout>
          <Layout.Section>
            <Form onSubmit={handleSubmit}>
              <Card title="Discount Configuration">
                <Card.Section>
                  <Stack vertical spacing="loose">
                    <TextField
                      onChange={handleTitleChange}
                      label="Discount title"
                      value={title}
                      helpText="This will shows as discount message"
                      requiredIndicator={true}
                    />
                    <TextField
                      label="Discount percentage"
                      value={discountPercentage}
                      suffix="%"
                      max="100"
                      min="1"
                      type="number"
                      helpText="Make it 100% if you wish to offer amount off and add in"
                      onChange={handlePercentageChange}
                      requiredIndicator={true}
                    />
                    <TextField
                      type="number"
                      label="Discount upto (amount)"
                      value={uptoAmount}
                      min="0"
                      helpText="Enter maximum capped amount for discount"
                      onChange={handleAmountChange}
                    />
                    <Button primary submit loading={isBtnLoading}>
                      Create Discount
                    </Button>
                  </Stack>
                </Card.Section>
              </Card>
            </Form>
          </Layout.Section>

          <Layout.Section secondary>
            <Card title="Add extension in the checkout editor." sectioned>
              <TextContainer>
                Blocks will not show inside checkout until you add a Prepaid
                Discount extension in the checkout editor.
              </TextContainer>

              <div className="mt-5">
                <Button onClick={redirect} primary>
                  Open checkout editor
                </Button>
              </div>
            </Card>
          </Layout.Section>
        </Layout>
      )}
      <SupportFooter />
    </Page>
  );
}
