import { Button, Card, Page, Layout, Link, TextContainer,Icon } from "@shopify/polaris";
import { useNavigate } from "react-router-dom";
import { SupportFooter } from "../../components/supportFooter"
import { useAppBridge } from "@shopify/app-bridge-react";
import { Redirect } from "@shopify/app-bridge/actions";
import { CirclePlusMinor } from "@shopify/polaris-icons";

// A utility hook for redirecting back to the Payment Customizations list
function useRedirectToCustomizations() {
  const app = useAppBridge();
  const redirect = Redirect.create(app);
  return () => {
      redirect.dispatch(Redirect.Action.ADMIN_PATH, {
          path: "/settings/payments/customizations",
      });
  }
}

export default function PageName() {
  const navigate = useNavigate();
  const redirect = useRedirectToCustomizations();
  const onActionHandler = () => {
    navigate("/");
  };

  return (
    <Page
      breadcrumbs={[{ onAction: () => onActionHandler() }]}
      title="Prepaid Discount"
      subtitle="Promote customers to opt in for online payments by offering custom prepaid discount"
    >
      <Layout>
        <Layout.Section secondary>
            <Card title="Add extension in the checkout editor." sectioned>
              <TextContainer>
                Blocks will not show inside checkout until you add a Prepaid
                Discount extension in the checkout editor.
              </TextContainer>

              <div className="mt-5">
                <Button onClick={redirect} plain>
                  <div className="flex">
                    <Icon source={CirclePlusMinor} />
                    Open checkout editor
                  </div>
                </Button>
              </div>
            </Card>
          </Layout.Section>
      </Layout>
      <SupportFooter/>
    </Page>
  );
}
