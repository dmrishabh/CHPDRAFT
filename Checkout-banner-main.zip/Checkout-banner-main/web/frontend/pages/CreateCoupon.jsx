import {
  Button,
  Card,
  Page,
  Autocomplete,
  Icon,
  Form,
  FormLayout,
  TextField,
  Stack,
  Checkbox,
} from "@shopify/polaris";
import { useNavigate } from "react-router-dom";
import { SearchMinor } from "@shopify/polaris-icons";
import { useState, useCallback, useEffect } from "react";
import { useAuthenticatedFetch } from "../hooks";
import { SupportFooter } from "../components/supportFooter"

// Function to clean the data received
function cleanCouponsData(coupon) {
  return {
    value: coupon.code,
    label: `${coupon.code} • ${coupon.summery}`,
    summery: coupon.summery,
    id: coupon.id
  }
}

export default function CreateCoupon() {
  const [topFiveCoupons, setTopFiveCoupons] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [options, setOptions] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [id, setID] = useState("");
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [couponActive, setCouponActive] = useState(true);
  const [searchLoading, setSearchLoading] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);
  const fetch = useAuthenticatedFetch();

  // To make coupon Enabled or not
  const handleChange = useCallback(
    (newChecked) => setCouponActive(newChecked),
    [],
  );

  // Handle Form submissions
  const handleSubmit = useCallback((event) => {
    

    event.preventDefault();
    setSaveLoading(true);

    const data = {
      "gid": id,
      "title": title,
      "subtitle": subtitle,
      "status": couponActive ? 'Active' : 'Deactivate'
    };

    // Make the fetch POST request
    fetch('/api/coupon/add', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then((responseData) => {
        // Handle the response data
        setSaveLoading(false);
        navigate("/CouponCode")
      })
      .catch((error) => {
        // Handle any error that occurred during the request
        setSaveLoading(false);
        console.error('Error submitting form:', error);
      });

  }, [id, title, subtitle, couponActive]);
  
  const handleTitleChange = useCallback((value) => setTitle(value), []);
  const handleSubtitleChange = useCallback((value) => setSubtitle(value), []);

  // Calling to get the top 5 coupons 
  useEffect(async () => {
    const URL = "/api/coupon/query"
    const response = await fetch(URL);
    let result = await response.json();

    let filterCoupons = await result.data.map(cleanCouponsData);

    setTopFiveCoupons(filterCoupons);
    setOptions(filterCoupons);
  }, []);

  // Debounce function to delay API calls on search keyboard input
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (inputValue) {
        search();
      }
    }, 500);

    return () => {
      clearTimeout(delayDebounceFn);
    };
  }, [inputValue]);

  const search = async () => {
    try {

      setSearchLoading(true);

      const URL = "/api/coupon/query?text="+inputValue;
      const response = await fetch(URL);
      let result = await response.json();

      // Not optimized code. React developer has to optimize the code if require we can make use of usememo
      let searchValue = await result.data.map(cleanCouponsData);

      setOptions(searchValue);
      setSearchLoading(false);
    } catch (error) {
      console.error('Error searching:', error);
      setSearchLoading(false);
    }
  };

  const updateText = useCallback(
    (value) => {
      setInputValue(value);
      if (value === "" || !value ) {
        setOptions(topFiveCoupons);
        return;
      }
    },
    [topFiveCoupons]
  );

  const updateSelection = useCallback(
    (selected) => {
      const selectedValue = selected.map((selectedItem) => {
        const matchedOption = options.find((option) => {
          return option.value === selectedItem;
        });
        return matchedOption && { 
          value: matchedOption.value ,
          label: matchedOption.label ,
          summery: matchedOption.summery,
          id: matchedOption.id
        };
      });

      setSelectedOptions(selected);
      setInputValue(selectedValue[0].value || "");

      // Updating the coupon value
      setID(selectedValue[0].id || "");
      setTitle(selectedValue[0].value || "");
      setSubtitle(selectedValue[0].summery || "");
    },
    [options]
  );

  const textField = (
    <Autocomplete.TextField
      onChange={updateText}
      label="Discount Coupon Code"
      value={inputValue}
      placeholder="Search within the coupons created on Shopify Dashboard."
      autoComplete="off"
      prefix={<Icon source={SearchMinor} />}
    />
  );

  const navigate = useNavigate();
  const onActionHandler = () => {
    navigate("/couponcode");
  };

  return (
    <Page
      breadcrumbs={[{ onAction: () => onActionHandler() }]}
      title="Create coupon"
    >
      <Form onSubmit={handleSubmit}> 
        <FormLayout>
          <Card sectioned >
              <Autocomplete
                options={options}
                selected={selectedOptions}
                onSelect={updateSelection}
                textField={textField}
                loading={searchLoading}
              />
          </Card>
          <Card sectioned >
            <Stack vertical spacing="loose" fill>
              <TextField
                value={title}
                onChange={handleTitleChange}
                label="Discount Coupon Title"
                type="text"
                autoComplete="off"
                placeholder="FREE10"
                helpText={<span>You can create a coupon title to attract customers attention.</span>}
              />
              <TextField
                value={subtitle}
                onChange={handleSubtitleChange}
                label="Discount Coupon Subtitle"
                type="text"
                autoComplete="off"
                placeholder="E.g. get flat 10% off"
                helpText={<span>You can add brief description for customer understanding.</span>}
              />
              <Checkbox
                label="Coupon available for customer usage"
                helpText={<span>Clicking this will make the coupon visible for customers to use.</span>}
                checked={couponActive}
                onChange={handleChange}
              />
            </Stack>
          </Card>
          
          <div className="text-right">
            {" "}
            <Button primary submit loading={saveLoading}>
              Save
            </Button>
          </div>
        </FormLayout>
      </Form>
      <SupportFooter/>
    </Page>
  );
}
