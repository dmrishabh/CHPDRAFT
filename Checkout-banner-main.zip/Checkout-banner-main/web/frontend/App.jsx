import { BrowserRouter } from "react-router-dom";
import { NavigationMenu } from "@shopify/app-bridge-react";
import Routes from "./Routes";

import {
  AppBridgeProvider,
  QueryProvider,
  PolarisProvider,
} from "./components";
const FUNCTION_ID = "1864d648-b879-4e3a-9116-0c4d1a8f0203";
const prePaidDiscountPath = "/prepaid-discount/" + FUNCTION_ID + "/new";
export default function App() {
  // Any .tsx or .jsx files in /pages will become a route
  // See documentation for <Routes /> for more info
  const pages = import.meta.globEager("./pages/**/!(*.test.[jt]sx)*.([jt]sx)");

  return (
    <PolarisProvider>
      <BrowserRouter>
        <AppBridgeProvider>
          <QueryProvider>
            <NavigationMenu
              navigationLinks={[
                {
                  label: "Payment Gateway Reorder",
                  destination: "/payment-reorder",
                },
                {
                  label: "Single Click Discount",
                  destination: "/couponcode",
                },
                {
                  label: "Checkout Banner",
                  destination: "/checkoutbanner",
                },
                {
                  label: "Prepaid Discount",
                  destination: prePaidDiscountPath,
                },
                {
                  label: "Pricing",
                  destination: "/pricing",
                },
              ]}
            />
            <Routes pages={pages} />
          </QueryProvider>
        </AppBridgeProvider>
      </BrowserRouter>
    </PolarisProvider>
  );
}
