import React from 'react'
import { Button } from '@shopify/polaris';
const [button, setButton] = useState(true);

const flexWrapper = {
  display: "flex",
  justifyContent: "space-between",
};
const action_card_container = {
  display: "flex",
  width: "100%",
  justifyContent: "space-between",
};
const action_card_container_mobile = {
  flexWrap: "wrap",
  gap: ".5rem",
};
const flexItem = {
  width: "49%",
};
const wFull = {
  width: "100%",
};
const buttonStyle = {
  marginRight: "1rem",
};
const accordionSummary = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  borderBottom: "1px solid #d5d5d5",
};
const defaultNone = {
  outline: "none",
  border: "none",
  boxShadow: "none",
};
const fontSm = {
  fontSize: ".7rem",
  lineHeight: "normal",
  fontWeight: "400",
};
function temp() {
  return (
    <div>
        
        {showSaleStrip ? (
          <Layout.Section>
            <Card sectioned>
              <div style={flexWrapper}>
                <div style={flexItem}> Sales</div>
                <div style={flexItem}> Views</div>
              </div>
            </Card>
          </Layout.Section>
        ) : (
          <></>
        )}
        // Button
        {button ? (
          <Layout.Section>
            <div
              className="action_card_container"
              style={
                window.innerWidth > 749
                  ? action_card_container
                  : action_card_container_mobile
              }
            >
              <div
                className="card_one"
                style={window.innerWidth > 749 ? flexItem : wFull}
              >
                <Card title="Complete The Following Steps">
                  <ul className="steps_container step_lh_3">
                    <li className="step">
                      <strong> Step 1:</strong> In shopify admin panel open{" "}
                      <em>Settings</em> by clicking on
                      <span>
                        <svg
                          viewBox="0 0 20 20"
                          class="Polaris-Icon__Svg_375hu"
                          focusable="false"
                          aria-hidden="true"
                        >
                          <path d="M10 13a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm7.476-1.246c-1.394-.754-1.394-2.754 0-3.508a1 1 0 0 0 .376-1.404l-1.067-1.733a1 1 0 0 0-1.327-.355l-.447.243c-1.329.719-2.945-.244-2.945-1.755v-.242a1 1 0 0 0-1-1h-2.132a1 1 0 0 0-1 1v.242c0 1.511-1.616 2.474-2.945 1.755l-.447-.243a1 1 0 0 0-1.327.355l-1.067 1.733a1 1 0 0 0 .376 1.404c1.394.754 1.394 2.754 0 3.508a1 1 0 0 0-.376 1.404l1.067 1.733a1 1 0 0 0 1.327.355l.447-.243c1.329-.719 2.945.244 2.945 1.755v.242a1 1 0 0 0 1 1h2.132a1 1 0 0 0 1-1v-.242c0-1.511 1.616-2.474 2.945-1.755l.447.243a1 1 0 0 0 1.327-.355l1.067-1.733a1 1 0 0 0-.376-1.404z"></path>
                        </svg>
                      </span>
                      Settings button.
                    </li>
                    <li className="step">
                      <strong> Step 2:</strong> Go to checkout settings{" "}
                      <span>
                        <svg
                          viewBox="0 0 20 20"
                          class="Polaris-Icon__Svg_375hu"
                          focusable="false"
                          aria-hidden="true"
                        >
                          <path
                            fill-rule="evenodd"
                            d="M1 1c0-.552.45-1 1.004-1h1.505c.831 0 1.505.672 1.505 1.5v.56l12.574.908c.877.055 1.52.843 1.397 1.71l-.866 6.034a1.504 1.504 0 0 1-1.489 1.288h-11.616v2h10.043a3.005 3.005 0 0 1 3.011 3c0 1.657-1.348 3-3.01 3a3.005 3.005 0 0 1-2.84-4h-5.368a3.005 3.005 0 0 1-2.84 4 3.005 3.005 0 0 1-3.01-3c0-1.306.838-2.418 2.007-2.83v-12.17h-1.003a1.002 1.002 0 0 1-1.004-1zm13.054 16c0-.552.449-1 1.003-1 .554 0 1.004.448 1.004 1s-.45 1-1.004 1a1.002 1.002 0 0 1-1.003-1zm-11.047 0c0-.552.45-1 1.004-1s1.003.448 1.003 1-.449 1-1.003 1a1.002 1.002 0 0 1-1.004-1z"
                          ></path>
                        </svg>
                      </span>
                    </li>
                    <li className="step">
                      <strong> Step 3:</strong> Click on{" "}
                      <em>Go to checkout editor</em> button.
                    </li>
                    <li className="step">
                      <strong> Step 4:</strong> Click on the{" "}
                      <span>
                        <svg
                          viewBox="0 0 20 20"
                          class="Polaris-Icon__Svg_375hu"
                          focusable="false"
                          aria-hidden="true"
                        >
                          <path d="M0 10c0 5.514 4.486 10 10 10s10-4.486 10-10-4.486-10-10-10-10 4.486-10 10zm5 0a1 1 0 0 1 1-1h3v-3a1 1 0 1 1 2 0v3h3a1 1 0 1 1 0 2h-3v3a1 1 0 1 1-2 0v-3h-3a1 1 0 0 1-1-1z"></path>
                        </svg>
                        Add app
                      </span>{" "}
                      button below to add extension
                    </li>
                    <li className="step">
                      <strong> Step 5:</strong> Click checkout banner that will
                      add an app block
                    </li>
                    <li className="step">
                      <strong> Step 6:</strong> Add data in all required fields
                      ( Desktop image url, Mobile image url, link for image
                      click, and a descriptive Alt text )
                    </li>
                    <span style={fontSm}>
                      <strong>Note:</strong> We can have different banner for
                      all of checkout pages as <em>Information page</em>,{" "}
                      <em>Shipping page</em> and <em>Payment page</em>.
                    </span>
                  </ul>
                  <div className="btn_wrapper" style={flexWrapper}>
                    {showDoneButton ? (
                      <Button
                        primary
                        onClick={() => {
                          handleClick();
                        }}
                        style={buttonStyle}
                      >
                        Mark as done
                      </Button>
                    ) : (
                      <></>
                    )}
                  </div>
                </Card>
              </div>
              <div
                className="card_two"
                style={window.innerWidth > 749 ? flexItem : wFull}
              >
                <Card>
                  <img
                    src="https://cdn.shopify.com/s/files/1/0660/6657/9705/files/ezgif.com-optimize.gif?v=1681996230"
                    alt="demo_gify"
                  />
                </Card>
              </div>
            </div>
          </Layout.Section>
        ) : (
          <></>
        )}
        {/* faq */}
        {/* Faq section */}
        <Layout.Section>
          <div>
            <Card title="Frequently asked questions" sectioned>
              {/* Que start */}
              <details>
                <summary style={accordionSummary}>
                  <span>How to add the block ?</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="#616a75"
                    class="bi bi-chevron-down Polaris-Icon__Svg_375hu"
                    viewBox="0 0 16 16"
                  >
                    <path
                      fill-rule="evenodd"
                      fill="#d5d5d5"
                      d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    />
                  </svg>
                </summary>
                <ul className="steps_container">
                  <li className="step">
                    <strong> Step 1:</strong>In shopify admin panel open{" "}
                    <em>Settings</em> by clicking on
                    <span>
                      <svg
                        viewBox="0 0 20 20"
                        class="Polaris-Icon__Svg_375hu"
                        focusable="false"
                        aria-hidden="true"
                      >
                        <path d="M10 13a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm7.476-1.246c-1.394-.754-1.394-2.754 0-3.508a1 1 0 0 0 .376-1.404l-1.067-1.733a1 1 0 0 0-1.327-.355l-.447.243c-1.329.719-2.945-.244-2.945-1.755v-.242a1 1 0 0 0-1-1h-2.132a1 1 0 0 0-1 1v.242c0 1.511-1.616 2.474-2.945 1.755l-.447-.243a1 1 0 0 0-1.327.355l-1.067 1.733a1 1 0 0 0 .376 1.404c1.394.754 1.394 2.754 0 3.508a1 1 0 0 0-.376 1.404l1.067 1.733a1 1 0 0 0 1.327.355l.447-.243c1.329-.719 2.945.244 2.945 1.755v.242a1 1 0 0 0 1 1h2.132a1 1 0 0 0 1-1v-.242c0-1.511 1.616-2.474 2.945-1.755l.447.243a1 1 0 0 0 1.327-.355l1.067-1.733a1 1 0 0 0-.376-1.404z"></path>
                      </svg>
                    </span>
                    Settings button.
                  </li>
                  <li className="step">
                    <strong> Step 2:</strong> Go to checkout settings{" "}
                    <span>
                      <svg
                        viewBox="0 0 20 20"
                        class="Polaris-Icon__Svg_375hu"
                        focusable="false"
                        aria-hidden="true"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M1 1c0-.552.45-1 1.004-1h1.505c.831 0 1.505.672 1.505 1.5v.56l12.574.908c.877.055 1.52.843 1.397 1.71l-.866 6.034a1.504 1.504 0 0 1-1.489 1.288h-11.616v2h10.043a3.005 3.005 0 0 1 3.011 3c0 1.657-1.348 3-3.01 3a3.005 3.005 0 0 1-2.84-4h-5.368a3.005 3.005 0 0 1-2.84 4 3.005 3.005 0 0 1-3.01-3c0-1.306.838-2.418 2.007-2.83v-12.17h-1.003a1.002 1.002 0 0 1-1.004-1zm13.054 16c0-.552.449-1 1.003-1 .554 0 1.004.448 1.004 1s-.45 1-1.004 1a1.002 1.002 0 0 1-1.003-1zm-11.047 0c0-.552.45-1 1.004-1s1.003.448 1.003 1-.449 1-1.003 1a1.002 1.002 0 0 1-1.004-1z"
                        ></path>
                      </svg>
                    </span>
                  </li>
                  <li className="step">
                    <strong> Step 3:</strong> Click on{" "}
                    <em>Go to checkout editor</em> button.
                  </li>
                  <li className="step">
                    <strong> Step 4:</strong> Click on the{" "}
                    <span>
                      <svg
                        viewBox="0 0 20 20"
                        class="Polaris-Icon__Svg_375hu"
                        focusable="false"
                        aria-hidden="true"
                      >
                        <path d="M0 10c0 5.514 4.486 10 10 10s10-4.486 10-10-4.486-10-10-10-10 4.486-10 10zm5 0a1 1 0 0 1 1-1h3v-3a1 1 0 1 1 2 0v3h3a1 1 0 1 1 0 2h-3v3a1 1 0 1 1-2 0v-3h-3a1 1 0 0 1-1-1z"></path>
                      </svg>
                      Add app
                    </span>{" "}
                    button below to add extension
                  </li>
                  <li className="step">
                    <strong> Step 5:</strong> Click checkout banner that will
                    add an app block
                  </li>
                  <li className="step">
                    <strong> Step 6:</strong> Add data in all required fields (
                    Desktop image url, Mobile image url, link for image click,
                    and a descriptive Alt text )
                  </li>
                </ul>
              </details>
              {/* Que end */}
              {/* Que start */}
              <details>
                <summary style={accordionSummary}>
                  <span>
                    {" "}
                    How to get the image link for the checkout block ?{" "}
                  </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-chevron-down"
                    viewBox="0 0 16 16"
                  >
                    <path
                      fill-rule="evenodd"
                      fill="#d5d5d5"
                      d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    />
                  </svg>
                </summary>
                <p>
                  In order to get the image CDN url we can follow these easy
                  steps
                </p>
                <ul className="steps_container">
                  <li className="step">
                    <strong> Step 1: </strong> In shopify admin panel go to
                    files under content{" "}
                    <span>
                      <svg
                        viewBox="0 0 20 20"
                        class="Polaris-Icon__Svg_375hu"
                        focusable="false"
                        aria-hidden="true"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M3 5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-10a2 2 0 0 1-2-2v-6Zm3 2a1 1 0 1 0 0-2 1 1 0 0 0 0 2Zm-3 9a1 1 0 0 1 1-1h6a1 1 0 1 1 0 2h-6a1 1 0 0 1-1-1Zm13-1a1 1 0 1 1 0 2h-2a1 1 0 1 1 0-2h2Zm-4.388-8.435a1 1 0 0 1 1.8-.012l1.479 3.005a1 1 0 0 1-.898 1.442h-5.993c-.862 0-1.313-1.019-.74-1.664l.69-.996a.993.993 0 0 1 1.5 0l.418.51a.5.5 0 0 0 .828-.142l.916-2.143Z"
                        ></path>
                      </svg>
                    </span>
                  </li>
                  <li className="step">
                    <strong> Step 2: </strong> Click on <em>Upload files</em>.
                  </li>
                  <li className="step">
                    <strong> Step 3: </strong> After getting image uploaded
                    click on the{" "}
                    <span class="Polaris-Icon_yj27d">
                      <span class="Polaris-Text--root_yj4ah Polaris-Text--visuallyHidden_yrtt6"></span>
                      <svg
                        viewBox="0 0 20 20"
                        class="Polaris-Icon__Svg_375hu"
                        focusable="false"
                        aria-hidden="true"
                      >
                        <path d="M6.534 18a4.507 4.507 0 0 1-3.208-1.329 4.54 4.54 0 0 1 0-6.414l1.966-1.964a.999.999 0 1 1 1.414 1.414l-1.966 1.964a2.54 2.54 0 0 0 0 3.586c.961.959 2.631.958 3.587 0l1.966-1.964a1 1 0 1 1 1.415 1.414l-1.966 1.964a4.503 4.503 0 0 1-3.208 1.329zm7.467-6a.999.999 0 0 1-.707-1.707l1.966-1.964a2.54 2.54 0 0 0 0-3.586c-.961-.959-2.631-.957-3.587 0l-1.966 1.964a1 1 0 1 1-1.415-1.414l1.966-1.964a4.503 4.503 0 0 1 3.208-1.329c1.211 0 2.351.472 3.208 1.329a4.541 4.541 0 0 1 0 6.414l-1.966 1.964a.997.997 0 0 1-.707.293zm-6.002 1a.999.999 0 0 1-.707-1.707l4.001-4a1 1 0 1 1 1.415 1.414l-4.001 4a1 1 0 0 1-.708.293z"></path>
                      </svg>
                    </span>{" "}
                    icon and copy link.
                  </li>
                  <li className="step">
                    <strong> Step 4: </strong> Now you can paste this link in
                    checkout extensions.
                  </li>
                </ul>
                <p>
                  Checkout extension also supports non shopify CDN links for
                  image so feel free to use the image url for any other platform
                </p>
              </details>
              {/* Que end */}
              {/* Que start */}
              <details>
                <summary style={accordionSummary}>
                  <span> Best place to position the banner </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-chevron-down"
                    viewBox="0 0 16 16"
                  >
                    <path
                      fill-rule="evenodd"
                      fill="#d5d5d5"
                      d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    />
                  </svg>
                </summary>
                <p>
                  Checkout banner allows a merchant to place banner at all
                  possible extension points on the checkout page but for better
                  visibility and conversion rate we highly recommend to position
                  banner at the top of Shipping information.
                </p>
              </details>
              {/* Que end */}
              {/* Que start */}
              <details>
                <summary style={accordionSummary}>
                  <span> How to change the placement of the banner ? </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-chevron-down"
                    viewBox="0 0 16 16"
                  >
                    <path
                      fill-rule="evenodd"
                      fill="#d5d5d5"
                      d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    />
                  </svg>
                </summary>
                <p>
                  In order to change the position of the banner we can just drag
                  and reposition the extension by <em>DragHandle</em>{" "}
                  <span>
                    <svg class="Polaris-Icon__Svg_375hu" viewBox="0 0 20 20">
                      <path d="M7 2a2 2 0 1 0 .001 4.001 2 2 0 0 0-.001-4.001zm0 6a2 2 0 1 0 .001 4.001 2 2 0 0 0-.001-4.001zm0 6a2 2 0 1 0 .001 4.001 2 2 0 0 0-.001-4.001zm6-8a2 2 0 1 0-.001-4.001 2 2 0 0 0 .001 4.001zm0 2a2 2 0 1 0 .001 4.001 2 2 0 0 0-.001-4.001zm0 6a2 2 0 1 0 .001 4.001 2 2 0 0 0-.001-4.001z"></path>
                    </svg>
                  </span>{" "}
                  , as similar as we reposition the sections in shopify theme
                  editor
                </p>
              </details>
              {/* Que end */}
              {/* Que start */}
              <details>
                <summary style={accordionSummary}>
                  <span> More tips </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-chevron-down"
                    viewBox="0 0 16 16"
                  >
                    <path
                      fill-rule="evenodd"
                      fill="#d5d5d5"
                      d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    />
                  </svg>
                </summary>
                <ul className="steps_container more_help">
                  <li className="step">
                    For best picture quality use high resolution images of{" "}
                    <em>16:9</em> for desktop and <em>4:3</em> for mobile
                  </li>
                  <li className="step">
                    We can also use more than one banner on checkout page at a
                    time
                  </li>
                  <li className="step">
                    We can use <em>Gif</em> as well to grab user attentions
                  </li>
                  <li className="step">
                    We can use banner to show running offer or land users on a
                    page for better conversion
                  </li>
                  <li className="step">
                    Select the available pages, products, or product categories
                    for every banner
                  </li>
                  <li className="step">
                    Consider not to use too flashy colors use the colors in the
                    banner that syncs with brand colors.
                  </li>
                </ul>
              </details>
              {/* Que end */}
            </Card>
          </div>
        </Layout.Section>
    </div>

         {/* <Layout.Section>
          <div className="help_card_wrapper text-center">
            Need assistance? Contact our customer support team at{" "}
            <a target="_blank" href="mailto:support@checkoutextension.com">support@checkoutextension.com</a>.
          </div>
        </Layout.Section> */}
  )
}

export default temp