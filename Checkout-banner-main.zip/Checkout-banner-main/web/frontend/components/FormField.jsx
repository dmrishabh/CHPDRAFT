import { Card, Button, FormLayout, TextField, Select, Stack, InlineError, Checkbox, Icon } from '@shopify/polaris';
import { DeleteMinor } from '@shopify/polaris-icons';
import { useState, useCallback } from 'react';

export function FormField({ index, field, onUpdateField, onRemoveField }) {
  const [selected, setSelected] = useState('');

  const regexOptions = [
    {label: 'Type your own', value: ''},
    {label: 'Alphanumeric', value: '\\w+'},
    {label: 'Only Alphabet', value: '[a-zA-Z]'},
    {label: 'Only Number', value: '^\\d+$'},
    {label: 'GST', value: '^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'},
  ]

  const handleSelectChange = (value) => {
    setSelected(value);
    handleRegexChange(value);
  };

  const handleNameChange = (value) => {
    onUpdateField(index, { ...field, name: value });
  };

  const handleTypeChange = (value) => {
    onUpdateField(index, { ...field, type: value, options: [], regex: '' });
  };

  const handleAddOption = () => {
    const updatedField = { ...field, options: [...field.options, ''] };
    onUpdateField(index, updatedField);
  };

  const handleOptionChange = (optionIndex, optionValue) => {
    const updatedOptions = [...field.options];
    updatedOptions[optionIndex] = optionValue;
    onUpdateField(index, { ...field, options: updatedOptions });
  };

  const handleRemoveOption = (optionIndex) => {
    const updatedOptions = [...field.options];
    updatedOptions.splice(optionIndex, 1);
    onUpdateField(index, { ...field, options: updatedOptions });
  };

  const handleRegexChange = (value) => {
    onUpdateField(index, { ...field, regex: value, regexError: null });

    // Validate the regex pattern
    try {
      new RegExp(value);
    } catch (error) {
      onUpdateField(index, { ...field, regex: value, regexError: 'Invalid regex pattern' });
    }
  };

  const handleRequiredChange = (checked) => {
    onUpdateField(index, { ...field, required: checked });
  };

  return (
    <Card sectioned title={`Field ${index + 1}`}
      actions={[
        {
          content: <Checkbox
              label="Mandatory field ?"
              checked={field.required}
              onChange={handleRequiredChange}
            />
        }
      ]}
    >
      <FormLayout>
        <Select
          label={`Field Type`}
          options={[
            { label: 'Text', value: 'text' },
            { label: 'Date', value: 'date' },
            { label: 'Phone', value: 'phone' },
            { label: 'Dropdown', value: 'dropdown' },
          ]}
          value={field.type}
          onChange={handleTypeChange}
        />
        <TextField
          label={`Field Label`}
          value={field.name}
          onChange={handleNameChange}
        />
        {field.type === 'dropdown' && (
          <FormLayout>
            {field.options.map((option, optionIndex) => (
              <Stack key={optionIndex} spacing="tight" alignment="trailing">
                <TextField
                  label={`Option ${optionIndex + 1}`}
                  value={option}
                  onChange={(value) => handleOptionChange(optionIndex, value)}
                />
                <Button
                  outline
                  icon={DeleteMinor}
                  destructive
                  onClick={() => handleRemoveOption(optionIndex)}
                />
              </Stack>
            ))}
            <Button onClick={handleAddOption}>Add Option</Button>
          </FormLayout>
        )}
        {(field.type === 'text') && (
          <TextField
            label="Regex Pattern (Optional)"
            value={field.regex}
            onChange={handleRegexChange}
            monospaced
            placeholder="Insert your regular expression here"
            connectedLeft={
              <Select
                label="Regex Suggestions"
                labelHidden
                onChange={handleSelectChange}
                value={selected}
                options={regexOptions}
              />
            }
          />
        )}
        {field.regexError && <InlineError message={field.regexError} />}
        <Stack distribution="trailing">
          <Button plain  textAlign="right" onClick={() => onRemoveField(index)} destructive>
            Remove Field
          </Button>
        </Stack>
      </FormLayout>
    </Card>
  );
}