import { useState, useRef } from 'react';
import { Card, Button } from "@shopify/polaris";
import { PauseMinor, PlayMinor } from '@shopify/polaris-icons';
import { paymentReorderVideo } from "../assets";


export function ReorderImage() {
  const videoRef = useRef(null);
  const [isPaused, setIsPaused] = useState(false);

  const togglePause = () => {
    const video = videoRef.current;

    if (video.paused) {
      video.play();
      setIsPaused(false);
    } else {
      video.pause();
      setIsPaused(true);
    }
  };

  return (
    <Card>
      <div style={{ position: 'relative' }}>
        <video onClick={togglePause} ref={videoRef} loop={true} autoPlay="autoplay" muted style={{ borderRadius: '20px', overflow: 'hidden' , padding: '12px', width: '100%'}} >
          <source src={paymentReorderVideo} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <div style={{ position: 'absolute', top: '20px', right: '20px'}} >
          <Button
            ariaControls={ isPaused ? "Play" : "Pause" }
            icon={ isPaused ? PlayMinor : PauseMinor }
            onClick={togglePause}
            plain
          />
        </div>
      </div>
    </Card>
  );
};