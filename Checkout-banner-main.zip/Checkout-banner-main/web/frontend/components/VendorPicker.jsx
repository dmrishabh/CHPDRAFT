import {Stack, Tag, Autocomplete} from '@shopify/polaris';
import {useState, useCallback, useEffect} from 'react';

const VendorPicker = ({ isVendorLoading, vendors, selectedVendors, onSelectVendors }) => {

  const [deselectedOptions, setDeselectedOptions] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState(selectedVendors);
  const [verticalContentMarkup, setVerticalContentMarkup] = useState(null);
  const [inputValue, setInputValue] = useState('');
  const [options, setOptions] = useState([]);

  useEffect(() => {
    const deselectedOptions = vendors.map((vendor) => ({
      value: vendor,
      label: vendor,
    }));
    setDeselectedOptions(deselectedOptions);
    setOptions(deselectedOptions);
  },[vendors])

  const updateText = useCallback(
    (value) => {
      setInputValue(value);

      if (value === '') {
        setOptions(deselectedOptions);
        return;
      }

      const filterRegex = new RegExp(value, 'i');
      const resultOptions = deselectedOptions.filter((option) =>
        option.label.match(filterRegex),
      );

      setOptions(resultOptions);
    },
    [deselectedOptions],
  );

  const handleSelection = (selected) => {
    if (!selectedOptions.includes(selected)) {
      setSelectedOptions(selected)
    }
  };

  const removeTag = useCallback(
    (tag) => () => {
      const options = [...selectedOptions];
      options.splice(options.indexOf(tag), 1);
      setSelectedOptions(options);
    },
    [selectedOptions],
  );

  useEffect(() => {
    onSelectVendors(selectedOptions);

    // After selection make the input blank
    setInputValue('');
    setOptions(deselectedOptions);

    setVerticalContentMarkup(
      selectedOptions.length > 0 ? (
        <Stack spacing="extraTight" alignment="center">
          {selectedOptions.map((option) => {
            return (
              <Tag key={`option${option}`} onRemove={removeTag(option)}>
                {option}
              </Tag>
            );
          })}
        </Stack>
      ): null
    )
  },[selectedOptions])



  const textField = (
    <Autocomplete.TextField
      onChange={updateText}
      value={inputValue}
      placeholder="Search for vendors"
      verticalContent={verticalContentMarkup}
      autoComplete="off"
    />
  );

  return (
    <div style={{"maxWidth": "350px"}}>
      <Autocomplete
        allowMultiple
        options={options}
        selected={selectedOptions}
        textField={textField}
        onSelect={handleSelection}
        listTitle="Vendor list"
        loading = { isVendorLoading }
      />
    </div>
  );
}

export default VendorPicker;