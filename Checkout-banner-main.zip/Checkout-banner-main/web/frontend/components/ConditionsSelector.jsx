import { TextField, Button, IndexTable, TextContainer, Tag, Select, Stack } from '@shopify/polaris';
import { DeleteMinor, CollectionsMajor } from '@shopify/polaris-icons';
import { ResourcePicker, useAppBridge } from "@shopify/app-bridge-react";
import { useState, useEffect } from 'react';
import { useAuthenticatedFetch } from '../hooks';
import VendorPicker from './VendorPicker';

// A utility hook for invoking the server endpoint that create automatic coupon
function useGraphQLQuery() {
  const fetch = useAuthenticatedFetch();
  return async (GraphQLQuery) => {
    try {
      const res = await fetch("/api/freebieProduct/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(GraphQLQuery),
      });
      return res;
    } catch (error) {
      console.error(error);
    }
  };
}

// GraphQL query to fetch vendors
const GET_VENDORS = `{
  shop {
    productVendors(first: 250) {
      edges {
        node
      }
    }
  }
}`;

// Prepare the query for product details and fetch data
const queryForVendors = {
  query: GET_VENDORS,
  variables: {},
};


export function ConditionsSelector({ index, selectedLogic, condition, onUpdateCondition, onRemoveCondition }) {
  const [selected, setSelected] = useState('');
  const [selectOptions, setSelectOptions] = useState([]);
  const [inputType, setInputType] = useState('');
  const [ruleType, setRuleType] = useState('');

  // For Vendor Component
  const [vendorsList, setVendorsList] = useState([]);
  const [selectedVendors, setSelectedVendors] = useState([]);
  const [isVendorLoading, setIsVendorLoading] = useState(false);

  // Adding the Vendors data into the value field
  useEffect(() => {
    onUpdateCondition(index, { ...condition, value: selectedVendors });
  },[selectedVendors])

  // For Collection Selector 
  const [openResourceSelector, setOpenResourceSelector] = useState(false);
  const [selectedCollection, setSelectedCollection] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  // On Input Open the resource picker
  const handleSearchInput = (input) => {
    setSearchQuery(input);
    setOpenResourceSelector(true);
  };

  const handleSelection = (resources) => {
    // Create Selected Items JSON
    const selectedItems = resources.selection;

    setSelectedCollection(selectedItems);
    setOpenResourceSelector(false);
  };

  // Adding the Collection data into the value field
  useEffect(() => {
    const collectionDataToStore = selectedCollection.map(
      (selectedItem) => selectedItem.id
    );
    onUpdateCondition(index, { ...condition, value: collectionDataToStore });
  },[selectedCollection])



  const GraphQLQuery = useGraphQLQuery();

  const preselectedOptions = [
    { label: 'Is', value: 'is' },
    { label: 'Is not', value: 'is_not' },
  ]

  const numberOptions = [
    { label: 'Equal to', value: 'eq' },
    { label: 'Not equal to', value: 'neq' },
    { label: 'Greater than', value: 'gt' },
    { label: 'Greater than equal to', value: 'gte' },
    { label: 'Less than', value: 'lt' },
    { label: 'Less than equal to', value: 'lte' },
  ]

  const handleSelectChange = (value) => {
    onUpdateCondition(index, { ...condition, rule: value });
  };

  const handleValueChange = (value) => {
    let sanitizedValue = value;

    if(inputType == 'number'){
      // Remove non-numeric and non-decimal characters using a regular expression
      sanitizedValue = value.replace(/[^0-9.]/g, '');

      // Ensure there's only one decimal point
      const parts = sanitizedValue.split('.');
      if (parts.length > 2) {
        return;
      }
    }

    onUpdateCondition(index, { ...condition, value: sanitizedValue });
  };


  // Fetch and process product details
  const getVendorsList = async () => {
    try {
      const response = await GraphQLQuery({ queryWithVariable: queryForVendors });
      const data = await response.json();
      return data.shop?.productVendors?.edges || [];
    } catch (error) {
      console.error('Error fetching product details:', error);
      return [];
    }
  };

  useEffect(() => {
    const conditionType = condition.type;

    switch(conditionType) {
      case 'product':
        setRuleType("Product");
        setSelectOptions(preselectedOptions);
        setInputType('product');
        handleSelectChange(condition.rule || preselectedOptions[0].value);
        break;
      case 'product_vendor':
        setRuleType("Product Vendor");
        setSelectOptions(preselectedOptions);
        setInputType('product_vendor');
        setSelectedVendors(condition.value || []);
        handleSelectChange(condition.rule || preselectedOptions[0].value);
        break;
      case 'product_collection':
        setRuleType("Product Collection");
        setSelectOptions(preselectedOptions);
        setInputType('product_collection');
        handleSelectChange(condition.rule || preselectedOptions[0].value);
        setSelectedCollection(condition.value?.map((collectionID) => { return {id: collectionID}}) || [])
        break;
      case 'cart_total':
        setRuleType("Cart Total");
        setSelectOptions(numberOptions);
        setInputType('number');
        handleSelectChange(condition.rule || numberOptions[0].value);
        break;
      case 'cart_quantity':
        setRuleType("Cart Quantity");
        setSelectOptions(numberOptions);
        setInputType('number');
        handleSelectChange(condition.rule || numberOptions[0].value);
        break;
    }
  }, [condition.type])

  useEffect(() => {
    if(inputType == 'product_vendor') {
      setIsVendorLoading(true);
      getVendorsList().then(vendorListData => {
        const vendorListItems = vendorListData.map( vendor => {
          return vendor.node;
        })
        setVendorsList(vendorListItems);
      }).finally(() => {
        setIsVendorLoading(false);
      })
    } else {

    }
  }, [inputType])

  return (
    <IndexTable.Row position={index}>
      <IndexTable.Cell>{index == 0 ? '' : <Tag>{selectedLogic}</Tag>}</IndexTable.Cell>
      <IndexTable.Cell>
        <TextContainer> {ruleType}</TextContainer>
      </IndexTable.Cell>
      <IndexTable.Cell>
        {
          selectOptions && selectOptions.length ?
            <Select
            options={ selectOptions }
            value={condition.rule}
            onChange={handleSelectChange}
          />
          : <></>
        }
      </IndexTable.Cell>
      {/* Value Selectors */}
      {
        inputType == "number" ?
          <IndexTable.Cell>
            <TextField
              value={condition.value}
              onChange={handleValueChange}
              placeholder='Enter a number'
              type="number"
              autoComplete="off"
            />
          </IndexTable.Cell>
        : <></>
      }
      {
        inputType == "product" ?
          <IndexTable.Cell>
            Product will be render here
          </IndexTable.Cell>
        : <></>
      }
      {
        inputType == "product_collection" ?
          <IndexTable.Cell>
            <Stack vertical >
              <Stack distribution="fill">
                  <Stack.Item fill>
                    <TextField
                      onChange={handleSearchInput}
                      placeholder={
                        "Search collection"
                      }
                    />
                  </Stack.Item>
                <Stack.Item fill>
                  <Button fullWidth onClick={setOpenResourceSelector}>
                    Add
                  </Button>
                </Stack.Item>
              </Stack>
              {
                selectedCollection.length > 0 ?
                <Stack distribution="fill">
                  <Stack.Item>
                    <Button 
                      icon={CollectionsMajor}
                      fullWidth 
                      onClick={setOpenResourceSelector}
                    >
                      {selectedCollection.length} selected
                    </Button>
                  </Stack.Item>
                </Stack>
                : ""
              }
            </Stack>

            {/* Resource Picker for the getting what customer needs to buy */}
            <ResourcePicker
              // For collection we allow only 1
              selectMultiple={2}
              initialQuery={searchQuery}
              resourceType={"Collection"}
              initialSelectionIds={ selectedCollection }
              onCancel={() => {
                setOpenResourceSelector(false);
                setSearchQuery("");
              }}
              open={openResourceSelector}
              onSelection={(resources) => handleSelection(resources)}
            />
          </IndexTable.Cell>
        : <></>
      }
      {
        inputType == "product_vendor" ?
          <IndexTable.Cell>
            <div style={{ maxWidth:'350px' }}>
              <VendorPicker
                isVendorLoading={isVendorLoading}
                vendors={vendorsList}
                selectedVendors={selectedVendors}
                onSelectVendors={setSelectedVendors}
              />
            </div>
          </IndexTable.Cell>
        : <></>
      }
      <IndexTable.Cell>
        <>
          <Button
            outline
            icon={DeleteMinor}
            destructive
            onClick={() => onRemoveCondition(index)}
          />
        </>
      </IndexTable.Cell>
    </IndexTable.Row>
  );
}