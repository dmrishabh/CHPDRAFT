import Validator from "validatorjs";
import { respondError, HttpStatusCode } from "./Response.js";

/**
 * Utility method for the initiate the validation
 * 
 * @param {*} body 
 * @param {*} rules 
 * @param {*} customMessages 
 * @param {*} callback 
 */
export const validator = async (res, next, body, rules, customMessages) => {

    const validation = new Validator(body, rules, customMessages);
    validation.passes(() => next());
    validation.fails(() => {
        res.json({
            ...respondError("validation_error", HttpStatusCode.VALIDATION),
            ...validation.errors
        });
    });
};