
// HTTP Status Code
export const HttpStatusCode = {
    OK: 200,
    BAD_REQUEST: 400,
    NOT_FOUND: 404,
    INTERNAL_SERVER: 500,
    VALIDATION: 422,
    AUTHORIZATION: 401,
    FORBIDDEN: 403
};

/**
 * Helper method to return the response
 * 
 * Author: Birendra Kr
 */

// Define the default error message
const errorMsg = {
    // Internal server error
    '500' : "There seems to be some problem with our servers. You can retry after a few seconds or reach out to admin for assistance.",
    // unauthorized
    "401": "Your credentials are not sufficient to authorized you. Please retry with the right credentials.",
    // forbidden
    "403": "You are not authorized to access it."
}

/**
 * Default response format
 * 
 * @param status 
 * @param msg 
 * @param code 
 * @returns {json} 
 */
const respond = (status = true, msg, code) => {

    return {
        "success": status,
        "message": msg,
        "code": code
    }
}

/**
 * return success response
 * @param msg 
 * @returns {json}
 */
 export const respondSuccess = (msg) => {

    return respond(true, msg, HttpStatusCode.OK);
}

/**
 * return success response with data
 * 
 * @param msg 
 * @param code 
 * @param data 
 * @returns {json}
 */
export const respondWithData = (msg = "", data, code = HttpStatusCode.OK) => {

    return {
        ...respond(true, msg, code),
        "data": data,
    }
}

/**
 * Return error response
 * 
 * @param msg 
 * @param code 
 * @returns {json}
 */
export const respondError = (msg, code) => {

    return respond(false, msg, code);
}

/**
 * return Unauthorized response
 * 
 * @returns 
 */
export const respondUnauthorized = (msg = errorMsg[HttpStatusCode.AUTHORIZATION]) => {

    return respond(false, msg, HttpStatusCode.AUTHORIZATION);
}

/**
 * Respond forbidden
 * 
 * @returns 
 */
export const respondForbidden = () => {

    return respond(false, errorMsg[HttpStatusCode.FORBIDDEN], HttpStatusCode.FORBIDDEN);
}

/**
 * respond not found
 * 
 * @param msg 
 * @returns 
 */
export const respondNotFound = (msg  = "Route Not Found") => {

    return respond(false, msg, HttpStatusCode.NOT_FOUND);
}

/**
 * respond internal server error
 * 
 * @returns 
 */
export const respondInternalServerError = () => {

    return respond(false, errorMsg[HttpStatusCode.INTERNAL_SERVER], HttpStatusCode.INTERNAL_SERVER);
}