import log4js from 'log4js';
// Configure Log4js with Pattern Layout
log4js.configure({
    appenders: {
        everything: { type: 'dateFile', filename: 'logs/app.log' },
        console: { type: 'console', layout: { type: 'pattern', pattern: '%[%d{ISO8601_WITH_TZ_OFFSET} %p %c -%] %m' } },
    },
    categories: {
        default: { appenders: ['console', 'everything'], level: 'debug' }
    }
});
// Get the logger
const logger = log4js.getLogger();

export default logger;