import {
  useApi,
  useTranslate,
  reactExtension,
  useApplyCartLinesChange,
  useCartLines,
  useDiscountCodes,
  Tag,
  InlineStack,
  TextBlock,
  useAttributes,
  useApplyAttributeChange,
} from '@shopify/ui-extensions-react/checkout';
import { useEffect, useState } from 'react';

export default reactExtension(
  'purchase.checkout.reductions.render-after',
  () => <Extension />,
);

 // Update Base URL accordingly 
 const baseUrl = "https://pro.checkoutextension.com";
 const queryURL = `${baseUrl}/api/freebieProduct/query`; 
  
 
 function Extension() {
  const { sessionToken, extension } = useApi();
  const isCustomizerOpen = !!(extension && extension.editor);
  const checkoutAttributes = useAttributes();
  const updateAttribute = useApplyAttributeChange();
  const [isEligible, setIsEligible] = useState(false);
  const appliedCouponCode = useDiscountCodes();
  const appliedCoupon = appliedCouponCode.map((item) => item.code);
  const cartLineChange = useApplyCartLinesChange();
  const lines = useCartLines();
  const translate = useTranslate();

  const [eligibleCoupons,setEligibleCoupons] = useState([]);
  const [appliedAutomaticDiscounts,setAppliedAutomaticDiscounts] = useState([]);
  const [isEffectCompleted, setIsEffectCompleted] = useState(true);

  /**
   * Call API
   *
   * @param {*} url
   * @param {*} token
   * @returns
   */
  const fetchWithToken = async (url, token, method = "GET", data = null) => {
    try {
      const config = {
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      if (data) {
        config["body"] = JSON.stringify(data);
      }

      const result = await fetch(url, config);
      return result.json();
    } catch (error) {
      console.log("Error", error.message);
      return {
        success: false,
      };
    }
  };

  /**
   * Handle Page Viewed
   *
   */
  const handlePageViewed = async () => {
    const token = Date.now().toString() + Math.random().toString(36).substring(2, 7);
    const url = `${baseUrl}/api/checkoutextension/viewed`;
    const sToken = await sessionToken.get();
    let response;

    // Not to count View if the merchant have opened checkout customizer
    if(!isCustomizerOpen) {
      response = await fetchWithToken(url, sToken, "POST", { token: token });
    }

    // Add attribute only if viewed by customer and billing or trial is active
    await updateAttribute({
      key: "isFreebieDiscountApplied",
      value: ((response && response.success) || isCustomizerOpen) ? token : 'ACTION_REQUIRED_ON_APP', 
      type: "updateAttribute",
    }).then(() => {
        // Can be used for logging data
        // console.log({msg: "Attributes Updated: isPrepaidDiscountApplied", isTest: isCustomizerOpen });
      }
    );
 
    return (!!(response && response.success) || !!isCustomizerOpen);
  };

  useEffect( async () => {
    const isFreebieDiscountApplied = checkoutAttributes.find(
      (attr) => attr.key == "isFreebieDiscountApplied"
    );

    if (isFreebieDiscountApplied == undefined) {
      functionalityAppliedCounted = await handlePageViewed();
      setIsEligible(functionalityAppliedCounted)
    } else if ( isFreebieDiscountApplied.value !== 'ACTION_REQUIRED_ON_APP' ) {
      setIsEligible(true);
    } else {
      setIsEligible(false);
    }
  },[eligibleCoupons])

  // Getting all the coupon created on Shopify
  const getCouponData = async () => {
    const url = `${baseUrl}/api/freebieProduct/getAllFreebieCoupons`;
    const token = await sessionToken.get();
    const response = await fetchWithToken(url, token, "GET");
    return response;
  };

  useEffect(async() => {
    // Fetch session token and coupon data
    const token = await sessionToken.get();
    const couponData = await getCouponData();

    // If no coupon data, exit early
    if (!couponData.length) return;

    // GraphQL query to check active coupons
    const CHECK_ACTIVE_COUPONS = `
      query FetchActiveCouponsByIds($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on DiscountAutomaticNode {
            automaticDiscount {
              ... on DiscountAutomaticApp {
                title
                status
              }
            }
          }
        }
      }`;

    // Get coupon IDs and prepare query for active coupons
    const couponIds = couponData.map(coupon => coupon.discountId);
    const queryForActiveCoupons = {
      query: CHECK_ACTIVE_COUPONS,
      variables: { ids: couponIds },
    };

    // Fetch active coupons
    const getActiveCoupons = await fetchWithToken(queryURL, token, "POST", { queryWithVariable: queryForActiveCoupons });

    // Filter active coupons based on status
    const activeCoupons = couponData.filter((coupon, index) => {
      if (!getActiveCoupons?.nodes) return false;
      const activeCoupon = getActiveCoupons.nodes[index];
      return activeCoupon?.automaticDiscount?.status === "ACTIVE";
    });

    // If no active coupons, exit early
    if (!activeCoupons.length) return;

    // Prepare sets for products, variants, and collections
    const productSet = new Set();
    const variantSet = new Set();
    const collectionSet = new Set();

    // Iterate through lines to populate sets
    lines.forEach(item => {
      if (item.merchandise.type === "variant") {
        variantSet.add(item.merchandise.id);
        productSet.add(item.merchandise.product.id);
      }
    });

    // Populate collection set from active coupons
    activeCoupons.forEach(coupon => {
      coupon.selectedCollections.forEach(collection => collectionSet.add(collection));
    });

    // Prepare query to check product collections
    const PRODUCT_IN_COLLECTIONS_QUERY = Array.from(collectionSet).map((collectionID, index) =>
      `collection${index}: inCollection(id: "${collectionID}")`).join('\n');

    // GraphQL query to check products in collections
    const CHECK_PRODUCT_IN_COLLECTIONS = `
      query FetchProductsByIds($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on Product {
            id
            ${PRODUCT_IN_COLLECTIONS_QUERY}
          }
        }
      }`;

    // Prepare query for product collections and fetch data
    const queryForProductCollections = {
      query: CHECK_PRODUCT_IN_COLLECTIONS,
      variables: { ids: Array.from(productSet) },
    };

    const queryResponseForProductCollections = await fetchWithToken(queryURL, token, "POST", { queryWithVariable: queryForProductCollections });

    // Log relevant data for debugging purposes
    // console.log({
    //   lines,
    //   couponData,
    //   getActiveCoupons,
    //   activeCoupons,
    //   queryResponseForProductCollections,
    //   productSet,
    //   variantSet,
    //   collectionSet,
    //   CHECK_PRODUCT_IN_COLLECTIONS,
    // });


    // Filter active coupons based on qualifying criteria
    const qualifiedCoupons = activeCoupons.filter(coupon => {
    // Check if coupon applies to collections and is automatic
      const qualifyingCriteria = coupon.appliesTo.includes('Collection') && coupon.discountType.includes('automatic')
        ? {
          qualifyingItems: lines.filter(line => line.merchandise.type === "variant")
            .filter(line => queryResponseForProductCollections.nodes.some(product => product.id === line.merchandise.product.id)),
          purchaseAmount: coupon.purchaseAmount,
          purchaseQuantity: coupon.purchaseQuantity
        }
        // Check if coupon applies to products and is automatic
        : coupon.appliesTo.includes('Product') && coupon.discountType.includes('automatic')
        ? {
          qualifyingItems: lines.filter(line => line.merchandise.type === "variant")
            .filter(line => coupon.selectedProducts.some(product => product.id === line.merchandise.product.id)),
          purchaseAmount: coupon.purchaseAmount,
          purchaseQuantity: coupon.purchaseQuantity
        }
        : null;

      if (qualifyingCriteria) {
        const qualifiedItemsPrice = qualifyingCriteria.qualifyingItems.reduce((total, line) =>
          total + parseFloat(line.cost.totalAmount.amount), 0);
        const qualifiedItemsQuantity = qualifyingCriteria.qualifyingItems.reduce((total, line) =>
          total + parseInt(line.quantity), 0);

        return qualifiedItemsPrice >= qualifyingCriteria.purchaseAmount &&
          qualifiedItemsQuantity >= qualifyingCriteria.purchaseQuantity;
      }

      return false;
    });

    if(isEffectCompleted){
      // Update eligible state
      setEligibleCoupons(qualifiedCoupons);
    }
  }, [lines,isEffectCompleted]);



  useEffect(async () => {
    if (!isEligible) return;

    setIsEffectCompleted(false);

    for (const coupon of eligibleCoupons) {
      let couponAlreadyApplied = false;

      for (const line of lines) {
        for (const attribute of line.attributes) {
          if (attribute.key === '_freebieCouponApplied' && attribute.value === coupon.discountId) {
            couponAlreadyApplied = true;
            break; // No need to continue checking attributes for this coupon
          }
        }

        if (couponAlreadyApplied) {
          break; // No need to continue checking lines for this coupon
        }
      }

      if (!couponAlreadyApplied) {
        for (const product of coupon.selectedGetProducts) {
          for (const variant of product.variants) {
            await cartLineChange({
              type: "addCartLine",
              merchandiseId: variant.id,
              quantity: 1,
              attributes: [{ key: '_freebieCouponApplied', value: `${coupon.discountId}` }]
            })
          }
        }
      }
      setIsEffectCompleted(true);
    }
  }, [eligibleCoupons,isEligible]);

  // Check If coupons are applied
  useEffect(() => {
    let appliedCouponItems = new Set();
    for (const line of lines) {
      for (const discountAllocation of line.discountAllocations){
        for (const eligibleCoupon of eligibleCoupons ) {
          if(discountAllocation.title === eligibleCoupon.discountTitle ) {
            appliedCouponItems.add(eligibleCoupon);
          }
        }
      }
    }
    setAppliedAutomaticDiscounts(Array.from(appliedCouponItems));
  },[eligibleCoupons,lines])

  return (
    <>
      <InlineStack spacing="base">
        { isCustomizerOpen ?
          <>
            <TextBlock appearance="critical">
              Below is how discount will be showed to your customers.
              This block is required for proper functioning of freebie discount functionality.
            </TextBlock>
            <Tag key="checkoutExtension" icon="discount">Applied Discount</Tag>
          </>
          :''
        }
        {appliedAutomaticDiscounts ? 
            appliedAutomaticDiscounts.map((item, index) => (
              <Tag key={index} icon="discount">{ item.discountTitle.toString().toUpperCase()}</Tag>
            ))
          :''
        }
      </InlineStack>
    </>
  );
}