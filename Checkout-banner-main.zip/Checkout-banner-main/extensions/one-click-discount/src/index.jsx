import React, { useEffect, useState } from "react";
import {
  render,
  ScrollView,
  View,
  Button,
  Image,
  InlineSpacer,
  InlineLayout,
  Text,
  useExtensionApi,
  useCartLines,
  useDiscountAllocations,
  useShippingAddress,
  Heading,
  BlockLayout,
  useApplyDiscountCodeChange,
  useDiscountCodes,
  useApplyAttributeChange,
  useAttributes,
  Style,
  Banner,
  useSettings,
  SkeletonTextBlock,
} from "@shopify/checkout-ui-extensions-react";
render("Checkout::Reductions::RenderAfter", () => <App />);

function App() {
  // Update Base URL accordingly
  const baseUrl = "https://pro.checkoutextension.com";

  const { scroll_hint } = useSettings();
  const applyDiscountCodeChange = useApplyDiscountCodeChange();
  const appliedCouponCode = useDiscountCodes();
  const discountAllocations = useDiscountAllocations();
  const cartItems = useCartLines();
  // const shippingAddress = useShippingAddress();

  const [isLoading, setIsLoading] = useState({});
  const [errorBanner, setErrorBanner] = useState(false);
  const [errorBannerMessage, setErrorBannerMessage] = useState("");
  const appliedCoupon = appliedCouponCode.map((item) => item.code);

  // Store coupon data
  const [discountData, setDiscountData] = useState([]);

  //Method to check page View
  const checkoutAttributes = useAttributes();
  let updateAttribute = useApplyAttributeChange();
  const { sessionToken, extension } = useExtensionApi();
  const isCustomizerOpen = !!(extension && extension.editor);

  /**
   * Call API
   *
   * @param {*} url
   * @param {*} token
   * @returns
   */
  const fetchWithToken = async (url, token, method = "GET", data = null) => {
    try {
      const config = {
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      if (data) {
        config["body"] = JSON.stringify(data);
      }

      const result = await fetch(url, config);
      return result.json();
    } catch (error) {
      console.log("Error", error.message);
      return {
        success: false,
      };
    }
  };

  /**
   * Handle Page Viewed
   *
   */
  const handlePageViewed = async () => {
    const token = Date.now().toString() + Math.random().toString(36).substring(2, 7);
    const url = `${baseUrl}/api/checkoutextension/viewed`;
    const sToken = await sessionToken.get();
    let response;

    // Not to count View if the merchant have opened checkout customizer
    if(!isCustomizerOpen) {
      response = await fetchWithToken(url, sToken, "POST", { token: token });
    }

    // Add attribute only if viewed by customer and billing or trial is active
    await updateAttribute({
      key: "isOneClickDiscountViewed",
      value: ((response && response.success) || isCustomizerOpen) ? token : 'ACTION_REQUIRED_ON_APP',
      type: "updateAttribute",
    }).then(() => {
        // Can be used for logging data 
        // console.log({msg: "Attributes Updated: isOneClickDiscountViewed", isTest: isCustomizerOpen });
      }
    );
    return ((response && response.success) || isCustomizerOpen);
  };

  const getCouponData = async () => {
    const url = `${baseUrl}/api/coupon/fetch`;
    const token = await sessionToken.get();
    const response = await fetchWithToken(url, token, "POST");
    if (response.success) {
      setDiscountData(response.data);
    }
  };

  useEffect(async() => {
    // TODO: checkoutAttributes.length can be use to identify faster if its required to count the view
    // If the length is zero that mean there is no key to check

    let isEligible = false;

    const isOneClickDiscountViewed = checkoutAttributes.find(
      (attr) => attr.key == "isOneClickDiscountViewed"
    );

    // If the value of the attribute has been set earlier mean that either the view has happened before the plan expired
    if (isOneClickDiscountViewed == undefined) {
      isEligible = await handlePageViewed();
    } else if ( isOneClickDiscountViewed.value !== 'ACTION_REQUIRED_ON_APP' ) {
      isEligible = true;
    }
    
    if ( isEligible && discountData.length == 0) {
      getCouponData();
    }
  }, []);

  async function addDiscountCoupon(couponCode) {
    setIsLoading({ [couponCode]: true });
    const result = await applyDiscountCodeChange({
      code: couponCode,
      type: "addDiscountCode",
    });

    setIsLoading({ [couponCode]: false });
    if (!(result.type === "success")) {
      setErrorBanner(true);
      setErrorBannerMessage(result.message);
    } else if (result.type === "success") {
      setErrorBanner(false);
    }
  }

  async function removeDiscountCoupon(couponCode) {
    setIsLoading({ [couponCode]: true });

    const result = await applyDiscountCodeChange({
      code: couponCode,
      type: "removeDiscountCode",
    });

    setIsLoading({ [couponCode]: false });
  }

  let inactiveCoupon = false;

  let subTotal = 0;
  let quantity = 0;

  // Adding all the item line price into the subtotal for calculation
  // Additionally Getting the quantity of items in the cart
  cartItems.forEach((item) => {
    if (item.cost.totalAmount) {
      subTotal += item.cost.totalAmount.amount;
    }
    quantity += item.quantity;
  });

  // Adding all the coupon discount into the subtotal for calculation
  discountAllocations.forEach((allocations) => {
    if (allocations.discountedAmount) {
      subTotal += allocations.discountedAmount.amount;
    }
  });

  // Coupon Active/Inactive logics
  inactiveCoupon = false;
  filteredDiscountData = discountData.map((data) => {
    let coupon_rule = data.coupon_rule;

    // Module to check if the minimum requirement is satisfied
    // A reverse logic has been added to help with the null value provided by minimum requirement
    // Starting with true value we want to make the value false if the condition are not satisfied
    let minimumRequirement = true;
    let shippingDestinationSelectionMatch = true; // Update this value to false after getting approval from shopify for the shipping data

    if (
      coupon_rule.minimumRequirement &&
      (quantity <
        coupon_rule.minimumRequirement?.greaterThanOrEqualToQuantity ||
        subTotal <
          coupon_rule.minimumRequirement?.greaterThanOrEqualToSubtotal?.amount)
    ) {
      minimumRequirement = false;
    }

    // Handling Shipping coupons destination
    // if (
    //   coupon_rule?.discountType == "SHIPPING" &&
    //   shippingAddress &&
    //   shippingAddress.countryCode
    // ) {
    //   if (
    //     coupon_rule.destinationSelection?.allCountries ||
    //     (coupon_rule.destinationSelection?.countries &&
    //       coupon_rule.destinationSelection?.countries.includes(
    //         shippingAddress.countryCode
    //       ))
    //   ) {
    //     shippingDestinationSelectionMatch = true;
    //   } else {
    //     shippingDestinationSelectionMatch = false;
    //   }
    // }

    if (
      minimumRequirement &&
      (shippingDestinationSelectionMatch ||
        coupon_rule.discountType == "ORDER" ||
        coupon_rule.discountType == "PRODUCT")
    ) {
      return { ...data, available: true };
    } else {
      // Need to optimize the code logic
      inactiveCoupon = true;
      return { ...data, available: false };
    }
  });

  // Handling Active coupon data template
  const active_coupon_cards = filteredDiscountData.map((data) =>
    data.available ? (
      <View key={data.code}>
        <View border="base" padding="base" cornerRadius="base">
          <InlineLayout columns={["fill", "20%"]}>
            <InlineLayout columns={["20%", "fill"]} blockAlignment="center">
              <View
                blockAlignment="center"
                padding={["none", "base", "none", "none"]}
              >
                <Image source="https://cdn.shopify.com/s/files/1/0759/0880/8990/files/coupn.png?v=1685016457" />
              </View>
              <BlockLayout>
                <Heading>{data.title.toUpperCase()}</Heading>
                <Text size="small">{data.subtitle}</Text>
              </BlockLayout>
            </InlineLayout>

            <Button
              appearance="interactive"
              loading={isLoading[data.code] ? true : false}
              onPress={
                appliedCoupon.includes(data.code)
                  ? () => {
                    removeDiscountCoupon(data.code);
                  }
                  : () => {
                    addDiscountCoupon(data.code);
                  }
              }
            >
              {appliedCoupon.includes(data.code) ? "Remove" : "Apply"}
            </Button>
          </InlineLayout>
        </View>
        <InlineSpacer spacing="loose" />
      </View>
    ) : (
      ""
    )
  );

  // Handling inactive coupon data template
  const inactive_coupon_cards = filteredDiscountData.map((data) =>
    !data.available ? (
      <View key={data.code}>
        <View border="base" padding="base" cornerRadius="base">
          <InlineLayout columns={["fill", "20%"]}>
            <InlineLayout columns={["20%", "fill"]} blockAlignment="center">
              <View
                blockAlignment="center"
                padding={["none", "base", "none", "none"]}
              >
                <Image source="https://cdn.shopify.com/s/files/1/0759/0880/8990/files/coupn.png?v=1685016457" />
              </View>
              <BlockLayout>
                <Heading>{data.title.toUpperCase()}</Heading>
                <Text size="small">{data.subtitle}</Text>
              </BlockLayout>
            </InlineLayout>

            <Button
              id={data.code}
              disabled={true}
              onPress={() => { }}
            >
              Apply
            </Button>
          </InlineLayout>
        </View>
        <InlineSpacer spacing="loose" />
      </View>
    ) : (
      ""
    )
  );

  return (
    <>
      {/* Displaying Error on coupon applied  */}
      {errorBanner ? (
        <View padding={["base", "none"]}>
          <Banner status="critical" title="">
            {errorBannerMessage}
          </Banner>
        </View>
      ) : (
        ""
      )}
      {/* Display Coupon List  */}
      { filteredDiscountData.length ? (
        <ScrollView
          hint={
            scroll_hint === "Pill"
              ? { type: "pill", content: "Scroll for more offers" }
              : scroll_hint === "Inner shadow"
              ? "innerShadow"
              : { type: "pill", content: "Scroll for more offers" }
          }
          maxBlockSize={200}
          padding="base"
          border="none"
        >
          {active_coupon_cards}
          {inactiveCoupon ? (
            <View>
              <View>
                <Heading> No Applicable</Heading>
              </View>
              <InlineSpacer spacing="loose" />
              {inactive_coupon_cards}{" "}
            </View>
          ) : (
            ""
          )}
        </ScrollView>
      ) : (
        ""
      )}
    </>
  );
}
