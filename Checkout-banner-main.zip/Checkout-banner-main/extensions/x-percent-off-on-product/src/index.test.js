import { describe, it, expect } from 'vitest';
import productDiscounts from './index';

/**
 * @typedef {import("../generated/api").FunctionResult} FunctionResult
 */

describe('product discounts function', () => {
  it('returns no discounts without configuration', () => {
    const result = productDiscounts({
      "cart": {
        "attribute": {
          "key": "discountedPaymentGateway",
          "value": "false"
        },
        "lines": [
          {
            "quantity": 1,
            "merchandise": {
              "__typename": "ProductVariant",
              "id": "gid://shopify/ProductVariant/45088720093470"
            }
          }
        ]
      },
      "discountNode": {
        "metafield": {
          "value": "{\"uptoAmount\":50,\"percentage\":5}"
        }
      }
    });
    const expected = /** @type {FunctionResult} */ ({
      discounts: [],
      discountApplicationStrategy: "FIRST",
    });

    expect(result).toEqual(expected);
  });
});

describe('product discounts function 2', () => {
  it('returns no discounts without configuration', () => {
    const result = productDiscounts({
        "cart": {
          "attribute": {
            "key": "discountedPaymentGateway",
            "value": "true"
          },
          "lines": [
            {
              "quantity": 1,
              "merchandise": {
                "__typename": "ProductVariant",
                "id": "gid://shopify/ProductVariant/45088720093470"
              },
              "id": "gid://shopify/CartLine/0"
            }
          ],
          "cost": {
            "subtotalAmount": {
              "amount": "699.95",
              "currencyCode": "INR"
            }
          }
        },
        "discountNode": {
          "metafield": {
            "value": "{\"uptoAmount\":50,\"percentage\":5}"
          }
        }

    });
    const expected = /** @type {FunctionResult} */ ({
      discounts: [{
        "targets": [{
          "productVariant": {
            "id": "gid://shopify/ProductVariant/45088720093470",
            "quantity": 1,
          }
        }],
        "value": {
          "fixedAmount": {
            "amount": 34.9975
          }
        },
        "message": `5% discount applied`,
      }],
      discountApplicationStrategy: "FIRST",
    });

    expect(result).toEqual(expected);
  });
});