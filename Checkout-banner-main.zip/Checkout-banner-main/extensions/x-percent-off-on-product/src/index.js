// @ts-check
import { DiscountApplicationStrategy } from "../generated/api";

// Use JSDoc annotations for type safety
/**
* @typedef {import("../generated/api").InputQuery} InputQuery
* @typedef {import("../generated/api").FunctionResult} FunctionResult
* @typedef {import("../generated/api").Target} Target
* @typedef {import("../generated/api").ProductVariant} ProductVariant
*/

/**
* @type {FunctionResult}
*/
const EMPTY_DISCOUNT = {
  discountApplicationStrategy: DiscountApplicationStrategy.First,
  discounts: [],
};

// The @shopify/shopify_function package will use the default export as your function entrypoint
export default /**
* @param {InputQuery} input
* @returns {FunctionResult}
*/
  (input) => {

    const configuration = JSON.parse(
      input?.discountNode?.metafield?.value ?? "{}"
    );
    if (!configuration.percentage) {
      return EMPTY_DISCOUNT;
    }

    const targets = input.cart.lines
      // Only include cart lines with a quantity of two or more
      // and a targetable product variant
      .filter(line => {
        return (input.cart.attribute?.key == 'discountedPaymentGateway'
        && input.cart.attribute?.value == 'true'
        && line.merchandise.__typename == "ProductVariant");
      })
      .map(line => {
        const variant = /** @type {ProductVariant} */ (line.merchandise);
        return /** @type {Target} */ ({
          // Use the variant ID to create a discount target
          productVariant: {
            id: variant.id,
            quantity: line.quantity
          }
        });
      });

    if (!targets.length) {
      // You can use STDERR for debug logs in your function
      console.error("No cart lines qualify for discount.");
      return EMPTY_DISCOUNT;
    }

    // The @shopify/shopify_function package applies JSON.stringify() to your function result
    // and writes it to STDOUT
    const discountPercentage = configuration.percentage;
    const maxDiscount = configuration.uptoAmount || 0;
    const cartSubtotal = input.cart.cost.subtotalAmount.amount || 0;
    let percentageDiscountAmount = (discountPercentage * cartSubtotal)/100;

    if(maxDiscount && percentageDiscountAmount>= maxDiscount){
      percentageDiscountAmount = maxDiscount;
    }

    return {
      discounts: [
        {
          // Apply the discount to the collected targets
          targets,
          value: {
            fixedAmount: {
              amount: percentageDiscountAmount
            }
          },
          message: `${discountPercentage}% prepaid discount`,
        }
      ],
      discountApplicationStrategy: DiscountApplicationStrategy.First
    };
  };
