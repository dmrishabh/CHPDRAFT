import React, { useEffect, useState } from "react";
import {
  render,
  ListItem,
  List,
  Banner,
  useSettings,
  useCartLines,
  useDiscountCodes,
  useApplyDiscountCodeChange,
  useAttributes,
  useApplyAttributeChange,
  useExtensionApi,
} from "@shopify/checkout-ui-extensions-react";

render("Checkout::Reductions::RenderBefore", () => <App />);
// render("Checkout::Reductions::RenderBefore", () => <extension />);

function App() {
  // Update Base URL accordingly
  const baseUrl = "https://pro.checkoutextension.com";
  const checkoutAttributes = useAttributes();
  let updateAttribute = useApplyAttributeChange();
  const { sessionToken, extension } = useExtensionApi();
  const isCustomizerOpen = !!(extension && extension.editor);
  const [isEligible, setIsEligible] = useState(false);
  const [errorProductTitle, setErrorProductTitle] = useState([]);
  const [noDiscount, setNoDiscount] = useState(false);
  const [showError, setShowError] = useState(false);
  const { tag, coupon, error_message } = useSettings();
  const cartItems = useCartLines();
  const discountCodes = useDiscountCodes(); // gives an array of applied discount codes
  const { query } = useExtensionApi(); // Used to fetch gQl query
  const applyDiscountCodeChange = useApplyDiscountCodeChange([]); // Can be used to add or remove discount codes

  /*
  Uncomment to test on dev server , and comment useSetting data
  const tag = "no-discount";const error_message = "";const coupon = "Free10,Free20";
  */

  let trimmedArray = [];
  if (coupon) {
    const couponArr = coupon?.trim().toUpperCase().split(","); // creating an array from `coupon` string user input
    trimmedArray = couponArr?.map((element) => element.trim());
  }

  // Code for billing integration

  /**
   * Call API
   *
   * @param {*} url
   * @param {*} token
   * @returns
   */
  const fetchWithToken = async (url, token, method = "GET", data = null) => {
    try {
      const config = {
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      if (data) {
        config["body"] = JSON.stringify(data);
      }

      const result = await fetch(url, config);
      return result.json();
    } catch (error) {
      console.log("Error", error.message);
      return {
        success: false,
      };
    }
  };

  /**
   * Handle Page Viewed
   *
   */
  const handlePageViewed = async () => {
    const token =
      Date.now().toString() + Math.random().toString(36).substring(2, 7);
    const url = `${baseUrl}/api/checkoutextension/viewed`;
    const sToken = await sessionToken.get();
    let response;

    // Not to count View if the merchant have opened checkout customizer
    if (!isCustomizerOpen) {
      response = await fetchWithToken(url, sToken, "POST", { token: token });
    }

    // Add attribute only if viewed by customer and billing or trial is active
    await updateAttribute({
      key: "isDiscountBlockerViewed",
      value:
        (response && response.success) || isCustomizerOpen
          ? token
          : "ACTION_REQUIRED_ON_APP",
      type: "updateAttribute",
    }).then(() => {
      /* Can be used for logging data
      console.log({
        msg: "Attributes Updated: isDiscountBlockerViewed",
         isTest: isCustomizerOpen,
       });*/
      setIsEligible((response && response.success) || isCustomizerOpen);
    });
  };

  useEffect(async () => {
    const isDiscountBlockerViewed = checkoutAttributes.find(
      (attr) => attr.key == "isDiscountBlockerViewed"
    );
    if (isDiscountBlockerViewed == undefined) {
      await handlePageViewed();
    } else if (isDiscountBlockerViewed.value !== "ACTION_REQUIRED_ON_APP") {
      setIsEligible(true);
    }
  }, []);

  // Looping through applied discounts , if product have tag for discount blocking and any applied coupon is not matching to any coupon of `couponArr` then removing that discount

  discountCodes.map((discountCode) => {
    if (isEligible) {
      if (showError) {
        setShowError(false);
      }
      if (noDiscount && !trimmedArray.includes(discountCode?.code)) {
        removeDiscountCoupon(discountCode?.code);
      } else if (noDiscount && !coupon) {
        removeDiscountCoupon(discountCode?.code);
      }
    }
  });

  /**
   * @param: productId - Taken from cartLineItems
   * Queries product tags by product id from GQL AdminAPI
   */

  const queryMethod = async (productId) => {
    await query(
      `query ($id: ID!) {
          product(id: $id) {
            title
            tags
          }
        }`,
      {
        variables: {
          id: `${productId}`,
        },
      }
    )
      .then(({ data, errors }) => {
        if (data?.product?.tags?.includes(tag)) {
          setErrorProductTitle((prev) => [...prev, data?.product?.title]);
          setNoDiscount(true);
        }
      })
      .catch(console.error);
  };

  useEffect(() => {
    cartItems.map((item) => {
      queryMethod(item.merchandise.product.id);
    });
  }, []);
  /**
   * @param: couponCode - any valid discount coupon code
   * removes given coupon discount asynchronously
   */
  async function removeDiscountCoupon(couponCode) {
    const result = await applyDiscountCodeChange({
      code: couponCode,
      type: "removeDiscountCode",
    });
    setShowError(true);
  }
  // Banner will appear only if user is not able to apply the coupon
  return (
    <>
      {isEligible && showError ? (
        <Banner
          status="warning"
          collapsible="true"
          title={
            error_message
              ? error_message
              : "Remove these products to get discount"
          }
        >
          <List>
            {errorProductTitle.map((errorProductTitle, index) => (
              <ListItem key={index}>{errorProductTitle}</ListItem>
            ))}
          </List>
        </Banner>
      ) : (
        <></>
      )}
    </>
  );
}
