// @ts-check

/**
 * @typedef {import("../generated/api").InputQuery} InputQuery
 * @typedef {import("../generated/api").FunctionResult} FunctionResult
 */

/**
 * @type {FunctionResult}
 */
const NO_CHANGES = {
  operations: [],
};

export default /**
 * @param {InputQuery} input
 * @returns {FunctionResult}
 */
(input) => {
  const configuration = JSON.parse(
    input?.paymentCustomization?.metafield?.value ?? "{}"
  );

  // Use the configured payment method name instead of a hardcoded value
  const activePaymentMethods = input.paymentMethods;


  // Filtering the data
  const paymentGatewayRearrangement = configuration.paymentGatewayOrder.filter((paymentGateway) => {
    const lowerCaseNamePaymentGatewayName = paymentGateway.content.toLowerCase();

    const isCurrentPaymentGatewayActive = activePaymentMethods.find(method => {
      const methodNameLowerCase = method.name.toLowerCase();
      return methodNameLowerCase.includes(lowerCaseNamePaymentGatewayName)
    });

    return !!isCurrentPaymentGatewayActive;
  }).map((paymentGateway) => {
    const lowerCaseNamePaymentGatewayName = paymentGateway.content.toLowerCase();

    const isCurrentPaymentGatewayActive = activePaymentMethods.find(method => {
      const methodNameLowerCase = method.name.toLowerCase();
      return methodNameLowerCase.includes(lowerCaseNamePaymentGatewayName)
    });
    return { ...paymentGateway, paymentMethodId: isCurrentPaymentGatewayActive?.id }
  });

  // Adding all the Unlisted payment Gateway
  for(let index = 0; index < activePaymentMethods.length; index++){

    const activePaymentMethodsID = activePaymentMethods[index].id;

    const isCurrentPaymentGatewayAddedInOrder = paymentGatewayRearrangement.find(gateway => {
      return activePaymentMethodsID == gateway.paymentMethodId;
    });
    
    if(!isCurrentPaymentGatewayAddedInOrder){
      paymentGatewayRearrangement.push({
        index: paymentGatewayRearrangement.length,
        paymentMethodId: activePaymentMethods[index].id
      })
    }
  }

  let operations = [];

  if(!paymentGatewayRearrangement.length) {
    return NO_CHANGES;
  } else {
    for(let index=0; index<paymentGatewayRearrangement.length; index++){
      operations.push({
        move: {
          index:index,
          paymentMethodId: paymentGatewayRearrangement[index].paymentMethodId,
        }
      })
    }
  }

  return {operations: operations}
};