import React, { useEffect, useState } from "react";
import {
  render,
  Image,
  useSettings,
  Link,
  Style,
  useAttributes,
  useApplyAttributeChange,
  useExtensionApi,
} from "@shopify/checkout-ui-extensions-react";
render("Checkout::Dynamic::Render", () => <App />);

function App() {
  // Update Base URL accordingly
  const baseUrl = "https://pro.checkoutextension.com";

  const { link, deskSource, mobileSource, accessibilityDescription } =
    useSettings();
  const checkoutAttributes = useAttributes();
  let updateAttribute = useApplyAttributeChange();
  const { sessionToken, extension } = useExtensionApi();
  const isCustomizerOpen = !!(extension && extension.editor);
  const [isEligible, setIsEligible] = useState(false);

  /**
   * Call API
   *
   * @param {*} url
   * @param {*} token
   * @returns
   */
  const fetchWithToken = async (url, token, method = "GET", data = null) => {
    try {
      const config = {
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      if (data) {
        config["body"] = JSON.stringify(data);
      }

      const result = await fetch(url, config);
      return result.json();
    } catch (error) {
      console.log("Error", error.message);
      return {
        success: false,
      };
    }
  };

  /**
   * Handle Page Viewed
   *
   */
  const handlePageViewed = async () => {
    const token =
      Date.now().toString() + Math.random().toString(36).substring(2, 7);
    const url = `${baseUrl}/api/checkoutextension/viewed`;
    const sToken = await sessionToken.get();
    let response;

    // Not to count View if the merchant have opened checkout customizer
    if (!isCustomizerOpen) {
      response = await fetchWithToken(url, sToken, "POST", { token: token });
    }

    // Add attribute only if viewed by customer and billing or trial is active
    await updateAttribute({
      key: "isBannerViewed",
      value:
        (response && response.success) || isCustomizerOpen
          ? token
          : "ACTION_REQUIRED_ON_APP",
      type: "updateAttribute",
    }).then(() => {
      // Can be used for logging data
      // console.log({msg: "Attributes Updated: isBannerViewed", isTest: isCustomizerOpen });
      setIsEligible((response && response.success) || isCustomizerOpen);
    });
  };

  useEffect(async () => {
    const isBannerViewed = checkoutAttributes.find(
      (attr) => attr.key == "isBannerViewed"
    );

    if (isBannerViewed == undefined) {
      await handlePageViewed();
    } else if (isBannerViewed.value !== "ACTION_REQUIRED_ON_APP") {
      setIsEligible(true);
    }
  }, []);

  return (
    <>
      {isEligible ? (
        <>
          {link ? (
            <Link to={link}>
              <Image
                source={Style.default(
                  mobileSource ? mobileSource : deskSource
                ).when({ viewportInlineSize: { min: "small" } }, deskSource)}
                accessibilityDescription={accessibilityDescription}
                loading="eager"
                cornerRadius="base"
              />
            </Link>
          ) : (
            <Image
              source={Style.default(
                mobileSource
                  ? mobileSource
                  : deskSource
                  ? deskSource
                  : "https://placehold.co/600x100"
              )
                .when(
                  { viewportInlineSize: { min: "small" } },
                  mobileSource ? mobileSource : "https://placehold.co/600x120"
                )
                .when(
                  { viewportInlineSize: { min: "medium" } },
                  deskSource ? deskSource : "https://placehold.co/600x100"
                )
                .when(
                  { viewportInlineSize: { min: "large" } },
                  deskSource ? deskSource : "https://placehold.co/600x100"
                )}
              accessibilityDescription={accessibilityDescription}
              loading="eager"
              cornerRadius="base"
            />
          )}
        </>
      ) : (
        ""
      )}
    </>
  );
}
