import React, { useState, useEffect } from "react";
import {
  Banner,
  reactExtension,
  View,
  Text,
  useAppMetafields,
  useSettings,
  useCartLines,
  useTotalAmount,
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function compareNumber(condition, compareWith, compareTo) {
  switch (condition) {
    case "gt":
      return compareWith > compareTo;
    case "gte":
      return compareWith >= compareTo;
    case "lt":
      return compareWith < compareTo;
    case "lte":
      return compareWith <= compareTo;
    case "eq":
      return compareWith == compareTo;
    case "neq":
      return compareWith != compareTo;
    default:
      throw new Error("Invalid condition");
  }
}

function Extension() {
  const metafields = useAppMetafields();
  const cartLines = useCartLines();
  const cartTotals = useTotalAmount();

  const [vendors, setVendors] = useState([]);
  const [productTypes, setProductTypes] = useState([]);
  const [products, setProducts] = useState([]);

  // Initialize a state variable to store the matching data item
  const [matchingDataItem, setMatchingDataItem] = useState(null);

  // Get app settings through customizer settings
  let { extension_id } = useSettings();

  if (extension_id == undefined) {
    extension_id = "572256";
  }

  useEffect(() => {
    cartLines.forEach((cartLine) => {
      setProducts([...products, cartLine.merchandise.product.id]);
      setVendors([...vendors, cartLine.merchandise.product.vendor]);
      setProductTypes([
        ...productTypes,
        cartLine.merchandise.product.productType,
      ]);
    });
  }, [cartLines]);

  // Use useEffect to populate the data array when metafields changes
  // Check if data contains anything that matches extension_id
  useEffect(() => {
    if (metafields.length > 0) {
      const appMetafieldData = JSON.parse([metafields[0]?.metafield?.value]);

      const matchingItem = appMetafieldData.find(
        (item) => item.id === extension_id
      );

      console.log({ matchingItem });

      if (matchingItem) {
        setMatchingDataItem(matchingItem);
      } else {
        setMatchingDataItem({});
      }
    } else {
      setMatchingDataItem({}); // Handle the case when metafields is empty
    }
  }, [metafields, extension_id]);

  // Function to check if conditions are met
  const areConditionsMet = (conditions) => {
    let status = [];

    // Iterate through the conditions
    conditions.forEach((condition) => {
      console.log({ condition });
      switch (condition.type) {
        case "product":
          break;
          if (
            (condition.rule === "is" &&
              condition.value.includes(lineItem.product?.id)) ||
            (condition.rule === "is_not" &&
              !condition.value.includes(lineItem.product?.id))
          ) {
            status.push(true);
          } else {
            status.push(false);
          }
          break;

        case "product_vendor":
          if (
            (condition.rule === "is" &&
              condition.value.some((r) => vendors.includes(r))) ||
            (condition.rule === "is_not" &&

              !condition.value.some(r => vendors.includes(r)))
          ) {
            status.push(true);
          } else {
            status.push(false);
          }
          break;

        case "cart_total":
          status.push(
            compareNumber(condition.rule, cartTotals.amount, condition.value)
          );
          break;

        case "cart_quantity":
          const totalQuantity = cartLines.reduce(
            (totalQuantity, lineItem) => totalQuantity + lineItem.quantity,
            0
          );
          status.push(
            compareNumber(condition.rule, totalQuantity, condition.value)
          );
          break;

        case "product_type":
          break;
          if (
            (condition.rule === "is" &&
              condition.value.includes(lineItem.product?.productType)) ||
            (condition.rule === "is_not" &&
              !condition.value.includes(lineItem.product?.productType))
          ) {
            status.push(true);
          } else {
            status.push(false);
          }
          break;

        // Add other condition types here

        default:
          break;
      }
    });


    if(status.length) {
      if(matchingDataItem?.conditionsType == 'or'){
        return status.some((value) => value === true)
      } else {
        return status.every((value) => value === true);
      }
    } else {
      return true;
    }
  };

  return (
    <View>
      {matchingDataItem?.isActive &&
        matchingDataItem?.contents?.map((item, index) => {
          console.log({
            areConditionsMet: areConditionsMet(matchingDataItem.conditions),
          });

          if (areConditionsMet(matchingDataItem.conditions)) {
            if (item.type === "banner") {
              return (
                <Banner
                  key={index}
                  title={item.title}
                  collapsible={item.collapsible}
                >
                  {item.content}
                </Banner>
              );
            } else if (item.type === "text") {
              // Render a Text component here if needed
              return <Text key={index}>{item.content}</Text>;
            }
          }

          // Add other content types and components as needed
          return null;
        })}
    </View>
  );
}
