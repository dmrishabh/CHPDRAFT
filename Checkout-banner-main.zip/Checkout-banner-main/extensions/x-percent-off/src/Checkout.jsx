import { useEffect, useState } from "react";
import {
  Banner,
  reactExtension,
  useSelectedPaymentOptions,
  useApplyAttributeChange,
  useAttributes,
  useApi
} from '@shopify/ui-extensions-react/checkout';

export default reactExtension(
  'purchase.checkout.block.render',
  () => <Extension />,
);

function Extension() {
  const baseUrl = 'https://pro.checkoutextension.com';
  const options = useSelectedPaymentOptions();
  const checkoutAttributes = useAttributes();
  const updateAttribute = useApplyAttributeChange();
  const [isEligible, setIsEligible] = useState(false);
  const [isPaymentGatewayDiscountable, setIsPaymentGatewayDiscountable] = useState(true);
  const [selectedPaymentGateway, setSelectedPaymentGateway] = useState('');

  //Method to check page View
  const { sessionToken, extension } = useApi();
  const isCustomizerOpen = !!(extension && extension.editor);

    /**
   * Call API
   *
   * @param {*} url
   * @param {*} token
   * @returns
   */
    const fetchWithToken = async (url, token, method = "GET", data = null) => {
      try {
        const config = {
          method: method,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        };
        if (data) {
          config["body"] = JSON.stringify(data);
        }
  
        const result = await fetch(url, config);
        return result.json();
      } catch (error) {
        console.log("Error", error.message);
        return {
          success: false,
        };
      }
    };

  /**
   * Handle Page Viewed
   *
   */
  const handlePageViewed = async () => {
    const token = Date.now().toString() + Math.random().toString(36).substring(2, 7);
    const url = `${baseUrl}/api/checkoutextension/viewed`;
    const sToken = await sessionToken.get();
    let response;

    // Not to count View if the merchant have opened checkout customizer
    if(!isCustomizerOpen) {
      response = await fetchWithToken(url, sToken, "POST", { token: token });
    }

    // Add attribute only if viewed by customer and billing or trial is active
    await updateAttribute({
      key: "isPrepaidDiscountApplied",
      value: ((response && response.success) || isCustomizerOpen) ? token : 'ACTION_REQUIRED_ON_APP',
      type: "updateAttribute",
    }).then(() => {
        // Can be used for logging data
        // console.log({msg: "Attributes Updated: isPrepaidDiscountApplied", isTest: isCustomizerOpen });
      }
    );

    return (!!(response && response.success) || !!isCustomizerOpen);
  };

  useEffect(() => {
    options.forEach(option => {
      setSelectedPaymentGateway(option.type);
    })
  },[options])

  useEffect(() => {
    setIsPaymentGatewayDiscountable(!(selectedPaymentGateway === 'paymentOnDelivery' || selectedPaymentGateway === 'manualPayment'));
  },[selectedPaymentGateway])


  useEffect( async () => {
    const isPrepaidDiscountApplied = checkoutAttributes.find(
      (attr) => attr.key == "isPrepaidDiscountApplied"
    );

    if (isPrepaidDiscountApplied == undefined && !(selectedPaymentGateway === 'paymentOnDelivery' || selectedPaymentGateway === 'manualPayment')) {
      functionalityAppliedCounted = await handlePageViewed();
      setIsEligible(functionalityAppliedCounted)
    } else if ( isPrepaidDiscountApplied.value !== 'ACTION_REQUIRED_ON_APP' ) {
      setIsEligible(true);
    } else {
      setIsEligible(false);
    }
  },[isPaymentGatewayDiscountable])

  useEffect( async () => {
    if(isEligible){
      await updateAttribute({
        key: "discountedPaymentGateway",
        value: isPaymentGatewayDiscountable.toString(),
        type: "updateAttribute",
      })
    }
  },[isPaymentGatewayDiscountable,isEligible])

  return (
    <>
      { isEligible ?
       isPaymentGatewayDiscountable
        ? <Banner>Prepaid Offer Applied</Banner>
        : <Banner>Use Online payment gateway for discount</Banner>
      : '' }
    </>
  )

}