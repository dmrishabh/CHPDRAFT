import { DiscountApplicationStrategy } from "../generated/api";

/**
 * @typedef {import("../generated/api").InputQuery} InputQuery
 * @typedef {import("../generated/api").FunctionResult} FunctionResult
 */

/**
 * @type {FunctionResult}
 */
const EMPTY_DISCOUNT = {
  discountApplicationStrategy: DiscountApplicationStrategy.First,
  discounts: [],
};

export default /**
 * @param {InputQuery} input
 * @returns {FunctionResult}
 */
(input) => {
  // Define a type for your configuration, and parse it from the metafield
  const configuration = JSON.parse(
    input?.discountNode?.metafield?.value ?? "{}"
  );

  // if (!configuration.quantity || !configuration.percentage) {
  //   return EMPTY_DISCOUNT;
  // }
  let totalEligibleCost = 0;
  let totalEligibleQuantity = 0;

  if(configuration.appliesTo == 'Collection'){
    // Finding the Product which falls under the collection
    input.cart.lines
    .filter(line => line.merchandise.__typename == "ProductVariant" && line.merchandise.product.inAnyCollection )
    .forEach(line => {
      totalEligibleQuantity += parseInt(line.quantity);
      totalEligibleCost += parseFloat(line.cost?.totalAmount?.amount || 0);
    });
  } else if(configuration.appliesTo == 'Product'){
    // Finding the Product which falls under the collection
    input.cart.lines
    .filter(line => line.merchandise.__typename == "ProductVariant" && configuration.selectedProducts.filter( item => item.id == line.merchandise.product.id ).length)
    .forEach(line => {
      totalEligibleQuantity += parseInt(line.quantity);
      totalEligibleCost += parseFloat(line.cost?.totalAmount?.amount || 0);
    });
  }

  let targets = [];

  if(totalEligibleCost >= configuration.purchaseAmount  && totalEligibleQuantity >= configuration.purchaseQuantity ){
    configuration.selectedGetProducts
    .map(product => {
      product.variants.map(variant => {
        targets.push({
          productVariant: {
            id: variant.id,
            quantity: 1
          }
        })
      })
    });
  }

  if (!targets.length) {
    console.error(totalEligibleQuantity);
    console.error(totalEligibleCost);
    console.error(configuration.purchaseAmount);
    console.error(configuration.purchaseQuantity);
    console.error(totalEligibleCost >= configuration.purchaseAmount  && totalEligibleQuantity >= configuration.purchaseQuantity);
    console.error(configuration.selectedGetProducts);

    console.error("Condition didn't Matched");
    return EMPTY_DISCOUNT;
  }

  return {
    discounts: [
      {
        targets,
        value: {
          percentage: {
            // Use the configured percentage instead of a hardcoded value
            value: "100"
          }
        }
      }
    ],
    discountApplicationStrategy: DiscountApplicationStrategy.First
  };
};