import React, { useState, useEffect } from "react";
import {
  reactExtension,
  TextField,
  Heading,
  BlockStack,
  useApplyMetafieldsChange,
  useMetafield,
  useApplyAttributeChange,
  useAttributes,
  useSettings,
  useAppMetafields,
  Select,
  PhoneField,
  DateField,
  useBuyerJourneyIntercept,
  useApi,
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  // Update Base URL accordingly
  const baseUrl = "https://pro.checkoutextension.com";
  // const baseUrl = "https://phi-eagles-commissions-hospitals.trycloudflare.com";

  // Get store data
  const { sessionToken, extension } = useApi();
  const isCustomizerOpen = !!(extension && extension.editor);

  // Get app configurations through metafield
  const metafields = useAppMetafields();

  // Get app settings through customizer settings
  const { extension_id } = useSettings();
  // const extension_id = "431273";

  const checkoutAttributes = useAttributes();
  const updateAttribute = useApplyAttributeChange();
  const updateMetafield = useApplyMetafieldsChange();
  const [isEligible, setIsEligible] = useState(false);

  // Saving the form data
  const [formData, setFormData] = useState({});

  // Store field Errors
  const [formErrorData, setFormErrorData] = useState({});

  // Get the form input
  const handleFormFieldChange = (name, value) => {
    setFormData({ ...formData, [name]: value });
  };

  // Get the form input
  const handleFormFieldError = (name, value) => {
    setFormErrorData({ ...formErrorData, [name]: value });
  };

  const today = new Date().toISOString().split("T")[0];
  // Initialize state to store the selected date with today's date as the default
  const [selectedDate, setSelectedDate] = useState(today);

  // Initialize a state variable to store the matching data item
  const [matchingDataItem, setMatchingDataItem] = useState(null);

  // Use useEffect to populate the data array when metafields changes
  // Check if data contains anything that matches extension_id
  useEffect(() => {
    if (metafields.length > 0) {
      const appMetafieldData = JSON.parse([metafields[0]?.metafield?.value]);
      const matchingItem = appMetafieldData.find(
        (item) => item.id === extension_id
      );

      if (matchingItem) {
        setMatchingDataItem(matchingItem);
      } else {
        setMatchingDataItem(null);
      }
    } else {
      setMatchingDataItem({}); // Handle the case when metafields is empty
    }
  }, [metafields, extension_id]);

  useEffect(async () => {
    if (formData && matchingDataItem) {
      const formName = matchingDataItem.formName;

      // Store the data into the attributes
      await updateAttribute({
        key: formName,
        value: JSON.stringify(formData),
        type: "updateAttribute",
      });

      // TODO: Future:  Give an option to store the data into the metafield
      // Also create a metafield defination on creation of the form
      // await updateMetafield({
      //   key: formName,
      //   namespace: "custom_form_fields",
      //   valueType: "json_string",
      //   value: JSON.stringify(formData),
      //   type: "updateMetafield",
      // });
    }
  }, [formData]);

  useEffect(() => {
    // Iterate through the Checkout Attribute array to find the "FormName" key
    const preFilledFormData = checkoutAttributes.find(
      (item) => item.key === matchingDataItem?.formName
    );

    if (preFilledFormData?.value) {
      const parsedPreFilledData = JSON.parse(preFilledFormData?.value);
      // setFormData(parsedPreFilledData);
      if (JSON.stringify(parsedPreFilledData) !== JSON.stringify(formData)) {
        setFormData(parsedPreFilledData);
      }
    }
  }, [matchingDataItem]);
  
  // Check the below if only required
  // Check for Required field
  useBuyerJourneyIntercept(({ canBlockProgress }) => {
    let invalidField = false;
    // If require is empty throw error
    {
      matchingDataItem && matchingDataItem.fields.map((field, index) => {
        // Check for required field
        if (field.required) {
          if (formData[field.name] == "") {
            invalidField = true;
            handleFormFieldError(field.name, "Input is required");
          }
        }

        // Check if the date entered is valid
        if(field.type == 'date' && formData[field.name] ) {
          const enteredDate = new Date(formData[field.name]);

          // If the date object is invalid it
          // will return 'NaN' on getTime()
          // and NaN is never equal to itself
          if(!(enteredDate.getTime() == enteredDate.getTime())){
            invalidField = true;
            handleFormFieldError(
              field.name,
              `${formData[field.name]} is not a valid date`
            )
          }
        }

        // Check For regex
        if (field?.regex) {
          let regexCheck = true;

          const fieldRegExp = new RegExp(field.regex);
          const fieldValue = formData[field.name];

          regexCheck = fieldRegExp.test(fieldValue);

          if(!regexCheck){
            invalidField = true;
            handleFormFieldError(
              field.name,
              "Input is not in correct format!"
            )
          } else {
            handleFormFieldError(field.name, "");
          }
        }
      });
    }

    return canBlockProgress && invalidField && isEligible
      ? {
          behavior: "block",
          reason: "Form not completed",
          errors: [
            {
              message: "Sorry, it seems like you have not filled the form correctly",
            },
          ],
        }
      : {
          behavior: "allow",
        };
  });

  // Code for billing integration

  /**
   * Call API
   *
   * @param {*} url
   * @param {*} token
   * @returns
   */
  const fetchWithToken = async (url, token, method = "GET", data = null) => {
    try {
      const config = {
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      if (data) {
        config["body"] = JSON.stringify(data);
      }

      const result = await fetch(url, config);
      return result.json();
    } catch (error) {
      console.log("Error", error.message);
      return {
        success: false,
      };
    }
  };

  /**
   * Handle Page Viewed
   *
   */
  const handlePageViewed = async () => {
    const token = Date.now().toString() + Math.random().toString(36).substring(2, 7);
    const url = `${baseUrl}/api/checkoutextension/viewed`;
    const sToken = await sessionToken.get();
    let response;

    // Not to count View if the merchant have opened checkout customizer
    if(!isCustomizerOpen) {
      response = await fetchWithToken(url, sToken, "POST", { token: token });
    }

    // Add attribute only if viewed by customer and billing or trial is active
    await updateAttribute({
      key: "isFormViewed",
      value: ((response && response.success) || isCustomizerOpen) ? token : 'ACTION_REQUIRED_ON_APP', 
      type: "updateAttribute",
    }).then((data) => {
        // Can be used for logging data
      }
    );

    return (!!(response && response.success) || !!isCustomizerOpen);
  };

  useEffect(async () => {
    const isFormViewed = checkoutAttributes.find(
      (attr) => attr.key == "isFormViewed"
    );
    if (isFormViewed == undefined) {
      await handlePageViewed();
    } else if (isFormViewed.value !== "ACTION_REQUIRED_ON_APP") {
      setIsEligible(true);
    }
  }, [checkoutAttributes]);

  // Render the extension components
  return (
    isEligible ?
    <BlockStack>
      {matchingDataItem && matchingDataItem.isActive ? (
        <BlockStack>
          <Heading>{matchingDataItem.title}</Heading>
          {matchingDataItem.fields.map((field, index) => (
            <BlockStack key={index}>
              {(() => {
                switch (field.type) {
                  case "text":
                    return (
                      <TextField
                        label={field?.name}
                        required={field?.required}
                        value={formData[field.name] || ""}
                        error={formErrorData[field.name] || ""}
                        onChange={(value) => {
                          let regexCheck = true;

                          // If field is required and value is empty show invalid field
                          field.required && value == ""
                            ? handleFormFieldError(
                                field.name,
                                "Input is not in correct format!"
                              )
                            : handleFormFieldError(field.name, "");

                          // Check For regex
                          if (field?.regex && value) {
                            const fieldRegExp = new RegExp(field.regex);
                            regexCheck = fieldRegExp.test(value);
                            !regexCheck
                              ? handleFormFieldError(
                                  field.name,
                                  "Input is not in correct format!"
                                )
                              : handleFormFieldError(field.name, "");
                          }

                          handleFormFieldChange(field.name, value);
                        }}
                      />
                    );
                  case "dropdown":
                    return (
                      <Select
                        required={field?.required}
                        label={field?.name}
                        value={formData[field.name] || ""}
                        options={field.options.map((option, optionIndex) => ({
                          value: option,
                          label: option,
                        }))}
                        onChange={(value) => {
                          handleFormFieldChange(field.name, value);
                        }}
                      />
                    );
                  case "date":
                    return (
                      <DateField
                        label={field?.name}
                        required={field?.required}
                        selected={selectedDate}
                        value={formData[field.name] || ""}
                        error={formErrorData[field.name] || ""}
                        onInvalid={() => {
                          handleFormFieldError(
                            field.name,
                            `${formData[field.name]} is not a valid date`
                          );
                        }}
                        onChange={(value) => {
                          handleFormFieldError(field.name, "");
                          handleFormFieldChange(field.name, value);
                        }}
                      />
                    );
                  case "phone":
                    return (
                      <PhoneField
                        required={field?.required}
                        autocomplete={true}
                        label={field?.name}
                        value={formData[field.name] || ""}
                        onInput={() => {
                          handleFormFieldError(field.name, "");
                        }}
                        onChange={(value) => {
                          const phoneNumber = value.replace(/[^\d\-\+ ]/g, "");
                          handleFormFieldChange(field.name, phoneNumber);
                        }}
                        error={formErrorData[field.name] || ""}
                      />
                    );
                  default:
                    return null;
                }
              })()}
            </BlockStack>
          ))}
        </BlockStack>
      ) : (
        <></>
      )}
    </BlockStack>
    : <></>
  );
}
